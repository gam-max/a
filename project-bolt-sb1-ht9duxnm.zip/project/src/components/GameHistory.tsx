import React, { useState } from 'react';
import { History, ChevronDown, ChevronUp, Trophy, X, Clock } from 'lucide-react';
import { GameHistory as GameHistoryType } from '../types/game';

interface GameHistoryProps {
  history: GameHistoryType[];
  isVisible: boolean;
  onToggle: () => void;
}

const GameHistory: React.FC<GameHistoryProps> = ({ history, isVisible, onToggle }) => {
  const [filter, setFilter] = useState<'all' | 'correct' | 'wrong'>('all');

  const filteredHistory = history.filter(item => {
    if (filter === 'correct') return item.isCorrect;
    if (filter === 'wrong') return !item.isCorrect;
    return true;
  });

  const stats = {
    total: history.length,
    correct: history.filter(h => h.isCorrect).length,
    wrong: history.filter(h => !h.isCorrect).length,
    redTeamCorrect: history.filter(h => h.team === 'red' && h.isCorrect).length,
    blueTeamCorrect: history.filter(h => h.team === 'blue' && h.isCorrect).length
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {/* Toggle Button */}
      <button
        onClick={onToggle}
        className="mb-4 w-14 h-14 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110"
        title="سجل الأسئلة"
      >
        <History className="w-6 h-6" />
      </button>

      {/* History Panel */}
      {isVisible && (
        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 w-96 max-h-96 overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-white/20">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-purple-400" />
              <h3 className="text-lg font-bold text-white">سجل الأسئلة</h3>
            </div>
            <button
              onClick={onToggle}
              className="w-8 h-8 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center hover:bg-red-500/30 transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Stats */}
          <div className="p-4 border-b border-white/20">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-white">{stats.total}</div>
                <div className="text-white/70 text-xs">إجمالي</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-400">{stats.correct}</div>
                <div className="text-green-300 text-xs">صحيحة</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-red-400">{stats.wrong}</div>
                <div className="text-red-300 text-xs">خاطئة</div>
              </div>
            </div>
          </div>

          {/* Filters */}
          <div className="p-4 border-b border-white/20">
            <div className="flex gap-2">
              {[
                { key: 'all', label: 'الكل', color: 'bg-gray-500/20 text-gray-300' },
                { key: 'correct', label: 'صحيحة', color: 'bg-green-500/20 text-green-300' },
                { key: 'wrong', label: 'خاطئة', color: 'bg-red-500/20 text-red-300' }
              ].map(filterOption => (
                <button
                  key={filterOption.key}
                  onClick={() => setFilter(filterOption.key as any)}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                    filter === filterOption.key 
                      ? filterOption.color + ' ring-2 ring-white/30' 
                      : 'bg-white/10 text-white/70 hover:bg-white/20'
                  }`}
                >
                  {filterOption.label}
                </button>
              ))}
            </div>
          </div>

          {/* History List */}
          <div className="max-h-48 overflow-y-auto">
            {filteredHistory.length === 0 ? (
              <div className="p-4 text-center text-white/70">
                لا توجد أسئلة بعد
              </div>
            ) : (
              <div className="space-y-2 p-4">
                {filteredHistory.reverse().map((item, index) => (
                  <div
                    key={index}
                    className={`p-3 rounded-xl border ${
                      item.isCorrect 
                        ? 'bg-green-500/10 border-green-400/30' 
                        : 'bg-red-500/10 border-red-400/30'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className={`px-2 py-1 rounded-full text-xs font-bold ${
                        item.team === 'red' 
                          ? 'bg-red-500/20 text-red-300' 
                          : 'bg-blue-500/20 text-blue-300'
                      }`}>
                        {item.team === 'red' ? 'أحمر' : 'أزرق'}
                      </div>
                      <div className="flex items-center gap-2">
                        {item.isCorrect ? (
                          <div className="flex items-center gap-1 text-green-400">
                            <Trophy className="w-4 h-4" />
                            <span className="text-xs font-bold">+{item.points}</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 text-red-400">
                            <X className="w-4 h-4" />
                            <span className="text-xs">0</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-white text-sm mb-1 line-clamp-2">
                      {item.question}
                    </div>
                    
                    <div className={`text-xs ${
                      item.isCorrect ? 'text-green-300' : 'text-red-300'
                    }`}>
                      الإجابة: {item.answer}
                    </div>
                    
                    <div className="flex items-center justify-between mt-2 text-xs text-white/50">
                      <span>{item.category} - {
                        item.difficulty === 'easy' ? 'سهل' :
                        item.difficulty === 'medium' ? 'متوسط' : 'صعب'
                      }</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default GameHistory;