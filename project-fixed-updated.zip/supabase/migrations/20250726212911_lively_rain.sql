/*
  # إنشاء جداول الإدارة فقط (بدون تعديل الجداول الموجودة)

  1. الجداول الجديدة
    - `admin_categories` - التخصصات المدارة
    - `admin_questions` - الأسئلة المدارة
    - `admin_activity` - سجل النشاطات

  2. الأمان
    - تفعيل RLS على الجداول الجديدة فقط
    - سياسات للقراءة والكتابة

  3. البيانات الافتراضية
    - إدراج التخصصات الأساسية
*/

-- جدول التخصصات المدارة
CREATE TABLE IF NOT EXISTS admin_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_ar text NOT NULL,
  name_en text,
  icon text DEFAULT 'BookOpen',
  color text DEFAULT 'from-blue-500 to-cyan-600',
  description text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- جدول الأسئلة المدارة
CREATE TABLE IF NOT EXISTS admin_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES admin_categories(id) ON DELETE CASCADE,
  question text NOT NULL,
  type text DEFAULT 'multiple_choice' CHECK (type IN ('multiple_choice', 'text')),
  options jsonb NOT NULL DEFAULT '[]'::jsonb,
  correct_answer jsonb NOT NULL,
  difficulty text NOT NULL CHECK (difficulty IN ('easy', 'medium', 'hard')),
  difficulty_level integer DEFAULT 1 CHECK (difficulty_level BETWEEN 1 AND 5),
  points integer DEFAULT 10,
  explanation text,
  notes text,
  tags jsonb DEFAULT '[]'::jsonb,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- جدول سجل النشاطات
CREATE TABLE IF NOT EXISTS admin_activity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL CHECK (type IN ('create', 'update', 'delete')),
  entity text NOT NULL CHECK (entity IN ('category', 'question')),
  entity_name text NOT NULL,
  entity_id uuid,
  details text,
  user_info jsonb,
  created_at timestamptz DEFAULT now()
);

-- إضافة عمود selected_categories إذا لم يكن موجوداً
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'game_state' AND column_name = 'selected_categories'
  ) THEN
    ALTER TABLE game_state ADD COLUMN selected_categories jsonb DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- تحديث قيود المرحلة لتشمل اختيار التخصصات
DO $$
BEGIN
  -- إزالة القيد القديم إذا كان موجوداً
  ALTER TABLE game_state DROP CONSTRAINT IF EXISTS game_state_phase_check;
  
  -- إضافة القيد الجديد
  ALTER TABLE game_state ADD CONSTRAINT game_state_phase_check 
    CHECK (phase IN ('categoryPreSelection', 'categorySelection', 'playing', 'result'));
EXCEPTION
  WHEN duplicate_object THEN
    -- تجاهل الخطأ إذا كان القيد موجوداً بالفعل
    NULL;
END $$;

-- تفعيل RLS على الجداول الجديدة فقط
ALTER TABLE admin_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_activity ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان للجداول الجديدة فقط
DO $$
BEGIN
  -- سياسة admin_categories
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'admin_categories' 
    AND policyname = 'Allow all operations on admin_categories'
  ) THEN
    CREATE POLICY "Allow all operations on admin_categories"
      ON admin_categories
      FOR ALL
      TO anon, authenticated
      USING (true)
      WITH CHECK (true);
  END IF;

  -- سياسة admin_questions
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'admin_questions' 
    AND policyname = 'Allow all operations on admin_questions'
  ) THEN
    CREATE POLICY "Allow all operations on admin_questions"
      ON admin_questions
      FOR ALL
      TO anon, authenticated
      USING (true)
      WITH CHECK (true);
  END IF;

  -- سياسة admin_activity
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'admin_activity' 
    AND policyname = 'Allow all operations on admin_activity'
  ) THEN
    CREATE POLICY "Allow all operations on admin_activity"
      ON admin_activity
      FOR ALL
      TO anon, authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_admin_categories_active ON admin_categories(is_active);
CREATE INDEX IF NOT EXISTS idx_admin_questions_category_id ON admin_questions(category_id);
CREATE INDEX IF NOT EXISTS idx_admin_questions_difficulty ON admin_questions(difficulty);
CREATE INDEX IF NOT EXISTS idx_admin_questions_active ON admin_questions(is_active);
CREATE INDEX IF NOT EXISTS idx_admin_activity_created_at ON admin_activity(created_at DESC);

-- دالة لتحديث updated_at تلقائياً (إنشاء فقط إذا لم تكن موجودة)
CREATE OR REPLACE FUNCTION update_admin_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- تطبيق الدالة على الجداول الجديدة
DO $$
BEGIN
  -- تحقق من وجود trigger قبل إنشائه
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_admin_categories_updated_at'
  ) THEN
    CREATE TRIGGER update_admin_categories_updated_at
      BEFORE UPDATE ON admin_categories
      FOR EACH ROW
      EXECUTE FUNCTION update_admin_updated_at_column();
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_admin_questions_updated_at'
  ) THEN
    CREATE TRIGGER update_admin_questions_updated_at
      BEFORE UPDATE ON admin_questions
      FOR EACH ROW
      EXECUTE FUNCTION update_admin_updated_at_column();
  END IF;
END $$;

-- إدراج التخصصات الافتراضية (فقط إذا لم تكن موجودة)
INSERT INTO admin_categories (name_ar, name_en, icon, color, description) 
SELECT * FROM (VALUES
  ('التاريخ', 'History', 'Book', 'from-amber-500 to-orange-600', 'أسئلة حول التاريخ العربي والعالمي'),
  ('الجغرافيا', 'Geography', 'Globe', 'from-green-500 to-emerald-600', 'أسئلة حول الجغرافيا والدول والعواصم'),
  ('العلوم', 'Science', 'Atom', 'from-blue-500 to-cyan-600', 'أسئلة حول الفيزياء والكيمياء والأحياء'),
  ('التكنولوجيا', 'Technology', 'Smartphone', 'from-purple-500 to-indigo-600', 'أسئلة حول التكنولوجيا والحاسوب'),
  ('الأدب', 'Literature', 'PenTool', 'from-pink-500 to-rose-600', 'أسئلة حول الأدب العربي والعالمي'),
  ('الرياضة', 'Sports', 'Trophy', 'from-red-500 to-pink-600', 'أسئلة حول الرياضة والألعاب')
) AS new_categories(name_ar, name_en, icon, color, description)
WHERE NOT EXISTS (
  SELECT 1 FROM admin_categories WHERE admin_categories.name_ar = new_categories.name_ar
);