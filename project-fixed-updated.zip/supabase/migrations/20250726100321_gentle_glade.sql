/*
  # إنشاء جداول اللعبة الأونلاين

  1. الجداول الجديدة
    - `game_rooms` - غرف اللعب
    - `game_players` - اللاعبين في كل غرفة  
    - `game_state` - حالة اللعبة المباشرة

  2. الأمان
    - تفعيل RLS على جميع الجداول
    - سياسات للقراءة والكتابة

  3. الفهارس
    - فهارس لتحسين الأداء
*/

-- جدول غرف اللعب
CREATE TABLE IF NOT EXISTS game_rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  host_id text NOT NULL,
  host_name text NOT NULL,
  status text DEFAULT 'waiting' CHECK (status IN ('waiting', 'playing', 'finished')),
  max_players integer DEFAULT 10,
  current_players integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- جدول اللاعبين
CREATE TABLE IF NOT EXISTS game_players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid REFERENCES game_rooms(id) ON DELETE CASCADE,
  player_id text NOT NULL,
  player_name text NOT NULL,
  team text CHECK (team IN ('red', 'blue')),
  is_ready boolean DEFAULT false,
  joined_at timestamptz DEFAULT now()
);

-- جدول حالة اللعبة
CREATE TABLE IF NOT EXISTS game_state (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid REFERENCES game_rooms(id) ON DELETE CASCADE UNIQUE,
  current_question jsonb,
  current_turn text DEFAULT 'red' CHECK (current_turn IN ('red', 'blue')),
  time_left integer DEFAULT 15,
  red_team_score integer DEFAULT 0,
  blue_team_score integer DEFAULT 0,
  red_team_power_cards integer DEFAULT 4,
  blue_team_power_cards integer DEFAULT 4,
  phase text DEFAULT 'categorySelection' CHECK (phase IN ('categorySelection', 'playing', 'result')),
  game_history jsonb DEFAULT '[]'::jsonb,
  used_questions jsonb DEFAULT '[]'::jsonb,
  used_power_card text,
  waiting_for_opponent boolean DEFAULT false,
  total_questions integer DEFAULT 0,
  max_questions_per_team integer DEFAULT 10,
  updated_at timestamptz DEFAULT now()
);

-- تفعيل RLS
ALTER TABLE game_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_players ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_state ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان - السماح للجميع بالقراءة والكتابة (للبساطة)
CREATE POLICY "Allow all operations on game_rooms"
  ON game_rooms
  FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on game_players"
  ON game_players
  FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on game_state"
  ON game_state
  FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_game_rooms_status ON game_rooms(status);
CREATE INDEX IF NOT EXISTS idx_game_players_room_id ON game_players(room_id);
CREATE INDEX IF NOT EXISTS idx_game_players_player_id ON game_players(player_id);
CREATE INDEX IF NOT EXISTS idx_game_state_room_id ON game_state(room_id);

-- دالة لتحديث updated_at تلقائياً
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- تطبيق الدالة على الجداول
CREATE TRIGGER update_game_rooms_updated_at
  BEFORE UPDATE ON game_rooms
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_game_state_updated_at
  BEFORE UPDATE ON game_state
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();