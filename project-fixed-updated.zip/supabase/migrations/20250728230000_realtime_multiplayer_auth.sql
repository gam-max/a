/*
  # إضافة دعم نظام التسجيل والملفات الشخصية للاعبين وربط اللاعبين بالمستخدمين

  تم إنشاء هذا الملف لإضافة جدول جديد للملفات الشخصية للاعبين وربط جدول اللاعبين
  الحالي مع جدول المستخدمين في Supabase (auth.users). بالإضافة إلى ذلك يتم تمكين
  سياسات RLS المناسبة للسماح لكل مستخدم بإدارة ملفه الشخصي الخاص.

  1. الجداول الجديدة
    - `player_profiles` : جدول يحتفظ ببيانات الملف الشخصي لكل مستخدم مسجل

  2. التعديلات على الجداول الحالية
    - إضافة عمود `user_id` إلى جدول `game_players` لربط اللاعب بحساب Supabase
      (يبقى العمود اختيارياً للسماح بالتوافق العكسي)

  3. الأمان
    - تفعيل RLS على جدول player_profiles
    - سياسات للقراءة والكتابة بحيث يستطيع كل مستخدم رؤية وتعديل ملفه الشخصي فقط

  4. الفهارس
    - فهرس لتحسين البحث عن اللاعبين بواسطة user_id
*/

-- إنشاء جدول ملفات اللاعبين إذا لم يكن موجوداً
CREATE TABLE IF NOT EXISTS player_profiles (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إضافة عمود user_id إلى جدول game_players إذا لم يكن موجوداً
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'game_players' AND column_name = 'user_id'
  ) THEN
    ALTER TABLE game_players ADD COLUMN user_id uuid;
  END IF;
END $$;

-- إنشاء قيد المفتاح الأجنبي على user_id للإشارة إلى auth.users
DO $$
BEGIN
  -- تحقق من عدم وجود القيد مسبقاً
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'game_players_user_id_fkey'
  ) THEN
    ALTER TABLE game_players
      ADD CONSTRAINT game_players_user_id_fkey
      FOREIGN KEY (user_id)
      REFERENCES auth.users(id)
      ON DELETE SET NULL;
  END IF;
END $$;

-- إنشاء فهرس للعمود user_id على game_players لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_game_players_user_id ON game_players(user_id);

-- تفعيل RLS على جدول player_profiles
ALTER TABLE player_profiles ENABLE ROW LEVEL SECURITY;

-- سياسة: السماح للمستخدم بقراءة ملفه الشخصي فقط
CREATE POLICY "Allow users to read their own profile" ON player_profiles
  FOR SELECT
  USING (auth.uid() = user_id);

-- سياسة: السماح للمستخدم بإدخال أو تحديث ملفه الشخصي
CREATE POLICY "Allow users to insert or update their own profile" ON player_profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id)
  TO authenticated;
CREATE POLICY "Allow users to update their own profile" ON player_profiles
  FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id)
  TO authenticated;

-- سياسة: السماح لدور الخدمة (service_role) بالوصول الكامل
CREATE POLICY "Allow service_role full access" ON player_profiles
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- دالة لتحديث حقل updated_at تلقائياً عند تحديث الصف
CREATE OR REPLACE FUNCTION update_player_profiles_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- تطبيق التريجر إذا لم يكن موجوداً
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_player_profiles_updated_at'
  ) THEN
    CREATE TRIGGER update_player_profiles_updated_at
      BEFORE UPDATE ON player_profiles
      FOR EACH ROW
      EXECUTE FUNCTION update_player_profiles_updated_at();
  END IF;
END $$;
