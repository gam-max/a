/*
  # إضافة عمود التخصصات المختارة لحالة اللعبة

  1. التعديلات
    - إضافة عمود `selected_categories` لجدول `game_state`
    - إضافة مرحلة `categoryPreSelection` للعبة

  2. الأمان
    - تحديث السياسات الموجودة
*/

-- إضافة عمود التخصصات المختارة
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'game_state' AND column_name = 'selected_categories'
  ) THEN
    ALTER TABLE game_state ADD COLUMN selected_categories jsonb DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- تحديث قيود المرحلة لتشمل اختيار التخصصات
DO $$
BEGIN
  -- إزالة القيد القديم
  ALTER TABLE game_state DROP CONSTRAINT IF EXISTS game_state_phase_check;
  
  -- إضافة القيد الجديد
  ALTER TABLE game_state ADD CONSTRAINT game_state_phase_check 
    CHECK (phase IN ('categoryPreSelection', 'categorySelection', 'playing', 'result'));
END $$;

-- تحديث المرحلة الافتراضية
ALTER TABLE game_state ALTER COLUMN phase SET DEFAULT 'categoryPreSelection';