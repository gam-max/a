import React, { useState, useEffect } from 'react';
import { Users, Trophy, Wifi } from 'lucide-react';
import ErrorBoundary from './components/ErrorBoundary';
import StartScreen from './components/StartScreen';
import CategoryPreSelection from './components/CategoryPreSelection';
import LobbyMenu from './components/LobbyMenu';
import GameRoom from './components/GameRoom';
import CategorySelection from './components/CategorySelection';
import GameScreen from './components/GameScreen';
import ResultScreen from './components/ResultScreen';
import OnlineGameScreen from './components/OnlineGameScreen';
import DeveloperPanel from './components/DeveloperPanel';
import AdminDashboard from './components/admin/AdminDashboard';
import { GameState, Player, PowerCard, Team } from './types/game';
import { useGameCategories } from './hooks/useGameCategories';
import { useQuestionManager } from './hooks/useQuestionManager';
import { useLobby } from './hooks/useLobby';
import { hasValidSupabaseConfig } from './lib/supabase';

// تحقق من وضع التطوير
const isDevelopment = import.meta.env.DEV;

function App() {
  const [gameMode, setGameMode] = useState<'offline' | 'online'>('offline');
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);
  const lobby = useLobby();
  
  // استخدام البيانات المناسبة حسب وضع اللعب
  const categoryQuestions = useGameCategories(gameMode === 'online');
  const questionManager = useQuestionManager(categoryQuestions);

  const [gameState, setGameState] = useState<GameState>({
    phase: 'modeSelection',
    redTeam: { players: [], score: 0, powerCards: 4 },
    blueTeam: { players: [], score: 0, powerCards: 4 },
    currentQuestion: null,
    currentTurn: 'red',
    timeLeft: 15,
    usedPowerCard: null,
    gameHistory: [],
    usedQuestions: [],
    selectedCategory: null,
    selectedDifficulty: null,
    waitingForOpponent: false,
    totalQuestions: 0,
    maxQuestionsPerTeam: 10,
    selectedCategories: []
  });

  // إضافة رسالة ترحيب عند نجاح الإعداد
  useEffect(() => {
    if (hasValidSupabaseConfig) {
      console.log('🎉 تم إعداد قاعدة البيانات بنجاح! الوضع الأونلاين متاح الآن.');
    }
  }, []);

  const joinGame = (playerName: string) => {
    const redCount = gameState.redTeam.players.length;
    const blueCount = gameState.blueTeam.players.length;
    const team: 'red' | 'blue' = redCount <= blueCount ? 'red' : 'blue';
    
    const newPlayer: Player = {
      id: Date.now().toString(),
      name: playerName,
      team
    };

    setGameState(prev => ({
      ...prev,
      [team === 'red' ? 'redTeam' : 'blueTeam']: {
        ...prev[team === 'red' ? 'redTeam' : 'blueTeam'],
        players: [...prev[team === 'red' ? 'redTeam' : 'blueTeam'].players, newPlayer]
      }
    }));
  };

  const startGame = () => {
    if (gameState.redTeam.players.length === 0 || gameState.blueTeam.players.length === 0) {
      alert('يجب أن يكون هناك لاعب واحد على الأقل في كل فريق');
      return;
    }

    setGameState(prev => ({
      ...prev,
      phase: 'categorySelection'
    }));
  };

  const handleCategoriesSelected = (categories: string[]) => {
    console.log('🎮 === بدء معالجة التخصصات المختارة ===');
    console.log('📥 التخصصات المستلمة:', categories);
    console.log('📊 عدد التخصصات:', categories?.length);
    console.log('🔍 نوع البيانات:', typeof categories);
    
    if (!categories || categories.length === 0) {
      console.error('❌ خطأ: لم يتم استلام تخصصات صحيحة:', categories);
      alert('خطأ: لم يتم اختيار أي تخصصات');
      return;
    }
    
    console.log('🔄 تحديث حالة اللعبة...');
    console.log('📋 الحالة الحالية:', gameState.phase);
    
    // تحديث الحالة
    setGameState(prev => {
      console.log('🔄 الحالة السابقة:', prev.phase);
      const newState = {
        ...prev,
        selectedCategories: categories,
        phase: 'categorySelection' as const
      };
      
      console.log('✅ الحالة الجديدة:', {
        phase: newState.phase,
        selectedCategories: newState.selectedCategories,
        selectedCategoriesCount: newState.selectedCategories.length
      });
      
      return newState;
    });
    
    console.log('🎉 === انتهاء معالجة التخصصات ===');
  };

  const goToCategorySelection = () => {
    setGameState(prev => ({ ...prev, phase: 'categoryPreSelection' }));
  };

  const backToModeSelection = () => {
    setGameState(prev => ({ ...prev, phase: 'modeSelection' }));
  };
  const selectCategory = (category: string, difficulty: 'easy' | 'medium' | 'hard') => {
    // فحص إشارة إنهاء اللعبة
    if (category === 'END_GAME') {
      console.log('🏁 تم استلام إشارة إنهاء اللعبة');
      setGameState(prev => ({ ...prev, phase: 'result' }));
      return;
    }

    // استخدام النظام الذكي لاختيار السؤال
    const selectedQuestion = questionManager.selectRandomQuestion(category, difficulty);
    
    if (!selectedQuestion) {
      console.warn(`لا توجد أسئلة متاحة في ${category} - ${difficulty}`);
      // فحص ما إذا كانت جميع الأسئلة قد انتهت
      const allCategoriesUsed = gameState.selectedCategories.every(cat => 
        (['easy', 'medium', 'hard'] as const).every(diff => 
          gameState.usedQuestions.some(used => used.category === cat && used.difficulty === diff)
        )
      );
      
      if (allCategoriesUsed) {
        console.log('🏁 جميع الأسئلة المتاحة قد استُخدمت - إنهاء اللعبة');
        setGameState(prev => ({ ...prev, phase: 'result' }));
      }
      return;
    }

    // إضافة السؤال للتاريخ
    questionManager.addQuestionToHistory(selectedQuestion);

    console.log('🎯 تم اختيار سؤال جديد:', {
      category,
      difficulty,
      questionId: selectedQuestion.id,
      question: selectedQuestion.question.substring(0, 50) + '...'
    });

    setGameState(prev => ({
      ...prev,
      phase: 'playing',
      currentQuestion: selectedQuestion,
      selectedCategory: category,
      selectedDifficulty: difficulty,
      timeLeft: 15,
      usedPowerCard: null,
      usedQuestions: [...prev.usedQuestions, { category, difficulty }],
      totalQuestions: prev.totalQuestions + 1
    }));
  };

  const answerQuestion = (answer: string, isCorrect: boolean) => {
    const currentTeam = gameState.currentTurn;
    const points = isCorrect ? (gameState.currentQuestion?.points || 0) : 0;

    if (isCorrect) {
      // إجابة صحيحة - إضافة النقاط وإنهاء السؤال
      setGameState(prev => ({
        ...prev,
        [currentTeam + 'Team']: {
          ...prev[currentTeam + 'Team' as keyof typeof prev],
          score: (prev[currentTeam + 'Team' as keyof typeof prev] as Team).score + points
        } as Team,
        waitingForOpponent: false,
        gameHistory: [...prev.gameHistory, {
          question: prev.currentQuestion!.question,
          answer,
          isCorrect,
          team: currentTeam,
          points,
          category: prev.currentQuestion!.category,
          difficulty: prev.currentQuestion!.difficulty
        }]
      }));
      
      setTimeout(() => {
        nextTurn();
      }, 2000);
    } else if (!gameState.waitingForOpponent) {
      // الفريق الأول أخطأ - إعطاء فرصة للفريق الآخر
      setGameState(prev => ({
        ...prev,
        waitingForOpponent: true,
        currentTurn: prev.currentTurn === 'red' ? 'blue' : 'red',
        timeLeft: 15,
        usedPowerCard: null, // إعادة تعيين كروت المساعدة
        gameHistory: [...prev.gameHistory, {
          question: prev.currentQuestion!.question,
          answer,
          isCorrect,
          team: prev.currentTurn, // الفريق الأصلي الذي أخطأ
          points: 0,
          category: prev.currentQuestion!.category,
          difficulty: prev.currentQuestion!.difficulty
        }]
      }));
    } else {
      // الفريق الثاني أخطأ أيضاً - إنهاء السؤال والانتقال للتالي
      setGameState(prev => ({
        ...prev,
        waitingForOpponent: false,
        gameHistory: [...prev.gameHistory, {
          question: prev.currentQuestion!.question,
          answer,
          isCorrect,
          team: currentTeam,
          points: 0,
          category: prev.currentQuestion!.category,
          difficulty: prev.currentQuestion!.difficulty
        }]
      }));
      
      setTimeout(() => {
        nextTurn();
      }, 2000);
    }
  };

  const nextTurn = () => {
    // التحقق من انتهاء اللعبة
    if (gameState.totalQuestions >= gameState.maxQuestionsPerTeam * 2) {
      setGameState(prev => ({ ...prev, phase: 'result' }));
      return;
    }

    setGameState(prev => ({
      ...prev,
      phase: 'categorySelection',
      currentTurn: prev.waitingForOpponent ? prev.currentTurn : (prev.currentTurn === 'red' ? 'blue' : 'red'),
      currentQuestion: null,
      selectedCategory: null,
      selectedDifficulty: null,
      timeLeft: 15,
      usedPowerCard: null,
      waitingForOpponent: false
    }));
  };

  const usePowerCard = (cardType: PowerCard) => {
    const currentTeam = gameState.currentTurn;
    const teamKey = currentTeam + 'Team' as keyof typeof gameState;
    
    if ((gameState[teamKey] as Team).powerCards <= 0) return;

    setGameState(prev => ({
      ...prev,
      [teamKey]: {
        ...prev[teamKey],
        powerCards: (prev[teamKey] as Team).powerCards - 1
      } as Team,
      usedPowerCard: cardType,
      timeLeft: cardType === 'extraTime' ? prev.timeLeft + 10 : prev.timeLeft
    }));

    if (cardType === 'skipQuestion') {
      setTimeout(() => {
        setGameState(prev => ({ ...prev, phase: 'categorySelection' }));
      }, 1000);
    }
  };

  const resetGame = () => {
    // إعادة تعيين جلسة الأسئلة عند بدء لعبة جديدة
    questionManager.resetSession();
    
    setGameState({
      phase: 'modeSelection',
      redTeam: { players: [], score: 0, powerCards: 4 },
      blueTeam: { players: [], score: 0, powerCards: 4 },
      currentQuestion: null,
      currentTurn: 'red',
      timeLeft: 15,
      usedPowerCard: null,
      gameHistory: [],
      usedQuestions: [],
      selectedCategory: null,
      selectedDifficulty: null,
      waitingForOpponent: false,
      totalQuestions: 0,
      maxQuestionsPerTeam: 10,
      selectedCategories: []
    });
    
    console.log('🔄 تم إعادة تشغيل اللعبة وإعادة تعيين جلسة الأسئلة');
  };

  const backToHome = () => {
    console.log('🏠 العودة للصفحة الرئيسية');
    resetGame();
  };

  // إذا كانت لوحة التحكم مفتوحة
  if (showAdminDashboard) {
    return <AdminDashboard onClose={() => setShowAdminDashboard(false)} />;
  }

  // Mode selection screen
  if (gameMode === 'offline' && gameState.phase === 'modeSelection') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <div className="min-h-screen flex items-center justify-center p-4">
          <div className="max-w-4xl w-full">
            <div className="text-center mb-12">
              <div className="flex items-center justify-center mb-6">
                <Trophy className="w-16 h-16 text-yellow-400 mr-4" />
                <h1 className="text-6xl font-bold text-white">
                  تحدي الفريقين
                </h1>
                <Trophy className="w-16 h-16 text-yellow-400 ml-4" />
              </div>
              <p className="text-xl text-blue-200">
                اختر طريقة اللعب المفضلة لديك
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <button
                onClick={() => {
                  console.log('🎮 تم الضغط على زر اللعب المحلي');
                  goToCategorySelection();
                }}
                className="bg-gradient-to-br from-green-500/20 to-emerald-700/20 backdrop-blur-md rounded-3xl p-8 border border-green-400/30 hover:border-green-400/50 transition-all duration-300 transform hover:scale-105"
              >
                <div className="text-center">
                  <Users className="w-16 h-16 text-green-400 mx-auto mb-4" />
                  <h3 className="text-3xl font-bold text-green-400 mb-4">لعب محلي</h3>
                  <p className="text-green-200 mb-6">
                    العب مع الأصدقاء على نفس الجهاز
                  </p>
                  <div className="space-y-2 text-green-200/80 text-sm">
                    <p>• سريع وبسيط</p>
                    <p>• لا يحتاج إنترنت</p>
                    <p>• مثالي للعائلة والأصدقاء</p>
                  </div>
                </div>
              </button>

              <button
                onClick={() => setGameMode('online')}
                disabled={!hasValidSupabaseConfig}
                className="bg-gradient-to-br from-blue-500/20 to-purple-700/20 backdrop-blur-md rounded-3xl p-8 border border-blue-400/30 hover:border-blue-400/50 transition-all duration-300 transform hover:scale-105 disabled:opacity-50"
              >
                <div className="text-center">
                  <Wifi className="w-16 h-16 text-blue-400 mx-auto mb-4" />
                  <h3 className="text-3xl font-bold text-blue-400 mb-4">لعب أونلاين</h3>
                  <p className="text-blue-200 mb-6">
                    العب مع أصدقائك من أي مكان في العالم
                    {!hasValidSupabaseConfig && (
                      <span className="block text-red-300 text-sm mt-2">
                        يتطلب إعداد Supabase
                      </span>
                    )}
                  </p>
                  <div className="space-y-2 text-blue-200/80 text-sm">
                    <p>• لعب مع الأصدقاء عن بُعد</p>
                    <p>• غرف مخصصة</p>
                    <p>• تزامن مباشر</p>
                    <p className="text-yellow-300">• للاختبار: افتح عدة تبويبات</p>
                  </div>
                </div>
              </button>
            </div>
          </div>
          
          {/* Admin Dashboard Button */}
          <div className="text-center mt-8">
            <button
              onClick={() => setShowAdminDashboard(true)}
              className="px-8 py-3 bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-bold rounded-xl hover:from-indigo-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2 mx-auto"
            >
              ⚙️ لوحة تحكم الإدارة
            </button>
            <p className="text-indigo-200 text-sm mt-2">
              إدارة التخصصات والأسئلة
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Category Pre-Selection Screen
  if (gameMode === 'offline' && gameState.phase === 'categoryPreSelection') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <CategoryPreSelection
          onCategoriesSelected={handleCategoriesSelected}
          onBack={backToModeSelection}
        />
      </div>
    );
  }

  // Online mode
  if (gameMode === 'online') {
    console.log('🌐 عرض وضع اللعب الأونلاين...', {
      lobbyMode: lobby.lobbyState.mode,
      currentRoom: lobby.lobbyState.currentRoom?.name,
      playerName: lobby.lobbyState.playerName,
      playersCount: lobby.lobbyState.players.length
    });
    
    return (
      <ErrorBoundary>
        <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        {lobby.lobbyState.mode === 'menu' && (
          <>
            {console.log('📋 عرض قائمة اللوبي...')}
            <LobbyMenu
              lobbyState={lobby.lobbyState}
              onCreateRoom={lobby.createRoom}
              onJoinRoom={lobby.joinRoom}
              onSetPlayerName={lobby.setPlayerName}
              onRefreshRooms={lobby.refreshRooms}
              onClearEmptyRooms={lobby.cleanupEmptyRooms}
            />
          </>
        )}
        
        {lobby.lobbyState.mode === 'room' && (
          <ErrorBoundary fallback={
            <div className="min-h-screen flex items-center justify-center">
              <div className="bg-red-500/20 border border-red-400/30 rounded-2xl p-8 text-center">
                <h2 className="text-2xl font-bold text-red-400 mb-4">خطأ في تحميل الغرفة</h2>
                <p className="text-red-200 mb-4">حدث خطأ أثناء تحميل غرفة اللعب</p>
                <button
                  onClick={() => {
                    lobby.leaveRoom();
                    window.location.reload();
                  }}
                  className="px-6 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all"
                >
                  العودة للوبي
                </button>
              </div>
            </div>
          }>
            <GameRoom
              lobbyState={lobby.lobbyState}
              players={lobby.lobbyState.players}
              onLeaveRoom={lobby.leaveRoom}
              onToggleReady={lobby.toggleReady}
              onStartGame={lobby.startGame}
              onSwitchTeam={lobby.switchTeam}
              onAddBot={lobby.addBot}
            />
          </ErrorBoundary>
        )}
        
        {lobby.lobbyState.mode === 'game' && (
          <div>
            {console.log('🎮 عرض شاشة اللعبة الأونلاين...', {
              roomId: lobby.lobbyState.currentRoom?.id,
              playerId: lobby.lobbyState.playerId,
              playerName: lobby.lobbyState.playerName,
              mode: lobby.lobbyState.mode
            })}
          <ErrorBoundary>
            <OnlineGameScreen
              roomId={lobby.lobbyState.currentRoom?.id || ''}
              playerId={lobby.lobbyState.playerId}
              playerName={lobby.lobbyState.playerName}
              onGameEnd={lobby.endGame}
            />
          </ErrorBoundary>
          </div>
        )}
        
        {/* رسالة خطأ إذا لم تتطابق أي حالة */}
        {!['menu', 'room', 'game'].includes(lobby.lobbyState.mode) && (
          <div className="min-h-screen flex items-center justify-center">
            <div className="bg-red-500/20 border border-red-400/30 rounded-2xl p-8 text-center">
              <h2 className="text-2xl font-bold text-red-400 mb-4">خطأ في حالة اللوبي</h2>
              <p className="text-red-200 mb-4">حالة غير معروفة: {lobby.lobbyState.mode}</p>
              <button
                onClick={() => window.location.reload()}
                className="px-6 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all"
              >
                إعادة تحميل الصفحة
              </button>
            </div>
          </div>
        )}
        
        <div className="fixed top-4 left-4">
          <button
            onClick={() => setGameMode('offline')}
            className="px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-all duration-300"
          >
            ← العودة
          </button>
        </div>
        </div>
      </ErrorBoundary>
    );
  }

  // Offline mode (original game)
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      {gameState.phase === 'start' && (
        <StartScreen 
          gameState={gameState}
          onJoinGame={joinGame}
          onStartGame={startGame}
        />
      )}
      
      {gameState.phase === 'categorySelection' && (
        <CategorySelection 
          gameState={gameState}
          onSelectCategory={selectCategory}
        />
      )}
      
      {gameState.phase === 'playing' && (
        <GameScreen 
          gameState={gameState}
          onAnswer={answerQuestion}
          onUsePowerCard={usePowerCard}
          setGameState={setGameState}
        />
      )}
      
      {gameState.phase === 'result' && (
        <ResultScreen 
          gameState={gameState}
          onRestart={resetGame}
          onBackToHome={backToHome}
        />
      )}
      
      {/* لوحة المطور - تظهر فقط في وضع التطوير */}
      {isDevelopment && (
        <DeveloperPanel 
          onAddQuestion={(question) => console.log('سؤال جديد:', question)}
        />
      )}
      
      {/* زر لوحة التحكم - يظهر دائماً */}
      <button
        onClick={() => setShowAdminDashboard(true)}
        className="fixed top-4 left-4 w-12 h-12 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 z-40"
        title="لوحة تحكم الإدارة"
      >
        ⚙️
      </button>
    </div>
  );
}

export default App;