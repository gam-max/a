export interface Category {
  id: string;
  nameAr: string;
  nameEn: string;
  icon: string;
  color: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AdminQuestion {
  id: string;
  categoryId: string;
  question: string;
  type: 'multiple_choice' | 'text';
  options: string[];
  correctAnswer: number | string;
  difficulty: 'easy' | 'medium' | 'hard';
  difficultyLevel: number; // 1-5
  points: number;
  explanation?: string;
  notes?: string;
  tags: string[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AdminStats {
  totalCategories: number;
  totalQuestions: number;
  questionsByDifficulty: {
    easy: number;
    medium: number;
    hard: number;
  };
  questionsByCategory: Record<string, number>;
  recentActivity: AdminActivity[];
}

export interface AdminActivity {
  id: string;
  type: 'create' | 'update' | 'delete';
  entity: 'category' | 'question';
  entityName: string;
  timestamp: string;
  details?: string;
}

export interface AdminFilters {
  categoryId?: string;
  difficulty?: 'easy' | 'medium' | 'hard';
  searchQuery?: string;
  isActive?: boolean;
  tags?: string[];
}