export interface Player {
  id: string;
  name: string;
  team: 'red' | 'blue';
}

export interface Team {
  players: Player[];
  score: number;
  powerCards: number;
}

export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
}

export interface CategoryQuestion {
  category: string;
  icon: string;
  difficulties: {
    easy: Question[];
    medium: Question[];
    hard: Question[];
  };
}

export interface UsedQuestion {
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface GameHistory {
  question: string;
  answer: string;
  isCorrect: boolean;
  team: 'red' | 'blue';
  points: number;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  player?: string;
  timestamp?: string;
}

export interface GameState {
  phase: 'modeSelection' | 'categoryPreSelection' | 'start' | 'categorySelection' | 'playing' | 'result';
  redTeam: Team;
  blueTeam: Team;
  currentQuestion: Question | null;
  currentTurn: 'red' | 'blue';
  timeLeft: number;
  usedPowerCard: PowerCard | null;
  gameHistory: GameHistory[];
  usedQuestions: UsedQuestion[];
  selectedCategory: string | null;
  selectedDifficulty: 'easy' | 'medium' | 'hard' | null;
  waitingForOpponent: boolean;
  totalQuestions: number;
  maxQuestionsPerTeam: number;
  selectedCategories: string[];
}

export type PowerCard = 'fiftyFifty' | 'skipQuestion' | 'stealTurn' | 'extraTime';