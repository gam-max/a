export interface GameRoom {
  id: string;
  name: string;
  host_id: string;
  host_name: string;
  status: 'waiting' | 'playing' | 'finished';
  max_players: number;
  current_players: number;
  created_at: string;
  updated_at: string;
}

export interface GamePlayer {
  id: string;
  room_id: string;
  player_id: string;
  player_name: string;
  team: 'red' | 'blue' | null;
  is_ready: boolean;
  joined_at: string;
}

export interface OnlineGameState {
  id: string;
  room_id: string;
  current_question: any;
  current_turn: 'red' | 'blue';
  time_left: number;
  red_team_score: number;
  blue_team_score: number;
  phase: 'categoryPreSelection' | 'categorySelection' | 'playing' | 'result';
  game_history: any[];
  used_questions: any[];
  selected_categories: string[];
  total_questions: number;
  updated_at: string;
}

export interface LobbyState {
  mode: 'menu' | 'lobby' | 'room' | 'game';
  currentRoom: GameRoom | null;
  playerId: string;
  playerName: string;
  rooms: GameRoom[];
  players: GamePlayer[];
  gameState: OnlineGameState | null;
}