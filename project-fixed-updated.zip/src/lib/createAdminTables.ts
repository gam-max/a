import { supabase } from './supabase';

export const createAdminTables = async (): Promise<boolean> => {
  if (!supabase) {
    console.error('❌ قاعدة بيانات Supabase غير متاحة - يرجى إعداد قاعدة البيانات أولاً');
    return false;
  }

  try {
    console.log('🔍 فحص هيكل قاعدة البيانات...');
    
    // Check if admin_categories table exists
    const { error: adminCategoriesError } = await supabase
      .from('admin_categories')
      .select('id')
      .limit(1);

    // Check if selected_categories column exists in game_state table
    const { error: gameStateError } = await supabase
      .from('game_state')
      .select('selected_categories')
      .limit(1);

    // Check for specific error codes that indicate missing schema
    const adminTablesExist = !adminCategoriesError || (
      adminCategoriesError.code !== '42P01' && // relation does not exist
      adminCategoriesError.code !== 'PGRST106' && // schema cache lookup failed
      !adminCategoriesError.message?.includes('does not exist') &&
      !adminCategoriesError.message?.includes('admin_categories')
    );
    
    const selectedCategoriesExists = !gameStateError || (
      gameStateError.code !== 'PGRST204' && // column not found in select
      gameStateError.code !== '42703' && // column does not exist
      !gameStateError.message?.includes('selected_categories') &&
      !gameStateError.message?.includes('column')
    );

    if (!adminTablesExist || !selectedCategoriesExists) {
      console.warn('❌ هيكل قاعدة البيانات غير مكتمل:');
      if (!adminTablesExist) {
        console.warn('  • جداول لوحة التحكم (admin_categories, admin_questions, admin_activity) مفقودة');
        console.warn('  • خطأ:', adminCategoriesError?.message || 'غير محدد');
      }
      if (!selectedCategoriesExists) {
        console.warn('  • عمود التخصصات المختارة (selected_categories) مفقود من جدول حالة اللعبة');
        console.warn('  • خطأ:', gameStateError?.message || 'غير محدد');
      }
      
      console.log('');
      console.log('🛠️ الحل المطلوب: تشغيل ملفات إعداد قاعدة البيانات في Supabase');
      console.log('');
      console.log('📋 الخطوات المطلوبة:');
      console.log('1️⃣ اذهب إلى: https://supabase.com/dashboard');
      console.log('2️⃣ اختر مشروعك → SQL Editor → New Query');
      console.log('3️⃣ شغّل الملفات بالترتيب التالي:');
      console.log('   • أولاً: supabase/migrations/20250726100321_gentle_glade.sql');
      console.log('   • ثانياً: supabase/migrations/20250726212911_lively_rain.sql');
      console.log('4️⃣ انسخ محتوى كل ملف كاملاً والصقه في المحرر');
      console.log('5️⃣ اضغط "Run" لتشغيل كل ملف');
      console.log('6️⃣ تأكد من ظهور رسالة "Success" لكل ملف');
      console.log('');
      console.log('⚠️ ملاحظة: يجب تشغيل الملفين بالترتيب المحدد لضمان عمل قاعدة البيانات بشكل صحيح');
      
      return false;
    }

    console.log('✅ هيكل قاعدة البيانات مكتمل - جميع الجداول والأعمدة المطلوبة موجودة');
    return true;

  } catch (error) {
    console.warn('❌ خطأ في فحص هيكل قاعدة البيانات:', error);
    console.log('');
    console.log('🔧 الحلول المتاحة:');
    console.log('1️⃣ الحل السريع: الوضع المحلي');
    console.log('   • استخدم زر "الوضع المحلي الكامل" في لوحة التحكم');
    console.log('   • جميع الميزات متاحة محلياً بدون قاعدة بيانات');
    console.log('');
    console.log('2️⃣ الحل الكامل: إصلاح قاعدة البيانات');
    console.log('   • شغّل ملفات SQL المطلوبة في Supabase Dashboard');
    console.log('   • اتبع التعليمات المفصلة في مساعد الإعداد');
    console.log('');
    console.log('📞 للمساعدة: استخدم مساعد الإعداد التفاعلي في لوحة التحكم');
    return false;
  }
};
