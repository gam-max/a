import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder-key';

// تحقق من صحة إعدادات Supabase
const hasValidSupabaseConfig = supabaseUrl !== 'https://placeholder.supabase.co' && 
  supabaseAnonKey !== 'placeholder-key' && 
  supabaseUrl.includes('supabase.co') && 
  supabaseAnonKey.length > 20;

export const supabase = hasValidSupabaseConfig ? createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    // تمكين حفظ الجلسة للسماح ببقاء المستخدمين مسجلين الدخول عبر الصفحات
    persistSession: true,
    autoRefreshToken: true
  },
  global: {
    fetch: (url, options = {}) => {
      return fetch(url, options).catch(error => {
        // تجاهل أخطاء قاعدة البيانات المتوقعة وعدم طباعتها كأخطاء
        const errorMessage = error?.message || '';
        if (errorMessage.includes('does not exist') || 
            errorMessage.includes('relation') ||
            errorMessage.includes('column') ||
            error?.code === '42P01' || 
            error?.code === '42703' ||
            error?.code === 'PGRST204' ||
            error?.code === 'PGRST116') {
          // هذه أخطاء متوقعة عندما تكون قاعدة البيانات غير مكتملة
          console.log('🔍 فحص قاعدة البيانات: هيكل غير مكتمل (متوقع)');
          throw error; // إعادة رمي الخطأ بدون طباعته
        }
        console.error('خطأ غير متوقع في Supabase:', error);
        throw error;
      });
    }
  }
}) : null;
export { hasValidSupabaseConfig };

// دالة للتحقق من اتصال قاعدة البيانات
export const testDatabaseConnection = async (): Promise<boolean> => {
  if (!supabase) return false;
  
  try {
    // اختبار الاتصال بجدول بسيط
    const { error } = await supabase
      .from('game_rooms')
      .select('id')
      .limit(1);
    
    return !error;
  } catch (error) {
    console.log('🔍 اختبار الاتصال: قاعدة البيانات غير جاهزة بعد');
    return false;
  }
};

export type Database = {
  public: {
    Tables: {
      game_rooms: {
        Row: {
          id: string;
          name: string;
          host_id: string;
          host_name: string;
          status: 'waiting' | 'playing' | 'finished';
          max_players: number;
          current_players: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          host_id: string;
          host_name: string;
          status?: 'waiting' | 'playing' | 'finished';
          max_players?: number;
          current_players?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          host_id?: string;
          host_name?: string;
          status?: 'waiting' | 'playing' | 'finished';
          max_players?: number;
          current_players?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      game_players: {
        Row: {
          id: string;
          room_id: string;
          player_id: string;
          player_name: string;
          team: 'red' | 'blue' | null;
          is_ready: boolean;
          joined_at: string;
        };
        Insert: {
          id?: string;
          room_id: string;
          player_id: string;
          player_name: string;
          team?: 'red' | 'blue' | null;
          is_ready?: boolean;
          joined_at?: string;
        };
        Update: {
          id?: string;
          room_id?: string;
          player_id?: string;
          player_name?: string;
          team?: 'red' | 'blue' | null;
          is_ready?: boolean;
          joined_at?: string;
        };
      };
      game_state: {
        Row: {
          id: string;
          room_id: string;
          current_question: any;
          current_turn: 'red' | 'blue';
          time_left: number;
          red_team_score: number;
          blue_team_score: number;
          red_team_power_cards: number;
          blue_team_power_cards: number;
          phase: 'categoryPreSelection' | 'categorySelection' | 'playing' | 'result';
          game_history: any[];
          used_questions: any[];
          used_power_card: string | null;
          waiting_for_opponent: boolean;
          total_questions: number;
          max_questions_per_team: number;
          selected_categories: string[];
          updated_at: string;
        };
        Insert: {
          id?: string;
          room_id: string;
          current_question?: any;
          current_turn?: 'red' | 'blue';
          time_left?: number;
          red_team_score?: number;
          blue_team_score?: number;
          red_team_power_cards?: number;
          blue_team_power_cards?: number;
          phase?: 'categoryPreSelection' | 'categorySelection' | 'playing' | 'result';
          game_history?: any[];
          used_questions?: any[];
          used_power_card?: string | null;
          waiting_for_opponent?: boolean;
          total_questions?: number;
          max_questions_per_team?: number;
          selected_categories?: string[];
          updated_at?: string;
        };
        Update: {
          id?: string;
          room_id?: string;
          current_question?: any;
          current_turn?: 'red' | 'blue';
          time_left?: number;
          red_team_score?: number;
          blue_team_score?: number;
          red_team_power_cards?: number;
          blue_team_power_cards?: number;
          phase?: 'categoryPreSelection' | 'categorySelection' | 'playing' | 'result';
          game_history?: any[];
          used_questions?: any[];
          used_power_card?: string | null;
          waiting_for_opponent?: boolean;
          total_questions?: number;
          max_questions_per_team?: number;
          selected_categories?: string[];
          updated_at?: string;
        };
      };
      admin_categories: {
        Row: {
          id: string;
          name_ar: string;
          name_en: string | null;
          icon: string;
          color: string;
          description: string | null;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name_ar: string;
          name_en?: string | null;
          icon?: string;
          color?: string;
          description?: string | null;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name_ar?: string;
          name_en?: string | null;
          icon?: string;
          color?: string;
          description?: string | null;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      admin_questions: {
        Row: {
          id: string;
          category_id: string;
          question: string;
          type: 'multiple_choice' | 'text';
          options: string[];
          correct_answer: any;
          difficulty: 'easy' | 'medium' | 'hard';
          difficulty_level: number;
          points: number;
          explanation: string | null;
          notes: string | null;
          tags: string[];
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          category_id: string;
          question: string;
          type?: 'multiple_choice' | 'text';
          options: string[];
          correct_answer: any;
          difficulty: 'easy' | 'medium' | 'hard';
          difficulty_level?: number;
          points?: number;
          explanation?: string | null;
          notes?: string | null;
          tags?: string[];
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          category_id?: string;
          question?: string;
          type?: 'multiple_choice' | 'text';
          options?: string[];
          correct_answer?: any;
          difficulty?: 'easy' | 'medium' | 'hard';
          difficulty_level?: number;
          points?: number;
          explanation?: string | null;
          notes?: string | null;
          tags?: string[];
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      admin_activity: {
        Row: {
          id: string;
          type: 'create' | 'update' | 'delete';
          entity: 'category' | 'question';
          entity_name: string;
          entity_id: string | null;
          details: string | null;
          user_info: any;
          created_at: string;
        };
        Insert: {
          id?: string;
          type: 'create' | 'update' | 'delete';
          entity: 'category' | 'question';
          entity_name: string;
          entity_id?: string | null;
          details?: string | null;
          user_info?: any;
          created_at?: string;
        };
        Update: {
          id?: string;
          type?: 'create' | 'update' | 'delete';
          entity?: 'category' | 'question';
          entity_name?: string;
          entity_id?: string | null;
          details?: string | null;
          user_info?: any;
          created_at?: string;
        };
      };
    };
  };
};