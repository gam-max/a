import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

/**
 * سياق المصادقة
 * يوفر معلومات المستخدم الحالي وعمليات تسجيل الدخول والخروج والتسجيل.
 */
interface AuthContextValue {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any | null }>;
  signUp: (email: string, password: string, username?: string) => Promise<{ error: any | null }>;
  signOut: () => Promise<{ error: any | null }>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Monitor authentication state
  useEffect(() => {
    let ignore = false;
    const initAuth = async () => {
      try {
        const {
          data: { session },
          error
        } = await supabase!.auth.getSession();
        if (!ignore) {
          if (error) {
            console.error('❌ خطأ في جلب الجلسة الحالية:', error);
          }
          setUser(session?.user ?? null);
          setLoading(false);
        }
      } catch (err) {
        console.error('❌ خطأ في تهيئة المصادقة:', err);
        if (!ignore) setLoading(false);
      }
    };
    initAuth();

    const { data: listener } = supabase!.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    return () => {
      ignore = true;
      listener.subscription.unsubscribe();
    };
  }, []);

  /**
   * تسجيل الدخول عبر البريد الإلكتروني وكلمة المرور
   */
  const signIn = async (email: string, password: string) => {
    const { error } = await supabase!.auth.signInWithPassword({ email, password });
    if (error) {
      console.error('❌ خطأ في تسجيل الدخول:', error);
    }
    return { error };
  };

  /**
   * التسجيل بحساب جديد
   * يمكن تحديد اسم مستخدم اختياري يُخزن في جدول player_profiles
   */
  const signUp = async (email: string, password: string, username?: string) => {
    const { data, error } = await supabase!.auth.signUp({ email, password });
    if (error) {
      console.error('❌ خطأ في إنشاء الحساب:', error);
      return { error };
    }
    const userId = data.user?.id;
    // إدراج ملف شخصي في جدول player_profiles إذا تم توفير اسم مستخدم
    if (userId && username) {
      try {
        const { error: profileError } = await supabase!
          .from('player_profiles')
          .insert({ user_id: userId, username });
        if (profileError) {
          console.error('❌ خطأ في إنشاء ملف اللاعب:', profileError);
        }
      } catch (err) {
        console.error('❌ استثناء أثناء إنشاء ملف اللاعب:', err);
      }
    }
    return { error: null };
  };

  /**
   * تسجيل الخروج
   */
  const signOut = async () => {
    const { error } = await supabase!.auth.signOut();
    if (error) {
      console.error('❌ خطأ في تسجيل الخروج:', error);
    }
    return { error };
  };

  const value: AuthContextValue = {
    user,
    loading,
    signIn,
    signUp,
    signOut
  };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextValue => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};