import React, { useState, useEffect } from 'react';
import { Users, Plus, RefreshCw, Globe, Trophy, Clock, Activity, Wifi } from 'lucide-react';
import { GameRoom, LobbyState } from '../types/lobby';
import { supabase } from '../lib/supabase';
import { v4 as uuidv4 } from 'uuid';

interface LobbyMenuProps {
  lobbyState: LobbyState;
  onCreateRoom: (roomName: string) => void;
  onJoinRoom: (roomId: string) => void;
  onSetPlayerName: (name: string) => void;
  onRefreshRooms: () => void;
  onClearEmptyRooms: () => Promise<void>;
}

const LobbyMenu: React.FC<LobbyMenuProps> = ({
  lobbyState,
  onCreateRoom,
  onJoinRoom,
  onSetPlayerName,
  onRefreshRooms,
  onClearEmptyRooms
}) => {
  const [roomName, setRoomName] = useState('');
  const [playerName, setPlayerName] = useState(lobbyState.playerName);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [onlineStatus, setOnlineStatus] = useState<'connected' | 'connecting' | 'disconnected'>('connecting');
  const [isClearing, setIsClearing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // مراقبة حالة الاتصال
  useEffect(() => {
    if (!supabase) {
      setOnlineStatus('disconnected');
      return;
    }

    // فحص الاتصال
    const checkConnection = async () => {
      try {
        const { error } = await supabase.from('game_rooms').select('count').limit(1);
        if (error) throw error;
        setOnlineStatus('connected');
      } catch (error) {
        console.error('Connection error:', error);
        setOnlineStatus('disconnected');
      }
    };

    checkConnection();
    const interval = setInterval(checkConnection, 30000); // فحص كل 30 ثانية

    return () => clearInterval(interval);
  }, []);

  // مراقبة تغييرات الغرف للإشعار بالحذف
  useEffect(() => {
    const prevRooms = JSON.parse(localStorage.getItem('prev-rooms') || '[]');
    
    // التحقق من الغرف المحذوفة
    const deletedRooms = prevRooms.filter((prevRoom: any) => 
      !lobbyState.rooms.find(currentRoom => currentRoom.id === prevRoom.id)
    );
    
    // التحقق من الغرف الجديدة
    const newRooms = lobbyState.rooms.filter(currentRoom => 
      !prevRooms.find((prevRoom: any) => prevRoom.id === currentRoom.id)
    );
    
    // التحقق من تغييرات عدد اللاعبين
    const updatedRooms = lobbyState.rooms.filter(currentRoom => {
      const prevRoom = prevRooms.find((prev: any) => prev.id === currentRoom.id);
      return prevRoom && prevRoom.current_players !== currentRoom.current_players;
    });
    
    // إشعارات للغرف المحذوفة
    deletedRooms.forEach((room: any) => {
      console.log(`🗑️ تم حذف الغرفة: ${room.name}`);
      // يمكن إضافة إشعار مرئي هنا
    });
    
    // إشعارات للغرف الجديدة
    newRooms.forEach((room: any) => {
      console.log(`🆕 غرفة جديدة: ${room.name}`);
      // يمكن إضافة إشعار مرئي هنا
    });
    
    // إشعارات لتحديث عدد اللاعبين
    updatedRooms.forEach((room: any) => {
      const prevRoom = prevRooms.find((prev: any) => prev.id === room.id);
      if (prevRoom) {
        console.log(`👥 تحديث عدد اللاعبين في ${room.name}: ${prevRoom.current_players} → ${room.current_players}`);
      }
    });
    
    // حفظ الحالة الحالية
    localStorage.setItem('prev-rooms', JSON.stringify(lobbyState.rooms));
  }, [lobbyState.rooms]);

  // مراقبة التحديثات المباشرة
  useEffect(() => {
    let notificationTimeout: NodeJS.Timeout;
    
    if (lobbyState.rooms.length > 0) {
      // إظهار مؤشر التحديث
      const indicator = document.getElementById('live-update-indicator');
      if (indicator) {
        indicator.classList.add('animate-pulse');
        
        // إزالة المؤشر بعد ثانيتين
        notificationTimeout = setTimeout(() => {
          indicator.classList.remove('animate-pulse');
        }, 2000);
      }
    }
    
    return () => {
      if (notificationTimeout) {
        clearTimeout(notificationTimeout);
      }
    };
  }, [lobbyState.rooms]);
  
  const handleSetPlayerName = (e: React.FormEvent) => {
    e.preventDefault();
    if (playerName.trim()) {
      onSetPlayerName(playerName.trim());
    }
  };

  const handleCreateRoom = (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('🎮 بدء إنشاء غرفة من الواجهة...', { 
      roomName: roomName.trim(), 
      playerName: lobbyState.playerName,
      formValid: !!(roomName.trim() && lobbyState.playerName)
    });
    
    if (roomName.trim() && lobbyState.playerName) {
      onCreateRoom(roomName.trim());
      setRoomName('');
      setShowCreateForm(false);
    } else {
      console.warn('⚠️ لا يمكن إنشاء الغرفة - بيانات ناقصة:', { 
        roomName: roomName.trim(), 
        playerName: lobbyState.playerName,
        roomNameEmpty: !roomName.trim(),
        playerNameEmpty: !lobbyState.playerName
      });
      alert('يرجى التأكد من إدخال اسم الغرفة واسم اللاعب');
    }
  };

  const handleClearEmptyRooms = async () => {
    setIsClearing(true);
    try {
      await onClearEmptyRooms();
      alert('تم حذف جميع الغرف الفارغة بنجاح!');
    } catch (error) {
      console.error('Error clearing empty rooms:', error);
      alert('حدث خطأ أثناء حذف الغرف');
    } finally {
      setIsClearing(false);
    }
  };

  const handleDeleteSpecificRooms = async () => {
    if (!supabase) {
      alert('يتطلب إعداد Supabase أولاً');
      return;
    }

    const confirmed = window.confirm(
      `هل أنت متأكد من حذف جميع الغرف؟\n\nسيتم حذف ${lobbyState.rooms.length} غرفة\n\nهذا الإجراء لا يمكن التراجع عنه.`
    );
    
    if (!confirmed) return;

    setIsDeleting(true);
    let deletedCount = 0;
    
    try {
      console.log('🗑️ بدء حذف جميع الغرف...', lobbyState.rooms.length, 'غرفة');
      
      for (const room of lobbyState.rooms) {
        try {
          console.log(`🗑️ حذف الغرفة: "${room.name}" (${room.id})`);
          
          // حذف حالة اللعبة أولاً
          await supabase
            .from('game_state')
            .delete()
            .eq('room_id', room.id);
          
          // حذف اللاعبين
          await supabase
            .from('game_players')
            .delete()
            .eq('room_id', room.id);
          
          // حذف الغرفة
          const { error: deleteError } = await supabase
            .from('game_rooms')
            .delete()
            .eq('id', room.id);
          
          if (deleteError) {
            console.error(`خطأ في حذف الغرفة "${room.name}":`, deleteError);
          } else {
            console.log(`✅ تم حذف الغرفة: "${room.name}"`);
            deletedCount++;
          }
        } catch (error) {
          console.error(`خطأ في معالجة الغرفة "${room.name}":`, error);
        }
      }
      
      // تحديث قائمة الغرف
      await onRefreshRooms();
      
      alert(`تم حذف ${deletedCount} غرفة بنجاح!`);
      console.log(`🎉 تم حذف ${deletedCount} غرفة من أصل ${lobbyState.rooms.length} غرفة`);
      
    } catch (error) {
      console.error('خطأ عام في حذف الغرف:', error);
      alert(`حدث خطأ أثناء حذف الغرف: ${error.message || error}`);
    } finally {
      setIsDeleting(false);
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const now = new Date();
    const created = new Date(dateString);
    const diffInMinutes = Math.floor((now.getTime() - created.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'الآن';
    if (diffInMinutes < 60) return `${diffInMinutes} دقيقة`;
    const hours = Math.floor(diffInMinutes / 60);
    if (hours < 24) return `${hours} ساعة`;
    const days = Math.floor(hours / 24);
    return `${days} يوم`;
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-6xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <Globe className="w-16 h-16 text-blue-400 mr-4" />
            <h1 className="text-6xl font-bold text-white">
              لوبي المباريات
            </h1>
            <Globe className="w-16 h-16 text-blue-400 ml-4" />
          </div>
          <p className="text-xl text-blue-200">
            انضم إلى مباراة أو أنشئ غرفة جديدة للعب مع الأصدقاء
          </p>
        </div>

        {/* Player Name Setup */}
        {!lobbyState.playerName && (
          <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 mb-8 border border-white/20">
            <h2 className="text-3xl font-bold text-white text-center mb-6">أدخل اسمك</h2>
            <form onSubmit={handleSetPlayerName} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="text"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                placeholder="اسمك المستعار"
                className="flex-1 px-6 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:bg-white/30 transition-all"
                maxLength={20}
                required
              />
              <button
                type="submit"
                className="px-8 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-blue-600 transition-all duration-300 transform hover:scale-105"
              >
                تأكيد
              </button>
            </form>
          </div>
        )}

        {lobbyState.playerName && (
          <>
            {/* Welcome Message */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-4">
                <div className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full border border-purple-400/30">
                  <Users className="w-5 h-5 text-purple-400 mr-2" />
                  <span className="text-white">مرحباً، {lobbyState.playerName}</span>
                </div>
                
                {/* مؤشر حالة الاتصال */}
                <div className={`inline-flex items-center px-4 py-2 rounded-full text-sm ${
                  onlineStatus === 'connected' ? 'bg-green-500/20 text-green-400 border border-green-400/30' :
                  onlineStatus === 'connecting' ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-400/30' :
                  'bg-red-500/20 text-red-400 border border-red-400/30'
                }`}>
                  <div className={`w-2 h-2 rounded-full mr-2 ${
                    onlineStatus === 'connected' ? 'bg-green-400 animate-pulse' :
                    onlineStatus === 'connecting' ? 'bg-yellow-400 animate-pulse' :
                    'bg-red-400'
                  }`} />
                  {onlineStatus === 'connected' ? 'متصل' :
                   onlineStatus === 'connecting' ? 'جاري الاتصال' : 'غير متصل'}
                </div>
              </div>
            </div>

            {/* Live Updates Indicator */}
            <div className="text-center mb-8" id="live-update-indicator">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/10 rounded-full border border-blue-400/30 transition-all duration-300">
                <Activity className="w-4 h-4 text-blue-400 animate-pulse" />
                <span className="text-blue-300 text-sm">
                  التحديثات المباشرة مفعلة • {lobbyState.rooms.length} غرفة متاحة • 
                  {lobbyState.rooms.reduce((total, room) => total + room.current_players, 0)} لاعب نشط
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8 max-w-2xl mx-auto">
              <button
                onClick={() => setShowCreateForm(!showCreateForm)}
                className="flex-1 px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-emerald-600 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-3"
              >
                <Plus className="w-6 h-6" />
                إنشاء غرفة جديدة
              </button>
              
              <button
                onClick={onRefreshRooms}
                className="px-8 py-4 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold rounded-xl hover:from-blue-600 hover:to-cyan-600 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-3"
              >
                <RefreshCw className="w-6 h-6" />
                تحديث وتنظيف
              </button>
              
              <button
                onClick={() => {
                  // تنظيف البيانات المحلية أولاً
                  localStorage.removeItem('prev-rooms');
                  const testNames = ['أحمد', 'فاطمة', 'محمد', 'عائشة', 'علي', 'زينب'];
                  const randomName = testNames[Math.floor(Math.random() * testNames.length)] + '_' + Math.floor(Math.random() * 1000);
                  onSetPlayerName(randomName);
                }}
                className="px-6 py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-xl hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2"
                title="وضع المطور - اسم عشوائي"
              >
                🧪 اختبار
              </button>
              
              <button
                onClick={handleDeleteSpecificRooms}
                disabled={isDeleting}
                className="px-6 py-4 bg-gradient-to-r from-red-500 to-red-600 text-white font-bold rounded-xl hover:from-red-600 hover:to-red-700 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 flex items-center justify-center gap-2"
                title="حذف جميع الغرف"
              >
                {isDeleting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    جاري الحذف...
                  </>
                ) : (
                  <>
                    🗑️ حذف جميع الغرف
                  </>
                )}
              </button>
            </div>

            {/* Create Room Form */}
            {showCreateForm && (
              <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 mb-8 border border-white/20">
                <h3 className="text-2xl font-bold text-white text-center mb-6">إنشاء غرفة جديدة</h3>
                <form onSubmit={handleCreateRoom} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                  <input
                    type="text"
                    value={roomName}
                    onChange={(e) => setRoomName(e.target.value)}
                    placeholder="اسم الغرفة"
                    className="flex-1 px-6 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-green-400 focus:bg-white/30 transition-all"
                    maxLength={30}
                    required
                  />
                  <button
                    type="submit"
                    className="px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-emerald-600 transition-all duration-300 transform hover:scale-105"
                  >
                    إنشاء
                  </button>
                </form>
              </div>
            )}

            {/* Available Rooms */}
            <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-3xl font-bold text-white">الغرف المتاحة</h3>
                <div className="text-white/70">
                  {lobbyState.rooms.length} غرفة متاحة
                </div>
              </div>

              {lobbyState.rooms.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-16 h-16 text-white/30 mx-auto mb-4" />
                  <p className="text-white/70 text-xl">لا توجد غرف متاحة حالياً</p>
                  <p className="text-white/50 mt-2">كن أول من ينشئ غرفة!</p>
                  {onlineStatus === 'disconnected' && (
                    <p className="text-red-400 mt-4 text-sm">
                      ⚠️ تحقق من اتصال الإنترنت أو إعدادات Supabase
                    </p>
                  )}
                  
                  {/* مؤشر التحديث المباشر */}
                  <div className="mt-6 inline-flex items-center gap-2 px-4 py-2 bg-green-500/10 rounded-full border border-green-400/30">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-green-300 text-sm">
                      مراقبة مباشرة للغرف الجديدة...
                    </span>
                  </div>
                  
                  {/* نصائح للمطورين */}
                  <div className="mt-6 bg-yellow-500/10 border border-yellow-400/30 rounded-xl p-4 max-w-md mx-auto">
                    <h4 className="text-yellow-300 font-bold mb-2">💡 نصائح للاختبار:</h4>
                    <div className="text-yellow-200 text-sm space-y-1">
                      <p>• أنشئ غرفة في تبويب واحد</p>
                      <p>• انضم إليها من تبويب آخر</p>
                      <p>• شاهد تحديث عدد اللاعبين مباشرة</p>
                      <p>• جرب مغادرة المنشئ لحذف الغرفة</p>
                      <p>• اضغط "مسح الغرف الفارغة" لحذف جميع الغرف الوهمية</p>
                    </div>
                  </div>
                  
                  {/* زر مسح سريع */}
                  <div className="mt-6">
                    <button
                      onClick={handleClearEmptyRooms}
                      disabled={isClearing}
                      className="px-8 py-3 bg-gradient-to-r from-red-500 to-pink-500 text-white font-bold rounded-xl hover:from-red-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 disabled:opacity-50"
                    >
                      {isClearing ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin inline mr-2" />
                          جاري المسح...
                        </>
                      ) : (
                        <>
                          🧹 مسح جميع الغرف الفارغة الآن
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {lobbyState.rooms.map((room) => (
                    <div
                      key={room.id}
                      className="bg-gradient-to-br from-white/10 to-white/5 rounded-2xl p-6 border border-white/20 hover:border-white/40 transition-all duration-300 transform hover:scale-105 relative animate-fade-in"
                    >
                      {/* مؤشر النشاط المباشر */}
                      <div className="absolute top-3 right-3 flex items-center gap-2">
                        {room.current_players > 0 ? (
                          <div className="flex items-center gap-1">
                            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" title="غرفة نشطة" />
                            <span className="text-xs text-green-300">نشط</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1">
                            <div className="w-3 h-3 bg-gray-400 rounded-full" title="غرفة فارغة" />
                            <span className="text-xs text-gray-400">فارغة</span>
                          </div>
                        )}
                        <div className="flex items-center gap-1">
                          <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" title="تحديث مباشر" />
                          <span className="text-xs text-blue-300">مباشر</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="text-xl font-bold text-white truncate">{room.name}</h4>
                        <div className={`px-3 py-1 rounded-full text-xs font-bold ${
                          room.status === 'waiting' ? 'bg-green-500/20 text-green-400' :
                          room.status === 'playing' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {room.status === 'waiting' ? 'في الانتظار' :
                           room.status === 'playing' ? 'يلعب' : 'انتهت'}
                        </div>
                      </div>

                      <div className="space-y-3 mb-6">
                        <div className="flex items-center text-white/70">
                          <Users className="w-4 h-4 mr-2" />
                          <span className="flex items-center gap-2">
                            {room.current_players}/{room.max_players} لاعب
                            {room.current_players > 0 ? (
                              <div className="flex items-center gap-1">
                                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                                <span className="text-xs text-green-300">نشط</span>
                              </div>
                            ) : (
                              <div className="flex items-center gap-1">
                                <div className="w-2 h-2 bg-red-400 rounded-full" />
                                <span className="text-xs text-red-300">فارغة</span>
                              </div>
                            )}
                          </span>
                        </div>
                        
                        <div className="flex items-center text-white/70">
                          <Trophy className="w-4 h-4 mr-2" />
                          <span>المضيف: {room.host_name}</span>
                        </div>
                        
                        <div className="flex items-center text-white/70">
                          <Clock className="w-4 h-4 mr-2" />
                          <span>منذ {formatTimeAgo(room.created_at)}</span>
                        </div>
                      </div>

                      <button
                        onClick={() => onJoinRoom(room.id)}
                        disabled={room.status !== 'waiting' || room.current_players >= room.max_players}
                        className={`w-full px-6 py-3 text-white font-bold rounded-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none ${
                          room.current_players === 0 
                            ? 'bg-gradient-to-r from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700' 
                            : 'bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600'
                        }`}
                      >
                        {room.status !== 'waiting' ? 'غير متاح' :
                         room.current_players >= room.max_players ? 'ممتلئة' : 
                         room.current_players === 0 ? 'غرفة فارغة' : 'انضم'}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default LobbyMenu;