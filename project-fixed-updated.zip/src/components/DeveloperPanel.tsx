import React, { useState } from 'react';
import { Settings, Code, Database, Palette, Plus, Save } from 'lucide-react';

interface DeveloperPanelProps {
  onAddQuestion?: (question: any) => void;
  onUpdateTheme?: (theme: any) => void;
}

const DeveloperPanel: React.FC<DeveloperPanelProps> = ({ onAddQuestion, onUpdateTheme }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'questions' | 'theme' | 'database'>('questions');
  
  const [newQuestion, setNewQuestion] = useState({
    question: '',
    options: ['', '', '', ''],
    correctAnswer: 0,
    category: 'التاريخ',
    difficulty: 'easy' as 'easy' | 'medium' | 'hard',
    points: 10
  });

  const handleAddQuestion = () => {
    if (newQuestion.question && newQuestion.options.every(opt => opt.trim())) {
      onAddQuestion?.(newQuestion);
      setNewQuestion({
        question: '',
        options: ['', '', '', ''],
        correctAnswer: 0,
        category: 'التاريخ',
        difficulty: 'easy',
        points: 10
      });
      alert('تم إضافة السؤال بنجاح!');
    } else {
      alert('يرجى ملء جميع الحقول');
    }
  };

  const updateOption = (index: number, value: string) => {
    const newOptions = [...newQuestion.options];
    newOptions[index] = value;
    setNewQuestion(prev => ({ ...prev, options: newOptions }));
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 z-50"
        title="لوحة المطور"
      >
        <Code className="w-6 h-6" />
      </button>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/20">
          <div className="flex items-center gap-3">
            <Settings className="w-6 h-6 text-purple-400" />
            <h2 className="text-2xl font-bold text-white">لوحة المطور</h2>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="w-8 h-8 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center hover:bg-red-500/30 transition-all"
          >
            ×
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/20">
          {[
            { id: 'questions', label: 'إضافة أسئلة', icon: Plus },
            { id: 'theme', label: 'تخصيص التصميم', icon: Palette },
            { id: 'database', label: 'قاعدة البيانات', icon: Database }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 px-6 py-4 flex items-center justify-center gap-2 transition-all ${
                  activeTab === tab.id
                    ? 'bg-purple-500/20 text-purple-300 border-b-2 border-purple-400'
                    : 'text-white/70 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className="w-5 h-5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {activeTab === 'questions' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">إضافة سؤال جديد</h3>
              
              {/* Question Input */}
              <div>
                <label className="block text-white/80 mb-2">السؤال:</label>
                <textarea
                  value={newQuestion.question}
                  onChange={(e) => setNewQuestion(prev => ({ ...prev, question: e.target.value }))}
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400"
                  placeholder="اكتب السؤال هنا..."
                  rows={3}
                />
              </div>

              {/* Options */}
              <div>
                <label className="block text-white/80 mb-2">الخيارات:</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {newQuestion.options.map((option, index) => (
                    <div key={index} className="relative">
                      <input
                        type="text"
                        value={option}
                        onChange={(e) => updateOption(index, e.target.value)}
                        className={`w-full p-3 bg-white/10 border rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400 ${
                          newQuestion.correctAnswer === index ? 'border-green-400' : 'border-white/20'
                        }`}
                        placeholder={`الخيار ${String.fromCharCode(65 + index)}`}
                      />
                      <button
                        onClick={() => setNewQuestion(prev => ({ ...prev, correctAnswer: index }))}
                        className={`absolute left-2 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-full border-2 flex items-center justify-center text-xs font-bold ${
                          newQuestion.correctAnswer === index
                            ? 'bg-green-500 border-green-400 text-white'
                            : 'border-white/40 text-white/60 hover:border-green-400'
                        }`}
                        title="الإجابة الصحيحة"
                      >
                        ✓
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Category and Difficulty */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-white/80 mb-2">الفئة:</label>
                  <select
                    value={newQuestion.category}
                    onChange={(e) => setNewQuestion(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400"
                  >
                    <option value="التاريخ">التاريخ</option>
                    <option value="الجغرافيا">الجغرافيا</option>
                    <option value="العلوم">العلوم</option>
                    <option value="التكنولوجيا">التكنولوجيا</option>
                    <option value="الأدب">الأدب</option>
                    <option value="الرياضة">الرياضة</option>
                  </select>
                </div>

                <div>
                  <label className="block text-white/80 mb-2">الصعوبة:</label>
                  <select
                    value={newQuestion.difficulty}
                    onChange={(e) => setNewQuestion(prev => ({ 
                      ...prev, 
                      difficulty: e.target.value as 'easy' | 'medium' | 'hard',
                      points: e.target.value === 'easy' ? 10 : e.target.value === 'medium' ? 20 : 30
                    }))}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400"
                  >
                    <option value="easy">سهل (10 نقاط)</option>
                    <option value="medium">متوسط (20 نقطة)</option>
                    <option value="hard">صعب (30 نقطة)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-white/80 mb-2">النقاط:</label>
                  <input
                    type="number"
                    value={newQuestion.points}
                    onChange={(e) => setNewQuestion(prev => ({ ...prev, points: parseInt(e.target.value) || 10 }))}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400"
                    min="1"
                    max="100"
                  />
                </div>
              </div>

              {/* Add Button */}
              <button
                onClick={handleAddQuestion}
                className="w-full px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-emerald-600 transition-all duration-300 flex items-center justify-center gap-2"
              >
                <Save className="w-5 h-5" />
                إضافة السؤال
              </button>
            </div>
          )}

          {activeTab === 'theme' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">تخصيص التصميم</h3>
              <div className="bg-yellow-500/10 border border-yellow-400/30 rounded-xl p-4">
                <p className="text-yellow-300">
                  🎨 يمكنك تعديل الألوان والتصميم من خلال ملفات CSS و Tailwind
                </p>
                <p className="text-yellow-200 text-sm mt-2">
                  راجع ملف src/index.css للتخصيص المتقدم
                </p>
              </div>
            </div>
          )}

          {activeTab === 'database' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">إدارة قاعدة البيانات</h3>
              <div className="bg-blue-500/10 border border-blue-400/30 rounded-xl p-4">
                <p className="text-blue-300">
                  🗄️ لإدارة قاعدة البيانات، اذهب إلى لوحة تحكم Supabase
                </p>
                <p className="text-blue-200 text-sm mt-2">
                  يمكنك عرض وتعديل البيانات من SQL Editor
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DeveloperPanel;