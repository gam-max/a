import React, { useState } from 'react';
import { Users, Trophy, Play, UserPlus } from 'lucide-react';
import { GameState } from '../types/game';

interface StartScreenProps {
  gameState: GameState;
  onJoinGame: (playerName: string) => void;
  onStartGame: () => void;
}

const StartScreen: React.FC<StartScreenProps> = ({ gameState, onJoinGame, onStartGame }) => {
  const [playerName, setPlayerName] = useState('');

  const handleJoinGame = (e: React.FormEvent) => {
    e.preventDefault();
    if (playerName.trim()) {
      onJoinGame(playerName.trim());
      setPlayerName('');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-6xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <Trophy className="w-16 h-16 text-yellow-400 mr-4" />
            <h1 className="text-6xl font-bold text-white">
              تحدي الفريقين
            </h1>
            <Trophy className="w-16 h-16 text-yellow-400 ml-4" />
          </div>
          <p className="text-xl text-blue-200">
            مسابقة تفاعلية مثيرة بين الفريق الأحمر والفريق الأزرق
          </p>
        </div>

        {/* Join Game Form */}
        <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 mb-8 border border-white/20">
          <h2 className="text-3xl font-bold text-white text-center mb-6">انضم إلى اللعبة</h2>
          
          <form onSubmit={handleJoinGame} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="text"
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
              placeholder="أدخل اسمك المستعار"
              className="flex-1 px-6 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:bg-white/30 transition-all"
              maxLength={20}
            />
            <button
              type="submit"
              className="px-8 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-blue-600 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2"
            >
              <UserPlus className="w-5 h-5" />
              انضم
            </button>
          </form>
        </div>

        {/* Teams Display */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* Red Team */}
          <div className="bg-gradient-to-br from-red-500/20 to-red-700/20 backdrop-blur-md rounded-3xl p-8 border border-red-400/30">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-red-400">الفريق الأحمر</h3>
              <p className="text-red-200">{gameState.redTeam.players.length} لاعب</p>
            </div>
            
            <div className="space-y-3">
              {gameState.redTeam.players.map((player, index) => (
                <div key={player.id} className="bg-red-500/30 rounded-xl p-3 text-center">
                  <span className="text-white font-semibold">{player.name}</span>
                  {index === 0 && (
                    <span className="text-yellow-300 text-sm ml-2">(القائد)</span>
                  )}
                </div>
              ))}
              {gameState.redTeam.players.length === 0 && (
                <div className="text-red-200 text-center py-8">
                  في انتظار اللاعبين...
                </div>
              )}
            </div>
          </div>

          {/* Blue Team */}
          <div className="bg-gradient-to-br from-blue-500/20 to-blue-700/20 backdrop-blur-md rounded-3xl p-8 border border-blue-400/30">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-blue-400">الفريق الأزرق</h3>
              <p className="text-blue-200">{gameState.blueTeam.players.length} لاعب</p>
            </div>
            
            <div className="space-y-3">
              {gameState.blueTeam.players.map((player, index) => (
                <div key={player.id} className="bg-blue-500/30 rounded-xl p-3 text-center">
                  <span className="text-white font-semibold">{player.name}</span>
                  {index === 0 && (
                    <span className="text-yellow-300 text-sm ml-2">(القائد)</span>
                  )}
                </div>
              ))}
              {gameState.blueTeam.players.length === 0 && (
                <div className="text-blue-200 text-center py-8">
                  في انتظار اللاعبين...
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Start Game Button */}
        <div className="text-center">
          <button
            onClick={onStartGame}
            disabled={gameState.redTeam.players.length === 0 || gameState.blueTeam.players.length === 0}
            className="px-12 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-xl rounded-2xl hover:from-purple-700 hover:to-pink-700 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-3 mx-auto"
          >
            <Play className="w-6 h-6" />
            ابدأ اللعبة
          </button>
          
          {(gameState.redTeam.players.length === 0 || gameState.blueTeam.players.length === 0) && (
            <p className="text-yellow-300 mt-4">
              يجب أن يكون هناك لاعب واحد على الأقل في كل فريق لبدء اللعبة
            </p>
          )}
        </div>

        {/* Game Rules */}
        <div className="mt-12 bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
          <h3 className="text-2xl font-bold text-white text-center mb-4">قواعد اللعبة</h3>
          
          {/* نظام الأسئلة الذكي */}
          <div className="mb-6 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-xl p-4 border border-purple-400/20">
            <h4 className="font-semibold text-purple-300 mb-2 flex items-center gap-2">
              🧠 نظام الأسئلة الذكي:
            </h4>
            <ul className="space-y-1 text-sm text-purple-200">
              <li>• أسئلة جديدة ومختلفة في كل مرة تلعب فيها</li>
              <li>• تجنب تكرار الأسئلة التي رأيتها مسبقاً</li>
              <li>• اختيار عشوائي ذكي من بنك الأسئلة</li>
              <li>• تجربة متجددة دائماً</li>
            </ul>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6 text-white/80">
            <div>
              <h4 className="font-semibold text-blue-300 mb-2">نظام الجولات:</h4>
              <ul className="space-y-1 text-sm">
                <li>• يتناوب الفريقان في الإجابة على الأسئلة</li>
                <li>• 15 ثانية لكل سؤال</li>
                <li>• 10 نقاط للإجابة الصحيحة</li>
                <li>• أسئلة مختلفة في كل جولة</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-green-300 mb-2">كروت المساعدة:</h4>
              <ul className="space-y-1 text-sm">
                <li>• حذف إجابتين (50/50)</li>
                <li>• تبديل السؤال</li>
                <li>• سرقة الدور</li>
                <li>• وقت إضافي</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StartScreen;