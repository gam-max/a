import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
  errorInfo?: ErrorInfo;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('🚨 Error Boundary اصطاد خطأ:', error, errorInfo);
    this.setState({ error, errorInfo });
  }

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
          <div className="max-w-2xl w-full">
            <div className="bg-red-500/20 backdrop-blur-md rounded-3xl p-8 border border-red-400/30 text-center">
              <div className="flex items-center justify-center mb-6">
                <AlertTriangle className="w-16 h-16 text-red-400" />
              </div>
              
              <h1 className="text-3xl font-bold text-red-400 mb-4">
                حدث خطأ غير متوقع
              </h1>
              
              <p className="text-red-200 mb-6">
                عذراً، حدث خطأ في التطبيق. يرجى المحاولة مرة أخرى.
              </p>

              {/* معلومات الخطأ للمطورين */}
              {this.state.error && (
                <div className="bg-black/30 rounded-xl p-4 mb-6 text-left">
                  <h3 className="text-red-300 font-bold mb-2">تفاصيل الخطأ:</h3>
                  <pre className="text-red-200 text-sm overflow-auto max-h-32">
                    {this.state.error.message}
                  </pre>
                  {this.state.errorInfo && (
                    <details className="mt-2">
                      <summary className="text-red-300 cursor-pointer">Stack Trace</summary>
                      <pre className="text-red-200 text-xs mt-2 overflow-auto max-h-32">
                        {this.state.errorInfo.componentStack}
                      </pre>
                    </details>
                  )}
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => window.location.reload()}
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold rounded-xl hover:from-blue-600 hover:to-cyan-600 transition-all duration-300"
                >
                  <RefreshCw className="w-5 h-5" />
                  إعادة تحميل الصفحة
                </button>
                
                <button
                  onClick={() => {
                    this.setState({ hasError: false, error: undefined, errorInfo: undefined });
                    window.history.pushState({}, '', '/');
                    window.location.reload();
                  }}
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-xl hover:from-purple-600 hover:to-pink-600 transition-all duration-300"
                >
                  <Home className="w-5 h-5" />
                  العودة للصفحة الرئيسية
                </button>
              </div>

              {/* نصائح للمستخدم */}
              <div className="mt-6 bg-blue-500/10 border border-blue-400/30 rounded-xl p-4">
                <h4 className="text-blue-300 font-bold mb-2">💡 نصائح لحل المشكلة:</h4>
                <div className="text-blue-200 text-sm space-y-1">
                  <p>• تأكد من اتصال الإنترنت</p>
                  <p>• امسح cache المتصفح (Ctrl+Shift+R)</p>
                  <p>• جرب في نافذة خاصة (Incognito)</p>
                  <p>• تحقق من إعدادات Supabase</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;