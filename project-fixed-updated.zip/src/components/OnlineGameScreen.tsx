import React, { useEffect, useState } from 'react';
import { Clock, Zap, RefreshCw, ArrowRightLeft, Plus, Users, AlertCircle, Trophy, Volume2, VolumeX, BookOpen, Check, X, Play, Bot } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { OnlineGameState, GamePlayer } from '../types/lobby';
import { useGameCategories } from '../hooks/useGameCategories';
import { useQuestionManager } from '../hooks/useQuestionManager';
import { getIconComponent } from '../lib/icons';
import { PowerCard } from '../types/game';
// استيراد شاشة النتائج الخاصة باللعب المحلي لاستخدامها فى الوضع الأونلاين
import ResultScreen from './ResultScreen';
import Timer from './Timer';
import GameHistory from './GameHistory';

interface OnlineGameScreenProps {
  roomId: string;
  playerId: string;
  playerName: string;
  onGameEnd: () => void;
}

const OnlineGameScreen: React.FC<OnlineGameScreenProps> = ({
  roomId,
  playerId,
  playerName,
  onGameEnd
}) => {
  const [gameState, setGameState] = useState<OnlineGameState | null>(null);
  const [players, setPlayers] = useState<GamePlayer[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [visibleOptions, setVisibleOptions] = useState<number[]>([0, 1, 2, 3]);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'disconnected' | 'reconnecting'>('connected');
  // local state for category pre-selection has been removed in favor of
  // storing the selections directly on the game_state in Supabase. The
  // selections will alternate between teams: each team picks one category
  // until the desired number of categories (currently two) is reached. When
  // selections are completed, the phase automatically advances to
  // `categorySelection`.
  //
  // لم يعد يتم استخدام selectedCategories كمخزن محلي للبيانات؛ حيث يتم جلب
  // التخصصات المختارة مباشرةً من gameState.selected_categories.
  const [showHistory, setShowHistory] = useState(false);
  
  // استخدام البيانات الأونلاين للأسئلة
  const categoryQuestions = useGameCategories(true);
  const questionManager = useQuestionManager(categoryQuestions);

  // تحميل حالة اللعبة واللاعبين
  useEffect(() => {
    console.log('🎮 تحميل شاشة اللعبة الأونلاين...', { roomId, playerId, playerName });
    
    if (!roomId || !playerId || !playerName) {
      console.error('❌ بيانات مفقودة لبدء اللعبة:', { roomId, playerId, playerName });
      return;
    }
    
    loadGameState();
    loadPlayers();

    if (!supabase) return;

    // الاشتراك في التحديثات المباشرة
    const gameSubscription = supabase
      .channel(`game-${roomId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'game_state',
        filter: `room_id=eq.${roomId}`
      }, (payload) => {
        console.log('🔄 تحديث حالة اللعبة:', payload);
        loadGameState();
      })
      .subscribe();

    const playersSubscription = supabase
      .channel(`players-${roomId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'game_players',
        filter: `room_id=eq.${roomId}`
      }, (payload) => {
        console.log('🔄 تحديث اللاعبين:', payload);
        loadPlayers();
      })
      .subscribe();

    return () => {
      gameSubscription.unsubscribe();
      playersSubscription.unsubscribe();
    };
  }, [roomId]);

  const loadGameState = async () => {
    if (!supabase) return;

    try {
      console.log('📊 جاري تحميل حالة اللعبة من قاعدة البيانات...', { roomId });
      const { data, error } = await supabase
        .from('game_state')
        .select('*')
        .eq('room_id', roomId)
        .maybeSingle();

      if (error) {
        if (error.code === '42703' || error.code === 'PGRST204') {
          console.error('❌ هيكل قاعدة البيانات غير مكتمل - يرجى تشغيل ملفات إعداد قاعدة البيانات');
        } else {
          console.error('❌ خطأ في تحميل حالة اللعبة:', error);
        }
        console.error('❌ فشل في تحميل حالة اللعبة من قاعدة البيانات:', error);
        throw error;
      }
      
      if (data) {
        console.log('✅ تم تحميل حالة اللعبة بنجاح من قاعدة البيانات:', data);
        setGameState(data);
      } else {
        console.log('⏳ لا توجد حالة لعبة محفوظة بعد - سيتم إنشاؤها عند بدء اللعبة');
        // Retry loading after a short delay
        setTimeout(() => loadGameState(), 1000);
      }
    } catch (error) {
      console.error('❌ خطأ في تحميل حالة اللعبة:', error);
    }
  };

  const loadPlayers = async () => {
    if (!supabase) return;

    try {
      console.log('👥 جاري تحميل قائمة اللاعبين من قاعدة البيانات...', { roomId });
      const { data, error } = await supabase
        .from('game_players')
        .select('*')
        .eq('room_id', roomId);

      if (error) throw error;
      console.log('✅ تم تحميل قائمة اللاعبين بنجاح:', data);
      setPlayers(data || []);
    } catch (error) {
      console.error('❌ خطأ في تحميل قائمة اللاعبين:', error);
    }
  };

  const selectCategory = async (category: string, difficulty: 'easy' | 'medium' | 'hard') => {
    if (!supabase || !gameState) return;

    // استخدام النظام الذكي لاختيار السؤال
    const selectedQuestion = questionManager.selectRandomQuestion(category, difficulty);
    
    if (!selectedQuestion) {
      console.warn(`لا توجد أسئلة متاحة في ${category} - ${difficulty}`);
      return;
    }

    // إضافة السؤال للتاريخ
    questionManager.addQuestionToHistory(selectedQuestion);

    try {
      const newUsedQuestions = [...gameState.used_questions, { category, difficulty }];
      
      const { error } = await supabase
        .from('game_state')
        .update({
          phase: 'playing',
          current_question: selectedQuestion,
          time_left: 15,
          used_power_card: null,
          used_questions: newUsedQuestions,
          total_questions: gameState.total_questions + 1
        })
        .eq('room_id', roomId);

      if (error) throw error;
      
      console.log('🎯 تم اختيار سؤال جديد في اللعبة الأونلاين:', {
        category,
        difficulty,
        questionId: selectedQuestion.id,
        question: selectedQuestion.question.substring(0, 50) + '...'
      });
    } catch (error) {
      console.error('Error selecting category:', error);
    }
  };

  const handleTimeUp = () => {
    if (!showResult && isMyTurn) {
      setShowResult(true);
      setTimeout(() => {
        answerQuestion(-1); // -1 يعني انتهى الوقت
      }, 1000);
    }
  };

  const playSound = (type: 'correct' | 'wrong' | 'timeup') => {
    if (!soundEnabled) return;
    
    // يمكن إضافة أصوات حقيقية هنا
    const audio = new Audio();
    switch (type) {
      case 'correct':
        // audio.src = '/sounds/correct.mp3';
        break;
      case 'wrong':
        // audio.src = '/sounds/wrong.mp3';
        break;
      case 'timeup':
        // audio.src = '/sounds/timeup.mp3';
        break;
    }
    // audio.play().catch(() => {}); // تجاهل أخطاء التشغيل
  };

  const answerQuestion = async (optionIndex: number) => {
    if (!supabase || !gameState || (selectedAnswer !== null && optionIndex !== -1)) return;

    setSelectedAnswer(optionIndex);
    setShowResult(true);

    const isCorrect = optionIndex !== -1 && optionIndex === gameState.current_question?.correctAnswer;
    const answer = optionIndex === -1 ? 'انتهى الوقت' : (gameState.current_question?.options[optionIndex] || '');
    const points = isCorrect ? (gameState.current_question?.points || 0) : 0;
    
    // تشغيل الصوت
    if (optionIndex === -1) {
      playSound('timeup');
    } else if (isCorrect) {
      playSound('correct');
    } else {
      playSound('wrong');
    }

    try {
      const newHistory = [...gameState.game_history, {
        question: gameState.current_question.question,
        answer,
        isCorrect,
        team: gameState.current_turn,
        points,
        category: gameState.current_question.category,
        difficulty: gameState.current_question.difficulty,
        player: playerName
      }];

      if (isCorrect) {
        // إجابة صحيحة
        const newScore = gameState.current_turn === 'red' 
          ? gameState.red_team_score + points
          : gameState.blue_team_score + points;

        await supabase
          .from('game_state')
          .update({
            [gameState.current_turn === 'red' ? 'red_team_score' : 'blue_team_score']: newScore,
            game_history: newHistory,
            waiting_for_opponent: false
          })
          .eq('room_id', roomId);

        setTimeout(() => {
          nextTurn();
        }, 3000);
      } else if (!gameState.waiting_for_opponent) {
        // الفريق الأول أخطأ - إعطاء فرصة للآخر
        await supabase
          .from('game_state')
          .update({
            waiting_for_opponent: true,
            current_turn: gameState.current_turn === 'red' ? 'blue' : 'red',
            time_left: 15,
            used_power_card: null,
            game_history: newHistory
          })
          .eq('room_id', roomId);
      } else {
        // كلا الفريقين أخطأ
        await supabase
          .from('game_state')
          .update({
            game_history: newHistory,
            waiting_for_opponent: false
          })
          .eq('room_id', roomId);

        setTimeout(() => {
          nextTurn();
        }, 3000);
      }
    } catch (error) {
      console.error('Error answering question:', error);
    }
  };

  const nextTurn = async () => {
    if (!supabase || !gameState) return;

    // التحقق من انتهاء اللعبة
    if (gameState.total_questions >= gameState.max_questions_per_team * 2) {
      await supabase
        .from('game_state')
        .update({ phase: 'result' })
        .eq('room_id', roomId);
      return;
    }

    try {
      await supabase
        .from('game_state')
        .update({
          phase: 'categorySelection',
          current_turn: gameState.waiting_for_opponent 
            ? gameState.current_turn 
            : (gameState.current_turn === 'red' ? 'blue' : 'red'),
          current_question: null,
          time_left: 15,
          used_power_card: null,
          waiting_for_opponent: false
        })
        .eq('room_id', roomId);
    } catch (error) {
      console.error('Error moving to next turn:', error);
    }
  };

  const usePowerCard = async (cardType: PowerCard) => {
    if (!supabase || !gameState) return;

    const currentTeamPowerCards = gameState.current_turn === 'red' 
      ? gameState.red_team_power_cards 
      : gameState.blue_team_power_cards;

    if (currentTeamPowerCards <= 0) return;

    try {
      const updates: any = {
        used_power_card: cardType,
        [gameState.current_turn === 'red' ? 'red_team_power_cards' : 'blue_team_power_cards']: currentTeamPowerCards - 1
      };

      if (cardType === 'extraTime') {
        updates.time_left = gameState.time_left + 10;
      }

      await supabase
        .from('game_state')
        .update(updates)
        .eq('room_id', roomId);

      if (cardType === 'skipQuestion') {
        setTimeout(() => {
          supabase
            .from('game_state')
            .update({ phase: 'categorySelection' })
            .eq('room_id', roomId);
        }, 1000);
      }
    } catch (error) {
      console.error('Error using power card:', error);
    }
  };

  // إعادة تعيين الحالة عند تغيير السؤال
  useEffect(() => {
    setSelectedAnswer(null);
    setShowResult(false);
    setVisibleOptions([0, 1, 2, 3]);
  }, [gameState?.current_question]);

  // تأثير كرت 50/50
  useEffect(() => {
    if (gameState?.used_power_card === 'fiftyFifty' && gameState.current_question) {
      const correctIndex = gameState.current_question.correctAnswer;
      const wrongOptions = [0, 1, 2, 3].filter(i => i !== correctIndex);
      const randomWrong = wrongOptions[Math.floor(Math.random() * wrongOptions.length)];
      setVisibleOptions([correctIndex, randomWrong].sort());
    }
  }, [gameState?.used_power_card]);

  if (!gameState) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-white text-xl mb-4">جاري تحميل اللعبة...</div>
          <div className="text-white/70 text-sm">
            إذا استمر التحميل، تحقق من Console للمزيد من المعلومات
          </div>
          <div className="mt-4 bg-blue-500/10 border border-blue-400/30 rounded-xl p-4 max-w-md">
            <div className="text-blue-300 text-sm space-y-1">
              <p>🔍 معلومات التشخيص:</p>
              <p>• معرف الغرفة: {roomId}</p>
              <p>• معرف اللاعب: {playerId}</p>
              <p>• اسم اللاعب: {playerName}</p>
              <p>• عدد اللاعبين: {players.length}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const redTeamPlayers = players.filter(p => p.team === 'red');
  const blueTeamPlayers = players.filter(p => p.team === 'blue');
  const currentPlayer = players.find(p => p.player_id === playerId);
  const isMyTurn = currentPlayer?.team === gameState.current_turn;

  // دالة اختيار التخصصات
  /**
   * يقوم بتعيين التخصصات المختارة في قاعدة البيانات ثم ينتقل إلى مرحلة اختيار الفئة.
   * فى حالة عدم وجود عمود `selected_categories` فى جدول game_state (أو إذا كانت
   * قاعدة البيانات قديمة)، تُجرى محاولة احتياطية لتحديث المرحلة فقط بحيث
   * تنتقل اللعبة للمراحل التالية. كما يتم تنبيه المستخدم لضرورة تحديث قاعدة
   * البيانات عند حدوث الخطأ. إذا تم استقبال خطأ آخر، فسيظهر للمستخدم نص الخطأ.
   */
  const handleCategoriesSelected = async (categories: string[]) => {
    if (!supabase || !gameState) return;
    try {
      // المحاولة الأولى: تحديث التخصصات والمرحلة
      const { error } = await supabase
        .from('game_state')
        .update({
          selected_categories: categories,
          phase: 'categorySelection'
        })
        .eq('room_id', roomId);
      if (error) throw error;
      console.log('✅ تم اختيار التخصصات:', categories);
    } catch (err: any) {
      console.error('Error selecting categories:', err);
      const message: string = err?.message || '';
      const code: string | undefined = err?.code;
      // إذا كان الخطأ سببه عدم وجود العمود أو قيود المرحلة، فحاول تحديث المرحلة فقط
      if (
        (code === '42703') ||
        message.includes('selected_categories') ||
        message.includes('categoryPreSelection') ||
        message.includes('phase_check')
      ) {
        try {
          await supabase
            .from('game_state')
            .update({ phase: 'categorySelection' })
            .eq('room_id', roomId);
          console.warn('⚠️ قاعدة البيانات لا تدعم التخصصات المختارة بعد. تم تجاوز هذا الخيار.');
          alert('تنبيه: يبدو أن قاعدة البيانات غير محدثة بالكامل. تم تجاوز اختيار التخصصات وسيتم الانتقال مباشرةً إلى مرحلة اختيار الفئة. يُرجى تشغيل ملفات ترقية قاعدة البيانات لاحقًا.');
        } catch (fallbackError) {
          console.error('Fallback update failed:', fallbackError);
          alert('حدث خطأ أثناء تحديث المرحلة. يرجى التحقق من إعدادات قاعدة البيانات.');
        }
      } else {
        // خطأ آخر غير متوقع
        alert('خطأ في اختيار التخصصات: ' + message);
      }
    }
  };

  /**
   * Handles selecting a category during the pre‑selection phase.  The game
   * alternates turns between the red and blue teams.  Only the team whose
   * turn it currently is may pick a category.  When a category is picked
   * it is appended to the `selected_categories` array stored in the
   * `game_state`.  After each selection, the turn toggles to the other
   * team.  Once two categories have been selected, the phase
   * automatically advances to `categorySelection`.
   */
  const selectPreCategory = async (categoryName: string) => {
    if (!supabase || !gameState) return;
    // Determine the player's team for permission checks
    const currentPlayer = players.find((p) => p.player_id === playerId);
    const myTeam = currentPlayer?.team;
    if (!myTeam) return;
    // Only allow selection if it's my team's turn
    if (gameState.current_turn !== myTeam) return;
    // Avoid selecting the same category twice
    const existing: string[] = (gameState as any).selected_categories || [];
    if (existing.includes(categoryName)) return;
    // Construct the new selected categories list
    const newSelected = [...existing, categoryName];
    // Toggle turn to the other team
    const nextTurn = gameState.current_turn === 'red' ? 'blue' : 'red';
    // Determine number of questions per team based on the number of selected
    // categories.  Each category contains three difficulty levels (easy,
    // medium and hard), so each selected category contributes three questions
    // per team.  We therefore multiply the number of selected categories by
    // three to compute the total questions each team will answer before the
    // game ends.  For example, if two categories are selected, each team
    // will answer 6 questions (3 difficulties × 2 categories) before the
    // result screen is shown.  Adjust this calculation if you change the
    // number of difficulty levels or categories.
    const maxQuestionsPerTeam = newSelected.length * 3;
    // Prepare update payload
    const updateData: any = {
      selected_categories: newSelected,
      current_turn: nextTurn,
      max_questions_per_team: maxQuestionsPerTeam
    };
    // If two categories have been selected, move to the next phase
    if (newSelected.length >= 2) {
      updateData.phase = 'categorySelection';
    }
    try {
      const { error } = await supabase
        .from('game_state')
        .update(updateData)
        .eq('room_id', roomId);
      if (error) throw error;
    } catch (err) {
      console.error('Error selecting pre‑category:', err);
    }
  };

  // شاشة اختيار الفئة
  if (gameState.phase === 'categoryPreSelection') {
    // تحديد اللاعب الحالي وفريقه لمرحلة اختيار التخصصات المسبقة
    const currentPlayer = players.find(p => p.player_id === playerId);
    const myTeam = currentPlayer?.team;
    // هل دوري الآن لاختيار التخصص؟ يعتمد على حقل current_turn فى حالة اللعبة
    const isMyTurnPreSelection = gameState.current_turn === myTeam;
    // جلب التخصصات المختارة من قاعدة البيانات
    const preSelected: string[] = (gameState as any).selected_categories || [];
    // يسمح بالاختيار فقط إذا كان دوري ولم نتجاوز الحد (اثنان)
    const canSelectCategories = isMyTurnPreSelection && preSelected.length < 2;
    // لم يعد هناك مفهوم المضيف فى اختيار التخصصات بالتناوب
    const isHost = false;
    
    return (
      <div className="min-h-screen p-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center mb-6">
              <BookOpen className="w-16 h-16 text-purple-400 mr-4" />
              <h1 className="text-6xl font-bold text-white">
                اختر التخصصات
              </h1>
              <BookOpen className="w-16 h-16 text-purple-400 ml-4" />
            </div>
            <p className="text-xl text-purple-200 mb-4">
              {preSelected.length >= 2
                ? 'تم اختيار التخصصات، جاري الإعداد...'
                : isMyTurnPreSelection
                ? 'دور فريقك لاختيار تخصص واحد'
                : 'في انتظار الفريق الآخر لاختيار تخصصه'}
            </p>
            <div className="inline-flex items-center gap-4 px-6 py-3 bg-white/10 rounded-full">
              <span className="text-white">المختار: {preSelected.length}/2</span>
              <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" />
            </div>
          </div>

          {/* Teams Score */}
          <div className="grid grid-cols-2 gap-8 mb-8">
            <div className="bg-gradient-to-r from-red-500/20 to-red-700/20 backdrop-blur-md rounded-2xl p-6 border border-red-400/30">
              <div className="text-center">
                <h3 className="text-xl font-bold text-red-400 mb-2">الفريق الأحمر</h3>
                <div className="text-4xl font-bold text-white">{gameState.red_team_score}</div>
                <div className="text-red-200 text-sm">{players.filter(p => p.team === 'red').length} لاعب</div>
              </div>
            </div>
            <div className="bg-gradient-to-r from-blue-500/20 to-blue-700/20 backdrop-blur-md rounded-2xl p-6 border border-blue-400/30">
              <div className="text-center">
                <h3 className="text-xl font-bold text-blue-400 mb-2">الفريق الأزرق</h3>
                <div className="text-4xl font-bold text-white">{gameState.blue_team_score}</div>
                <div className="text-blue-200 text-sm">{players.filter(p => p.team === 'blue').length} لاعب</div>
              </div>
            </div>
          </div>

          {canSelectCategories ? (
            <>
              {/* Categories Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {categoryQuestions.map((categoryData) => {
                  // تحديد ما إذا كان هذا التخصص قد تم اختياره
                  const isSelected = preSelected.includes(categoryData.category);
                  // يمنع اختيار التخصص إذا كان التخصص مختاراً بالفعل أو إذا لم يكن دوري أو إذا تم اختيار تخصصين بالفعل
                  const isDisabled = isSelected || !isMyTurnPreSelection || preSelected.length >= 2;
                  const Icon = getIconComponent(categoryData.icon);
                  const totalQuestions =
                    categoryData.difficulties.easy.length +
                    categoryData.difficulties.medium.length +
                    categoryData.difficulties.hard.length;

                  return (
                    <button
                      key={categoryData.category}
                      onClick={() => {
                        if (!isDisabled) selectPreCategory(categoryData.category);
                      }}
                      disabled={isDisabled}
                      className={`
                        relative p-6 rounded-3xl border-2 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                        ${isSelected
                          ? 'bg-gradient-to-br from-purple-500/30 to-pink-500/30 border-purple-400 shadow-lg shadow-purple-500/50'
                          : 'bg-white/10 border-white/20 hover:bg-white/20 hover:border-white/40'
                        }
                      `}
                    >
                      <div
                        className={`absolute top-4 right-4 w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
                          isSelected ? 'bg-green-500 border-green-400' : 'border-white/40'
                        }`}
                      >
                        {isSelected && <Check className="w-5 h-5 text-white" />}
                      </div>

                      <div className="text-center mb-4">
                        <div
                          className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                            isSelected ? 'bg-gradient-to-r from-purple-500 to-pink-500' : 'bg-gradient-to-r from-gray-500 to-gray-600'
                          }`}
                        >
                          <Icon className="w-8 h-8 text-white" />
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-2">{categoryData.category}</h3>
                        <p className="text-white/70 text-sm">{totalQuestions} سؤال متاح</p>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-xs">
                        <div className="bg-green-500/20 rounded-lg p-2 text-center">
                          <div className="text-green-400 font-bold">
                            {categoryData.difficulties.easy.length}
                          </div>
                          <div className="text-green-300">سهل</div>
                        </div>
                        <div className="bg-yellow-500/20 rounded-lg p-2 text-center">
                          <div className="text-yellow-400 font-bold">
                            {categoryData.difficulties.medium.length}
                          </div>
                          <div className="text-yellow-300">متوسط</div>
                        </div>
                        <div className="bg-red-500/20 rounded-lg p-2 text-center">
                          <div className="text-red-400 font-bold">
                            {categoryData.difficulties.hard.length}
                          </div>
                          <div className="text-red-300">صعب</div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Selected Categories Summary */}
              {preSelected.length > 0 && (
                <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 mb-8 border border-white/10">
                  <h3 className="text-xl font-bold text-white text-center mb-4">التخصصات المختارة</h3>
                  <div className="flex flex-wrap justify-center gap-3">
                    {preSelected.map((category) => (
                      <div
                        key={category}
                        className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full border border-purple-400/30"
                      >
                        <span className="text-white font-semibold">{category}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </>
          ) : (
            <div className="text-center">
              <div className="bg-blue-500/10 border border-blue-400/30 rounded-2xl p-8">
                <div className="text-6xl mb-4">⏳</div>
                <h3 className="text-2xl font-bold text-blue-400 mb-4">في انتظار المضيف</h3>
                <p className="text-blue-200">المضيف يختار التخصصات للعبة...</p>
                <div className="mt-4 flex justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400"></div>
                </div>
              </div>
            </div>
          )}

          {/* Instructions */}
          <div className="mt-12 bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
            <h3 className="text-xl font-bold text-white text-center mb-4">تعليمات اختيار التخصصات</h3>
            <div className="grid md:grid-cols-3 gap-6 text-white/80 text-sm">
              <div>
                <h4 className="font-semibold text-purple-300 mb-2">🎯 الاختيار:</h4>
                <ul className="space-y-1">
                  <li>• يختار كل فريق تخصصًا واحدًا بالتناوب</li>
                  <li>• بعد اختيار تخصصين، تبدأ مرحلة اختيار الفئة</li>
                  <li>• لا يمكن تغيير التخصص المختار</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-blue-300 mb-2">📊 المعلومات:</h4>
                <ul className="space-y-1">
                  <li>• عدد الأسئلة لكل تخصص</li>
                  <li>• توزيع الصعوبة (سهل/متوسط/صعب)</li>
                  <li>• التخصصات المختارة تظهر فقط في اللعبة</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-green-300 mb-2">🎮 اللعب:</h4>
                <ul className="space-y-1">
                  <li>• ستظهر التخصصات المختارة فقط</li>
                  <li>• تنوع أكبر في الأسئلة</li>
                  <li>• تجربة مخصصة حسب اهتماماتك</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (gameState.phase === 'categorySelection') {
    // فلترة التخصصات حسب الاختيار المسبق
    const filteredCategories = categoryQuestions.filter(categoryData => 
      gameState.selected_categories && gameState.selected_categories.includes(categoryData.category)
    );

    return (
      <div className="min-h-screen p-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className={`inline-flex items-center px-8 py-4 rounded-full bg-gradient-to-r ${
              gameState.current_turn === 'red' ? 'from-red-500 to-red-700' : 'from-blue-500 to-blue-700'
            } text-white font-bold text-2xl animate-pulse`}>
              دور {gameState.current_turn === 'red' ? 'الفريق الأحمر' : 'الفريق الأزرق'} - اختر الفئة والصعوبة
            </div>
            {!isMyTurn && (
              <p className="text-white/70 mt-4">في انتظار اختيار الفريق الآخر...</p>
            )}
          </div>

          {/* Teams Score */}
          <div className="grid grid-cols-2 gap-8 mb-8">
            <div className="bg-gradient-to-r from-red-500/20 to-red-700/20 backdrop-blur-md rounded-2xl p-6 border border-red-400/30">
              <div className="text-center">
                <h3 className="text-xl font-bold text-red-400 mb-2">الفريق الأحمر</h3>
                <div className="text-4xl font-bold text-white">{gameState.red_team_score}</div>
                <div className="text-red-200 text-sm">{redTeamPlayers.length} لاعب</div>
              </div>
            </div>
            <div className="bg-gradient-to-r from-blue-500/20 to-blue-700/20 backdrop-blur-md rounded-2xl p-6 border border-blue-400/30">
              <div className="text-center">
                <h3 className="text-xl font-bold text-blue-400 mb-2">الفريق الأزرق</h3>
                <div className="text-4xl font-bold text-white">{gameState.blue_team_score}</div>
                <div className="text-blue-200 text-sm">{blueTeamPlayers.length} لاعب</div>
              </div>
            </div>
          </div>

          {/* Categories */}
          <div
            className={`grid gap-6 ${
              filteredCategories.length <= 2
                ? 'grid-cols-1 md:grid-cols-2 max-w-4xl mx-auto'
                : filteredCategories.length <= 4
                ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-2 max-w-5xl mx-auto'
                : filteredCategories.length <= 6
                ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'
                : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'
            }`}
          >
            {filteredCategories.map((categoryData) => {
              const Icon = getIconComponent(categoryData.icon);

              return (
                <div
                  key={categoryData.category}
                  className="bg-white/10 backdrop-blur-md rounded-3xl p-6 border border-white/20"
                >
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-white">{categoryData.category}</h3>
                  </div>
                  <div className="space-y-3">
                    {(['easy', 'medium', 'hard'] as const).map((difficulty) => {
                      const isUsed = gameState.used_questions.some(
                        (used: any) =>
                          used.category === categoryData.category && used.difficulty === difficulty
                      );
                      const points = difficulty === 'easy' ? 10 : difficulty === 'medium' ? 20 : 30;
                      const difficultyName =
                        difficulty === 'easy'
                          ? 'سهل'
                          : difficulty === 'medium'
                          ? 'متوسط'
                          : 'صعب';
                      const difficultyColor =
                        difficulty === 'easy'
                          ? 'from-green-500 to-green-600'
                          : difficulty === 'medium'
                          ? 'from-yellow-500 to-orange-500'
                          : 'from-red-500 to-red-600';

                      // Disable button if it's not my turn or if the question was already used
                      const disabled = !isMyTurn || isUsed;

                      return (
                        <button
                          key={difficulty}
                          onClick={() => {
                            if (!disabled) {
                              selectCategory(categoryData.category, difficulty);
                            }
                          }}
                          disabled={disabled}
                          className={`
                            w-full p-4 rounded-xl text-white font-semibold transition-all duration-300 transform
                            hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                            bg-gradient-to-r ${difficultyColor}
                          `}
                        >
                          <div className="flex items-center justify-between">
                            <span>{difficultyName}</span>
                            <span className="text-lg font-bold">{points} نقطة</span>
                          </div>
                          {isUsed && <div className="text-sm opacity-75 mt-1">مُستخدم</div>}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
          
          {/* عرض معلومات التخصصات المختارة */}
          <div className="mt-8 bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-4">
                🎯 التخصصات المختارة ({filteredCategories.length})
              </h3>
              <div className="flex flex-wrap justify-center gap-3">
                {filteredCategories.map((categoryData) => {
                  const Icon = getIconComponent(categoryData.icon);
                  const totalQuestions = 
                    categoryData.difficulties.easy.length +
                    categoryData.difficulties.medium.length +
                    categoryData.difficulties.hard.length;
                  
                  return (
                    <div
                      key={categoryData.category}
                      className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full border border-purple-400/30"
                    >
                      <Icon className="w-4 h-4 text-purple-400" />
                      <span className="text-white font-semibold">{categoryData.category}</span>
                      <span className="text-white/70 text-xs">({totalQuestions})</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // شاشة اللعب
  if (gameState.phase === 'playing' && gameState.current_question) {
    return (
      <div className="min-h-screen p-4">
        {/* Header */}
        <div className="max-w-6xl mx-auto mb-8">
          <div className="grid grid-cols-3 gap-4 items-center">
            {/* Red Team */}
            <div className="bg-gradient-to-r from-red-500/20 to-red-700/20 backdrop-blur-md rounded-2xl p-4 border border-red-400/30">
              <div className="text-center">
                <h3 className="text-xl font-bold text-red-400">الفريق الأحمر</h3>
                <div className="text-3xl font-bold text-white">{gameState.red_team_score}</div>
                <div className="text-red-200 text-sm">{redTeamPlayers.length} لاعب</div>
              </div>
            </div>

            {/* Current Turn */}
            <div className="text-center">
              <div className={`inline-flex items-center px-6 py-3 rounded-full bg-gradient-to-r ${
                gameState.current_turn === 'red' ? 'from-red-500 to-red-700' : 'from-blue-500 to-blue-700'
              } text-white font-bold text-lg animate-pulse`}>
                {gameState.waiting_for_opponent ? 
                  `فرصة ${gameState.current_turn === 'red' ? 'الفريق الأحمر' : 'الفريق الأزرق'}` :
                  `دور ${gameState.current_turn === 'red' ? 'الفريق الأحمر' : 'الفريق الأزرق'}`
                }
              </div>
              <div className="mt-2 text-white/70">
                السؤال {gameState.total_questions} من {gameState.max_questions_per_team * 2}
              </div>
            </div>

            {/* Blue Team */}
            <div className="bg-gradient-to-r from-blue-500/20 to-blue-700/20 backdrop-blur-md rounded-2xl p-4 border border-blue-400/30">
              <div className="text-center">
                <h3 className="text-xl font-bold text-blue-400">الفريق الأزرق</h3>
                <div className="text-3xl font-bold text-white">{gameState.blue_team_score}</div>
                <div className="text-blue-200 text-sm">{blueTeamPlayers.length} لاعب</div>
              </div>
            </div>
          </div>
        </div>

        {/* Question */}
        <div className="max-w-4xl mx-auto">
          <div className={`bg-gradient-to-br ${
            gameState.current_turn === 'red' ? 'bg-red-500/20 border-red-400/30' : 'bg-blue-500/20 border-blue-400/30'
          } backdrop-blur-md rounded-3xl p-8 mb-8 border`}>
            <div className="text-center mb-6">
              <div className="bg-white/10 rounded-xl p-2 mb-4 inline-block">
                <span className="text-white/70 text-sm">الفئة: </span>
                <span className="text-white font-semibold">{gameState.current_question.category}</span>
                <span className="text-white/70 text-sm ml-4">النقاط: </span>
                <span className="text-yellow-400 font-bold">{gameState.current_question.points}</span>
              </div>
              
              <h2 className="text-3xl font-bold text-white leading-relaxed">
                {gameState.current_question.question}
              </h2>
              
              {!isMyTurn && (
                <p className="text-white/70 mt-4">في انتظار إجابة الفريق الآخر...</p>
              )}
              
              {/* Bot Turn Indicator */}
              {!isMyTurn && (
                <div className="text-center mt-6">
                  <div className="inline-flex items-center px-4 py-2 bg-purple-500/20 rounded-full border border-purple-400/30">
                    <Bot className="w-4 h-4 text-purple-400 mr-2 animate-pulse" />
                    <span className="text-purple-300 text-sm">
                      {(() => {
                        const currentTeamPlayers = gameState.current_turn === 'red' ? redTeamPlayers : blueTeamPlayers;
                        const botPlayer = currentTeamPlayers.find(p => p.player_name.includes('🤖'));
                        return botPlayer ? `${botPlayer.player_name} يفكر...` : 'في انتظار إجابة الفريق الآخر...';
                      })()}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Answer Options */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {gameState.current_question.options.map((option: string, index: number) => {
                if (!visibleOptions.includes(index)) return null;
                
                let buttonClass = "p-6 rounded-2xl text-white font-semibold text-lg transition-all duration-300 transform hover:scale-105 border-2 ";
                
                if (showResult) {
                  if (index === selectedAnswer) {
                    const isCorrect = index === gameState.current_question.correctAnswer;
                    if (isCorrect) {
                      buttonClass += "bg-gradient-to-r from-green-500 to-green-600 border-green-400";
                    } else {
                      buttonClass += "bg-gradient-to-r from-red-500 to-red-600 border-red-400";
                    }
                  } else {
                    buttonClass += "bg-gray-500/30 border-gray-500/30";
                  }
                } else {
                  buttonClass += "bg-white/10 border-white/20 hover:bg-white/20 hover:border-white/40";
                }

                return (
                  <button
                    key={index}
                    onClick={() => isMyTurn && answerQuestion(index)}
                    disabled={!isMyTurn || showResult || selectedAnswer !== null}
                    className={buttonClass}
                  >
                    <div className="flex items-center">
                      <span className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center mr-4 text-sm font-bold">
                        {String.fromCharCode(65 + index)}
                      </span>
                      {option}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Result Message */}
            {showResult && (
              <div className="text-center mt-6">
                {selectedAnswer === gameState.current_question.correctAnswer ? (
                  <div className="text-green-400 text-xl font-bold animate-bounce">
                    ✅ إجابة صحيحة! +{gameState.current_question.points} نقطة
                  </div>
                ) : (
                  <div className="text-red-400 text-xl font-bold">
                    ❌ إجابة خاطئة
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Power Cards */}
          {isMyTurn && (
            <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
              <div className="text-center mb-4">
                <h3 className="text-xl font-bold text-white">كروت المساعدة</h3>
                <p className="text-white/70">
                  المتبقي: {gameState.current_turn === 'red' ? gameState.red_team_power_cards : gameState.blue_team_power_cards} كرت
                </p>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { type: 'fiftyFifty' as PowerCard, name: '50/50', icon: Zap, color: 'from-yellow-500 to-orange-500' },
                  { type: 'skipQuestion' as PowerCard, name: 'تبديل السؤال', icon: RefreshCw, color: 'from-blue-500 to-purple-500' },
                  { type: 'stealTurn' as PowerCard, name: 'سرقة الدور', icon: ArrowRightLeft, color: 'from-red-500 to-pink-500' },
                  { type: 'extraTime' as PowerCard, name: 'وقت إضافي', icon: Plus, color: 'from-green-500 to-teal-500' }
                ].map((card) => {
                  const Icon = card.icon;
                  const currentTeamPowerCards = gameState.current_turn === 'red' ? gameState.red_team_power_cards : gameState.blue_team_power_cards;
                  const isDisabled = currentTeamPowerCards <= 0 || gameState.used_power_card === card.type;
                  
                  return (
                    <button
                      key={card.type}
                      onClick={() => !isDisabled && usePowerCard(card.type)}
                      disabled={isDisabled}
                      className={`
                        p-4 rounded-xl text-white font-semibold transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                        bg-gradient-to-br ${card.color}
                      `}
                    >
                      <Icon className="w-8 h-8 mx-auto mb-2" />
                      <div className="text-sm">{card.name}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // شاشة النتائج
  if (gameState.phase === 'result') {
    // إنشاء بنية حالة اللعبة المتوافقة مع ResultScreen والمستمدة من بيانات الأونلاين
    // بُنية حالة اللعبة المتوافقة مع ResultScreen
    // بالإضافة إلى gameHistory لضمان عمل إحصائيات النتائج بشكل صحيح
    const offlineResultState = {
      redTeam: {
        score: gameState.red_team_score,
        players: redTeamPlayers.map((p) => ({ id: p.player_id, name: p.player_name }))
      },
      blueTeam: {
        score: gameState.blue_team_score,
        players: blueTeamPlayers.map((p) => ({ id: p.player_id, name: p.player_name }))
      },
      // تمرير سجل اللعبة حتى يمكن لـ ResultScreen عرض إحصائيات الأسئلة بشكل صحيح
      gameHistory: gameState.game_history || []
    } as any;

    return (
      <div className="min-h-screen flex flex-col">
        <ResultScreen
          gameState={offlineResultState}
          onRestart={onGameEnd}
          onBackToHome={onGameEnd}
        />
        {/* عرض سجل اللعبة أسفل شاشة النتائج */}
        <GameHistory
          history={gameState.game_history || []}
          isVisible={showHistory}
          onToggle={() => setShowHistory(!showHistory)}
        />
      </div>
    );
  }

  return null;
};

export default OnlineGameScreen;