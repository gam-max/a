import React, { useState } from 'react';
import { Database, Play, Copy, CheckCircle, ExternalLink, ArrowRight, Monitor, MousePointer, Keyboard } from 'lucide-react';

interface SupabaseSQLGuideProps {
  onClose: () => void;
}

const SupabaseSQLGuide: React.FC<SupabaseSQLGuideProps> = ({ onClose }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const markStepCompleted = (stepId: number) => {
    if (!completedSteps.includes(stepId)) {
      setCompletedSteps([...completedSteps, stepId]);
    }
  };

  const steps = [
    {
      id: 1,
      title: "الوصول إلى Supabase Dashboard",
      description: "افتح لوحة تحكم Supabase الخاصة بمشروعك",
      details: [
        "اذهب إلى الرابط: https://supabase.com/dashboard",
        "سجل دخولك باستخدام حسابك",
        "اختر المشروع الخاص بك من القائمة"
      ],
      visual: "🌐 ستجد قائمة بجميع مشاريعك، اختر المشروع المطلوب"
    },
    {
      id: 2,
      title: "العثور على SQL Editor",
      description: "ابحث عن محرر SQL في القائمة الجانبية",
      details: [
        "في الجانب الأيسر من الشاشة، ستجد قائمة جانبية",
        "ابحث عن خيار يسمى 'SQL Editor' أو 'محرر SQL'",
        "عادة ما يكون تحت قسم 'Database' أو 'قاعدة البيانات'"
      ],
      visual: "📋 القائمة الجانبية تحتوي على: Dashboard, Authentication, Database, SQL Editor, etc."
    },
    {
      id: 3,
      title: "إنشاء New Query",
      description: "إنشاء استعلام SQL جديد",
      details: [
        "اضغط على 'SQL Editor' من القائمة الجانبية",
        "ستجد زر 'New Query' أو '+ New Query' في أعلى الصفحة",
        "اضغط على هذا الزر لإنشاء استعلام جديد"
      ],
      visual: "➕ زر 'New Query' عادة ما يكون باللون الأخضر أو الأزرق"
    },
    {
      id: 4,
      title: "نسخ ولصق كود SQL",
      description: "نسخ محتوى ملف الإعداد ولصقه في المحرر",
      details: [
        "افتح الملف الأول: supabase/migrations/20250726100321_gentle_glade.sql",
        "اضغط Ctrl+A لتحديد كامل المحتوى",
        "اضغط Ctrl+C لنسخ المحتوى",
        "ارجع لمحرر SQL في Supabase والصق المحتوى بـ Ctrl+V"
      ],
      visual: "📝 المحرر سيظهر كود SQL مع تلوين للكلمات المفتاحية"
    },
    {
      id: 5,
      title: "تشغيل الكود",
      description: "تنفيذ كود SQL لإنشاء الجداول",
      details: [
        "بعد لصق الكود، ابحث عن زر 'Run' أو 'تشغيل'",
        "عادة ما يكون في أعلى المحرر أو بجانبه",
        "يمكنك أيضاً الضغط على Ctrl+Enter لتشغيل الكود",
        "انتظر حتى تظهر رسالة 'Success' أو 'تم بنجاح'"
      ],
      visual: "▶️ زر Run عادة ما يكون بشكل مثلث أو يحتوي على كلمة 'Run'"
    },
    {
      id: 6,
      title: "تكرار العملية للملف الثاني",
      description: "تشغيل الملف الثاني لإكمال الإعداد",
      details: [
        "امسح محتوى المحرر (Ctrl+A ثم Delete)",
        "افتح الملف الثاني: supabase/migrations/20250726212911_lively_rain.sql",
        "انسخ محتواه والصقه في المحرر",
        "اضغط Run مرة أخرى وانتظر رسالة النجاح"
      ],
      visual: "🔄 كرر نفس العملية: نسخ → لصق → تشغيل → انتظار النجاح"
    }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 overflow-y-auto">
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="bg-gradient-to-br from-slate-900/95 to-gray-900/95 backdrop-blur-md rounded-3xl border border-white/20 w-full max-w-4xl max-h-[90vh] overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-white/20">
            <div className="flex items-center gap-3">
              <Database className="w-8 h-8 text-blue-400" />
              <div>
                <h1 className="text-2xl font-bold text-white">دليل استخدام محرر SQL في Supabase</h1>
                <p className="text-blue-200">خطوات مفصلة لإنشاء New Query وتشغيل ملفات الإعداد</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center hover:bg-red-500/30 transition-all"
            >
              ×
            </button>
          </div>

          {/* Progress Bar */}
          <div className="p-6 border-b border-white/20">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white">التقدم: {completedSteps.length}/{steps.length}</h3>
              <div className="text-blue-300 text-sm">الخطوة الحالية: {currentStep}</div>
            </div>
            <div className="w-full bg-white/10 rounded-full h-3">
              <div 
                className="bg-gradient-to-r from-blue-500 to-green-500 h-3 rounded-full transition-all duration-500"
                style={{ width: `${(completedSteps.length / steps.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Steps Navigation */}
          <div className="p-6 border-b border-white/20">
            <div className="flex flex-wrap gap-2">
              {steps.map(step => (
                <button
                  key={step.id}
                  onClick={() => setCurrentStep(step.id)}
                  className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                    currentStep === step.id
                      ? 'bg-blue-500 text-white'
                      : completedSteps.includes(step.id)
                      ? 'bg-green-500/20 text-green-300'
                      : 'bg-white/10 text-white/70 hover:bg-white/20'
                  }`}
                >
                  {completedSteps.includes(step.id) ? '✅' : step.id} {step.title}
                </button>
              ))}
            </div>
          </div>

          {/* Current Step Content */}
          <div className="p-6 overflow-y-auto max-h-[50vh]">
            {steps.map(step => (
              currentStep === step.id && (
                <div key={step.id} className="space-y-6">
                  {/* Step Header */}
                  <div className="text-center">
                    <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full mb-4 ${
                      completedSteps.includes(step.id) ? 'bg-green-500' : 'bg-blue-500'
                    }`}>
                      {completedSteps.includes(step.id) ? (
                        <CheckCircle className="w-8 h-8 text-white" />
                      ) : (
                        <span className="text-2xl font-bold text-white">{step.id}</span>
                      )}
                    </div>
                    <h2 className="text-3xl font-bold text-white mb-2">{step.title}</h2>
                    <p className="text-blue-200 text-lg">{step.description}</p>
                  </div>

                  {/* Visual Guide */}
                  <div className="bg-blue-500/10 border border-blue-400/30 rounded-2xl p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <Monitor className="w-6 h-6 text-blue-400" />
                      <h3 className="text-xl font-bold text-blue-300">المظهر المرئي:</h3>
                    </div>
                    <p className="text-blue-200 text-lg">{step.visual}</p>
                  </div>

                  {/* Detailed Steps */}
                  <div className="bg-white/5 rounded-2xl p-6">
                    <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                      <Keyboard className="w-6 h-6 text-green-400" />
                      الخطوات التفصيلية:
                    </h3>
                    <div className="space-y-4">
                      {step.details.map((detail, index) => (
                        <div key={index} className="flex items-start gap-3">
                          <div className="w-6 h-6 bg-green-500/20 text-green-400 rounded-full flex items-center justify-center text-sm font-bold mt-1">
                            {index + 1}
                          </div>
                          <p className="text-white/90 flex-1">{detail}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Special Instructions for Specific Steps */}
                  {step.id === 1 && (
                    <div className="bg-green-500/10 border border-green-400/30 rounded-2xl p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <ExternalLink className="w-6 h-6 text-green-400" />
                        <h3 className="text-xl font-bold text-green-300">رابط مباشر:</h3>
                      </div>
                      <a
                        href="https://supabase.com/dashboard"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 px-6 py-3 bg-green-500 text-white font-bold rounded-xl hover:bg-green-600 transition-all"
                      >
                        <ExternalLink className="w-5 h-5" />
                        فتح Supabase Dashboard
                      </a>
                    </div>
                  )}

                  {step.id === 3 && (
                    <div className="bg-yellow-500/10 border border-yellow-400/30 rounded-2xl p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <MousePointer className="w-6 h-6 text-yellow-400" />
                        <h3 className="text-xl font-bold text-yellow-300">نصائح للعثور على New Query:</h3>
                      </div>
                      <div className="space-y-2 text-yellow-200">
                        <p>• ابحث عن زر أخضر أو أزرق مكتوب عليه "New Query"</p>
                        <p>• قد يكون مكتوب "+" أو "إنشاء جديد"</p>
                        <p>• عادة ما يكون في أعلى يمين أو يسار الصفحة</p>
                        <p>• إذا لم تجده، ابحث عن أيقونة "+" بجانب كلمة "Queries"</p>
                      </div>
                    </div>
                  )}

                  {(step.id === 4 || step.id === 6) && (
                    <div className="bg-purple-500/10 border border-purple-400/30 rounded-2xl p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <Copy className="w-6 h-6 text-purple-400" />
                        <h3 className="text-xl font-bold text-purple-300">ملفات الإعداد المطلوبة:</h3>
                      </div>
                      <div className="space-y-3">
                        <div className="bg-black/20 rounded-lg p-3">
                          <p className="text-white font-mono text-sm">
                            {step.id === 4 
                              ? 'supabase/migrations/20250726100321_gentle_glade.sql'
                              : 'supabase/migrations/20250726212911_lively_rain.sql'
                            }
                          </p>
                        </div>
                        <p className="text-purple-200 text-sm">
                          📁 هذا الملف موجود في مجلد المشروع الخاص بك
                        </p>
                      </div>
                    </div>
                  )}

                  {step.id === 5 && (
                    <div className="bg-red-500/10 border border-red-400/30 rounded-2xl p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <Play className="w-6 h-6 text-red-400" />
                        <h3 className="text-xl font-bold text-red-300">علامات النجاح:</h3>
                      </div>
                      <div className="space-y-2 text-red-200">
                        <p>✅ رسالة "Success" أو "تم بنجاح"</p>
                        <p>✅ لون أخضر في منطقة النتائج</p>
                        <p>✅ عدم ظهور رسائل خطأ حمراء</p>
                        <p>⚠️ إذا ظهرت أخطاء، تأكد من نسخ الكود كاملاً</p>
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-4 justify-center">
                    {currentStep > 1 && (
                      <button
                        onClick={() => setCurrentStep(currentStep - 1)}
                        className="px-6 py-3 bg-gray-500/20 text-gray-300 rounded-xl hover:bg-gray-500/30 transition-all"
                      >
                        ← الخطوة السابقة
                      </button>
                    )}
                    
                    <button
                      onClick={() => markStepCompleted(step.id)}
                      disabled={completedSteps.includes(step.id)}
                      className={`px-8 py-3 rounded-xl font-bold transition-all ${
                        completedSteps.includes(step.id)
                          ? 'bg-green-500/20 text-green-300 cursor-not-allowed'
                          : 'bg-green-500 text-white hover:bg-green-600'
                      }`}
                    >
                      {completedSteps.includes(step.id) ? '✅ مكتملة' : '✅ أكملت هذه الخطوة'}
                    </button>

                    {currentStep < steps.length && (
                      <button
                        onClick={() => setCurrentStep(currentStep + 1)}
                        className="px-6 py-3 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-all flex items-center gap-2"
                      >
                        الخطوة التالية <ArrowRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              )
            ))}
          </div>

          {/* Completion Message */}
          {completedSteps.length === steps.length && (
            <div className="p-6 border-t border-white/20">
              <div className="bg-green-500/10 border border-green-400/30 rounded-2xl p-6 text-center">
                <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-green-400 mb-2">🎉 تم إكمال جميع الخطوات!</h3>
                <p className="text-green-200 mb-4">
                  قاعدة البيانات جاهزة الآن. يمكنك إغلاق هذا الدليل والعودة لإضافة التخصصات والأسئلة.
                </p>
                <button
                  onClick={onClose}
                  className="px-8 py-3 bg-green-500 text-white font-bold rounded-xl hover:bg-green-600 transition-all"
                >
                  🎮 العودة للعبة
                </button>
              </div>
            </div>
          )}

          {/* Help Section */}
          <div className="p-6 border-t border-white/20">
            <div className="bg-blue-500/10 border border-blue-400/30 rounded-2xl p-4">
              <h4 className="text-blue-300 font-bold mb-2">💡 نصائح مهمة:</h4>
              <div className="text-blue-200 text-sm space-y-1">
                <p>• تأكد من تشغيل الملفات بالترتيب المحدد</p>
                <p>• إذا ظهرت أخطاء، تحقق من صحة نسخ المحتوى</p>
                <p>• بعض الأوامر قد تظهر تحذيرات - هذا طبيعي</p>
                <p>• إذا فشل ملف، جرب تشغيله مرة أخرى</p>
                <p>• بعد الانتهاء، أعد تحميل الصفحة لتطبيق التغييرات</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupabaseSQLGuide;