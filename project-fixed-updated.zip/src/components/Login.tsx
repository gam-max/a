import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

/**
 * مكون شاشة تسجيل الدخول والتسجيل للمستخدمين.
 * يسمح للمستخدم بالتحويل بين نمطي تسجيل الدخول وإنشاء حساب جديد.
 */
const Login: React.FC = () => {
  const { signIn, signUp, loading } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);
    if (!email || !password) {
      setErrorMessage('يرجى إدخال البريد الإلكتروني وكلمة المرور');
      return;
    }
    if (mode === 'signup' && !username) {
      setErrorMessage('يرجى إدخال اسم المستخدم');
      return;
    }
    if (mode === 'signin') {
      const { error } = await signIn(email, password);
      if (error) {
        setErrorMessage(error.message ?? 'فشل تسجيل الدخول');
      } else {
        setSuccessMessage('تم تسجيل الدخول بنجاح');
      }
    } else {
      const { error } = await signUp(email, password, username);
      if (error) {
        setErrorMessage(error.message ?? 'فشل إنشاء الحساب');
      } else {
        setSuccessMessage('تم إنشاء الحساب بنجاح. يرجى التحقق من بريدك الإلكتروني.');
        setMode('signin');
      }
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100 dark:bg-gray-900">
      <div className="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-8 w-96">
        <h1 className="text-2xl font-bold mb-4 text-center">
          {mode === 'signin' ? 'تسجيل الدخول' : 'إنشاء حساب'}
        </h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <div>
              <label className="block mb-1 text-sm font-medium">اسم المستخدم</label>
              <input
                type="text"
                className="w-full px-3 py-2 border rounded focus:outline-none focus:ring focus:border-blue-300 dark:bg-gray-700 dark:text-white"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={loading}
              />
            </div>
          )}
          <div>
            <label className="block mb-1 text-sm font-medium">البريد الإلكتروني</label>
            <input
              type="email"
              className="w-full px-3 py-2 border rounded focus:outline-none focus:ring focus:border-blue-300 dark:bg-gray-700 dark:text-white"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={loading}
            />
          </div>
          <div>
            <label className="block mb-1 text-sm font-medium">كلمة المرور</label>
            <input
              type="password"
              className="w-full px-3 py-2 border rounded focus:outline-none focus:ring focus:border-blue-300 dark:bg-gray-700 dark:text-white"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={loading}
            />
          </div>
          {errorMessage && <p className="text-red-500 text-sm">{errorMessage}</p>}
          {successMessage && <p className="text-green-500 text-sm">{successMessage}</p>}
          <button
            type="submit"
            className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded"
            disabled={loading}
          >
            {loading ? 'جاري التحميل...' : mode === 'signin' ? 'تسجيل الدخول' : 'إنشاء حساب'}
          </button>
        </form>
        <div className="mt-4 text-center">
          {mode === 'signin' ? (
            <p>
              ليس لديك حساب؟{' '}
              <button
                className="text-blue-500 hover:underline"
                onClick={() => {
                  setMode('signup');
                  setEmail('');
                  setPassword('');
                  setUsername('');
                  setErrorMessage(null);
                  setSuccessMessage(null);
                }}
              >
                إنشاء حساب
              </button>
            </p>
          ) : (
            <p>
              لديك حساب بالفعل؟{' '}
              <button
                className="text-blue-500 hover:underline"
                onClick={() => {
                  setMode('signin');
                  setErrorMessage(null);
                  setSuccessMessage(null);
                }}
              >
                تسجيل الدخول
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Login;