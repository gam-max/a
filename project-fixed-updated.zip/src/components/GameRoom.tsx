import React, { useState, useEffect } from 'react';
import { Users, Crown, Play, ArrowLeft, UserCheck, UserX, Shuffle, Activity, Bell, Bot } from 'lucide-react';
import { GamePlayer, GameRoom as GameRoomType, LobbyState } from '../types/lobby';
import { hasValidSupabaseConfig, supabase } from '../lib/supabase';

interface GameRoomProps {
  lobbyState: LobbyState;
  players: GamePlayer[];
  onLeaveRoom: () => void;
  onToggleReady: () => void;
  onStartGame: () => void;
  onSwitchTeam: (team: 'red' | 'blue') => void;
  onAddBot: () => void;
}

const GameRoom: React.FC<GameRoomProps> = ({
  lobbyState,
  players,
  onLeaveRoom,
  onToggleReady,
  onStartGame,
  onSwitchTeam,
  onAddBot
}) => {
  // التحقق من صحة البيانات المطلوبة
  if (!lobbyState || !lobbyState.currentRoom) {
    console.error('❌ بيانات اللوبي أو الغرفة مفقودة:', { lobbyState });
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="bg-red-500/20 border border-red-400/30 rounded-2xl p-8 text-center">
          <h2 className="text-2xl font-bold text-red-400 mb-4">خطأ في تحميل الغرفة</h2>
          <p className="text-red-200 mb-4">لم يتم العثور على بيانات الغرفة</p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all"
          >
            إعادة تحميل الصفحة
          </button>
        </div>
      </div>
    );
  }

  if (!Array.isArray(players)) {
    console.error('❌ قائمة اللاعبين غير صحيحة:', { players });
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="bg-yellow-500/20 border border-yellow-400/30 rounded-2xl p-8 text-center">
          <h2 className="text-2xl font-bold text-yellow-400 mb-4">جاري تحميل اللاعبين...</h2>
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-400 mx-auto"></div>
        </div>
      </div>
    );
  }

  console.log('🏠 تحميل مكون GameRoom...', {
    currentRoom: lobbyState.currentRoom?.name,
    playersCount: players.length,
    players: players.map(p => ({ name: p.player_name, team: p.team }))
  });
  
  const currentPlayer = players.find(p => p.player_id === lobbyState.playerId);
  const isHost = lobbyState.currentRoom?.host_id === lobbyState.playerId;
  const [recentActivity, setRecentActivity] = useState<string[]>([]);
  const [lastPlayerCount, setLastPlayerCount] = useState(players.length);
  const [activeTab, setActiveTab] = useState<'game' | 'debug'>('game');
  
  const redTeamPlayers = players.filter(p => p.team === 'red');
  const blueTeamPlayers = players.filter(p => p.team === 'blue');
  const unassignedPlayers = players.filter(p => p.team === null);
  
  // فحص مبسط للشروط (تم إلغاء شرط الجاهزية)
  const hasMinimumPlayers = players.length >= 2;
  const hasPlayersInBothTeams = redTeamPlayers.length > 0 && blueTeamPlayers.length > 0;
  const noUnassignedPlayers = unassignedPlayers.length === 0;
  const allPlayersReady = players.every(p => p.is_ready === true);

  // تشخيص آمن للشروط
  try {
    console.log('🔍 فحص شروط بدء اللعبة:', {
      players: players.map(p => ({
        name: p.player_name || 'غير محدد',
        team: p.team || 'بدون فريق',
        player_id: p.player_id || 'غير محدد'
      })),
      totalPlayers: players.length,
      redTeamCount: redTeamPlayers.length,
      blueTeamCount: blueTeamPlayers.length,
      unassignedCount: unassignedPlayers.length,
      isHost,
      hasMinimumPlayers,
      hasPlayersInBothTeams,
      noUnassignedPlayers
    });
  } catch (error) {
    console.error('❌ خطأ في تشخيص الشروط:', error);
  }

  const canStartGame = isHost && hasMinimumPlayers && hasPlayersInBothTeams && noUnassignedPlayers;
  
  const handleStartGame = () => {
    try {
      console.log('🎮 محاولة بدء اللعبة...', {
        isHost,
        hasMinimumPlayers,
        hasPlayersInBothTeams,
        noUnassignedPlayers,
        playersCount: players.length,
        redTeam: redTeamPlayers.length,
        blueTeam: blueTeamPlayers.length,
        canStartGame,
        players: players.map(p => ({
          name: p.player_name,
          team: p.team
        }))
      });
      
      if (!canStartGame) {
        console.log('❌ لا يمكن بدء اللعبة - الشروط غير مكتملة');
        
        // رسالة تشخيصية مفصلة
        let errorMessage = 'لا يمكن بدء اللعبة:\n';
        if (!isHost) errorMessage += '• لست المضيف\n';
        if (!hasMinimumPlayers) errorMessage += '• يجب وجود لاعبين على الأقل\n';
        if (!hasPlayersInBothTeams) errorMessage += '• يجب وجود لاعب في كل فريق\n';
        if (!noUnassignedPlayers) errorMessage += '• يوجد لاعبون لم ينضموا لأي فريق\n';
        
        console.error('🚫 أسباب عدم إمكانية بدء اللعبة:', errorMessage);
        alert(errorMessage);
        return;
      }
      
      console.log('✅ جميع الشروط محققة، بدء اللعبة...');
      
      // تعطيل الزر مؤقتاً لمنع الضغط المتكرر
      const startButton = document.querySelector('[data-start-game]') as HTMLButtonElement;
      if (startButton) {
        startButton.disabled = true;
        startButton.textContent = 'جاري بدء اللعبة...';
      }
      
      onStartGame();
      
      // إعادة تفعيل الزر بعد 3 ثوان في حالة عدم الانتقال
      setTimeout(() => {
        if (startButton) {
          startButton.disabled = false;
          startButton.textContent = 'ابدأ اللعبة';
        }
      }, 3000);
    } catch (error) {
      console.error('❌ خطأ في معالجة بدء اللعبة:', error);
      alert('حدث خطأ أثناء بدء اللعبة. يرجى المحاولة مرة أخرى.');
    }
  };

  // مراقبة التغييرات في اللاعبين وإضافة الإشعارات
  useEffect(() => {
    if (players.length !== lastPlayerCount) {
      if (players.length > lastPlayerCount) {
        const newPlayer = players[players.length - 1];
        if (newPlayer.player_id !== lobbyState.playerId) {
          addActivity(`🎉 انضم ${newPlayer.player_name} للغرفة`);
        }
      } else if (players.length < lastPlayerCount) {
        // لاعب غادر الغرفة
        const wasHost = lastPlayerCount > 0 && players.length === 0;
        if (wasHost) {
          addActivity(`🏠 غادر منشئ الغرفة - سيتم حذف الغرفة`);
        } else {
          addActivity(`👋 غادر أحد اللاعبين الغرفة`);
        }
      }
      setLastPlayerCount(players.length);
      
      // تحديث عدد اللاعبين في قاعدة البيانات
      if (lobbyState.currentRoom && hasValidSupabaseConfig && supabase) {
        supabase
          .from('game_rooms')
          .update({ current_players: players.length })
          .eq('id', lobbyState.currentRoom.id)
          .then(({ error }) => {
            if (error) {
              console.error('Error updating player count:', error);
            }
          });
      }
    }
  }, [players, lobbyState.playerId, lobbyState.currentRoom, lastPlayerCount]);

  // مراقبة تغييرات الفرق
  useEffect(() => {
    const prevPlayers = JSON.parse(localStorage.getItem(`room-${lobbyState.currentRoom?.id}-players`) || '[]');
    
    players.forEach(player => {
      const prevPlayer = prevPlayers.find((p: GamePlayer) => p.player_id === player.player_id);
      
      if (prevPlayer && prevPlayer.team !== player.team && player.player_id !== lobbyState.playerId) {
        if (player.team === 'red') {
          addActivity(`🔴 انضم ${player.player_name} للفريق الأحمر`);
        } else if (player.team === 'blue') {
          addActivity(`🔵 انضم ${player.player_name} للفريق الأزرق`);
        } else {
          addActivity(`⚪ غادر ${player.player_name} فريقه`);
        }
      }
      
      if (prevPlayer && prevPlayer.is_ready !== player.is_ready && player.player_id !== lobbyState.playerId) {
        if (player.is_ready) {
          addActivity(`✅ ${player.player_name} أصبح جاهزاً`);
        } else {
          addActivity(`❌ ${player.player_name} ألغى استعداده`);
        }
      }
    });
    
    localStorage.setItem(`room-${lobbyState.currentRoom?.id}-players`, JSON.stringify(players));
  }, [players, lobbyState.playerId, lobbyState.currentRoom?.id]);

  const addActivity = (message: string) => {
    setRecentActivity(prev => {
      const newActivity = [...prev, message];
      // الاحتفاظ بآخر 5 أنشطة فقط
      return newActivity.slice(-5);
    });
    
    // إزالة النشاط بعد 8 ثوان
    setTimeout(() => {
      setRecentActivity(prev => prev.filter(activity => activity !== message));
    }, 8000);
  };

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onLeaveRoom}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl transition-all duration-300 ${
              isHost 
                ? 'bg-red-600/30 text-red-300 hover:bg-red-600/50 border border-red-500/50' 
                : 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
            {isHost ? 'حذف الغرفة' : 'مغادرة الغرفة'}
          </button>
          
          <div className="text-center">
            <h1 className="text-4xl font-bold text-white mb-2">
              {lobbyState.currentRoom?.name}
            </h1>
            <div className="flex items-center justify-center gap-4 text-white/70">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                <span>{players.length}/{lobbyState.currentRoom?.max_players} لاعب</span>
              </div>
              <div className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-yellow-400" />
                <span>المضيف: {lobbyState.currentRoom?.host_name}</span>
                {isHost && (
                  <span className="text-yellow-300 text-sm">(أنت)</span>
                )}
              </div>
            </div>
          </div>
          
          <div className="w-32"></div> {/* Spacer for centering */}
        </div>

        {/* Bot Controls - Only for host */}
        {isHost && (
          <div className="mb-8">
            <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 backdrop-blur-md rounded-2xl p-4 border border-purple-400/20">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bot className="w-5 h-5 text-purple-400" />
                  <h3 className="text-lg font-bold text-purple-400">أدوات المضيف</h3>
                </div>
                <button
                  onClick={onAddBot}
                  disabled={players.length >= (lobbyState.currentRoom?.max_players || 10)}
                  className="px-6 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-xl hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center gap-2"
                >
                  <Bot className="w-4 h-4" />
                  إضافة لاعب وهمي
                </button>
              </div>
              <p className="text-purple-200 text-sm mt-2">
                💡 اللاعب الوهمي سيساعدك في اختبار اللعبة عندما لا يوجد لاعبون آخرون
              </p>
            </div>
          </div>
        )}

        {/* Live Activity Feed */}
        {recentActivity.length > 0 && (
          <div className="mb-8">
            <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 backdrop-blur-md rounded-2xl p-4 border border-green-400/20">
              <div className="flex items-center gap-2 mb-3">
                <Activity className="w-5 h-5 text-green-400 animate-pulse" />
                <h3 className="text-lg font-bold text-green-400">النشاط المباشر</h3>
              </div>
              <div className="space-y-2">
                {recentActivity.map((activity, index) => (
                  <div 
                    key={index}
                    className="flex items-center gap-2 text-white/90 text-sm bg-white/5 rounded-lg p-2 animate-fade-in"
                  >
                    <Bell className="w-4 h-4 text-yellow-400" />
                    <span>{activity}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Player Status */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full">
              <span className="text-white">أنت: {lobbyState.playerName}</span>
              {currentPlayer?.is_ready ? (
                <UserCheck className="w-5 h-5 text-green-400" />
              ) : (
                <UserX className="w-5 h-5 text-red-400" />
              )}
            </div>
            
            <button
              onClick={onToggleReady}
              className={`px-6 py-2 rounded-full font-bold transition-all duration-300 ${
                currentPlayer?.is_ready
                  ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                  : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
              }`}
            >
              {currentPlayer?.is_ready ? 'إلغاء الاستعداد' : 'جاهز'}
            </button>
          </div>
        </div>

        {/* Teams */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* Red Team */}
          <div className="bg-gradient-to-br from-red-500/20 to-red-700/20 backdrop-blur-md rounded-3xl p-8 border border-red-400/30">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-red-400">الفريق الأحمر</h3>
              <p className="text-red-200">{redTeamPlayers.length} لاعب</p>
            </div>
            
            <div className="space-y-3 mb-6">
              {redTeamPlayers.map((player) => (
                <div key={player.id} className="bg-red-500/30 rounded-xl p-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-semibold">
                      {player.player_name}
                      {player.player_id === lobbyState.playerId && (
                        <span className="text-yellow-300 text-xs ml-1">(أنت)</span>
                      )}
                      {player.player_name.includes('🤖') && (
                        <span className="text-purple-300 text-xs ml-1">(بوت)</span>
                      )}
                    </span>
                    {player.player_id === lobbyState.currentRoom?.host_id && (
                      <Crown className="w-4 h-4 text-yellow-400" />
                    )}
                    {/* مؤشر النشاط المباشر */}
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" title="متصل" />
                  </div>
                  {player.is_ready ? (
                    <UserCheck className="w-5 h-5 text-green-400" />
                  ) : (
                    <UserX className="w-5 h-5 text-red-400" />
                  )}
                </div>
              ))}
              {redTeamPlayers.length === 0 && (
                <div className="text-red-200 text-center py-8">
                  في انتظار اللاعبين...
                </div>
              )}
            </div>

            {currentPlayer?.team !== 'red' && (
              <button
                onClick={() => onSwitchTeam('red')}
                className="w-full px-6 py-3 bg-red-500/30 text-white font-bold rounded-xl hover:bg-red-500/50 transition-all duration-300"
              >
                انضم للفريق الأحمر
              </button>
            )}
          </div>

          {/* Blue Team */}
          <div className="bg-gradient-to-br from-blue-500/20 to-blue-700/20 backdrop-blur-md rounded-3xl p-8 border border-blue-400/30">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-blue-400">الفريق الأزرق</h3>
              <p className="text-blue-200">{blueTeamPlayers.length} لاعب</p>
            </div>
            
            <div className="space-y-3 mb-6">
              {blueTeamPlayers.map((player) => (
                <div key={player.id} className="bg-blue-500/30 rounded-xl p-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-semibold">
                      {player.player_name}
                      {player.player_id === lobbyState.playerId && (
                        <span className="text-yellow-300 text-xs ml-1">(أنت)</span>
                      )}
                      {player.player_name.includes('🤖') && (
                        <span className="text-purple-300 text-xs ml-1">(بوت)</span>
                      )}
                    </span>
                    {player.player_id === lobbyState.currentRoom?.host_id && (
                      <Crown className="w-4 h-4 text-yellow-400" />
                    )}
                    {/* مؤشر النشاط المباشر */}
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" title="متصل" />
                  </div>
                  {player.is_ready ? (
                    <UserCheck className="w-5 h-5 text-green-400" />
                  ) : (
                    <UserX className="w-5 h-5 text-red-400" />
                  )}
                </div>
              ))}
              {blueTeamPlayers.length === 0 && (
                <div className="text-blue-200 text-center py-8">
                  في انتظار اللاعبين...
                </div>
              )}
            </div>

            {currentPlayer?.team !== 'blue' && (
              <button
                onClick={() => onSwitchTeam('blue')}
                className="w-full px-6 py-3 bg-blue-500/30 text-white font-bold rounded-xl hover:bg-blue-500/50 transition-all duration-300"
              >
                انضم للفريق الأزرق
              </button>
            )}
          </div>
        </div>

        {/* Unassigned Players */}
        {unassignedPlayers.length > 0 && (
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 mb-8 border border-white/20">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Shuffle className="w-6 h-6 text-yellow-400" />
              لاعبون بدون فريق
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {unassignedPlayers.map((player) => (
                <div key={player.id} className="bg-white/10 rounded-xl p-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-semibold">
                      {player.player_name}
                      {player.player_id === lobbyState.playerId && (
                        <span className="text-yellow-300 text-xs ml-1">(أنت)</span>
                      )}
                      {player.player_name.includes('🤖') && (
                        <span className="text-purple-300 text-xs ml-1">(بوت)</span>
                      )}
                    </span>
                    {player.player_id === lobbyState.currentRoom?.host_id && (
                      <Crown className="w-4 h-4 text-yellow-400" />
                    )}
                    {/* مؤشر النشاط المباشر */}
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" title="متصل" />
                  </div>
                  {player.is_ready ? (
                    <UserCheck className="w-5 h-5 text-green-400" />
                  ) : (
                    <UserX className="w-5 h-5 text-red-400" />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Debug Button - زر التشخيص الكبير والواضح */}
        <div className="text-center mb-8">
          <div className="bg-yellow-500/20 border-2 border-yellow-400 rounded-2xl p-6">
            <h3 className="text-yellow-300 font-bold text-xl mb-4">🔍 تشخيص المشكلة</h3>
            <p className="text-yellow-200 mb-4">اضغط هنا لمعرفة سبب عدم إمكانية بدء اللعبة</p>
            <button
              onClick={() => {
                console.log('🔍 تشخيص سريع - حالة اللاعبين:', {
                  totalPlayers: players.length,
                  players: players.map(p => ({
                    name: p.player_name,
                    team: p.team,
                    is_ready: p.is_ready,
                    ready_type: typeof p.is_ready,
                    ready_value_exact: JSON.stringify(p.is_ready)
                  })),
                  redTeamPlayers: redTeamPlayers.length,
                  blueTeamPlayers: blueTeamPlayers.length,
                  unassignedPlayers: unassignedPlayers.length,
                  isHost,
                  hasMinimumPlayers,
                  allPlayersReady,
                  hasPlayersInBothTeams,
                  noUnassignedPlayers,
                  canStartGame
                });
                
                // عرض النتيجة في alert أيضاً
                const debugInfo = `
🔍 تشخيص سريع للمشكلة:

📊 إحصائيات اللاعبين:
• إجمالي اللاعبين: ${players.length}
• الفريق الأحمر: ${redTeamPlayers.length} لاعب
• الفريق الأزرق: ${blueTeamPlayers.length} لاعب
• اللاعبون الجاهزون: ${players.filter(p => p.is_ready === true).length}/${players.length}
• أنت المضيف: ${isHost ? 'نعم' : 'لا'}

🔍 فحص الشروط:
• عدد كافي من اللاعبين: ${hasMinimumPlayers ? '✅ نعم' : '❌ لا'}
• جميع اللاعبين جاهزون: ${allPlayersReady ? '✅ نعم' : '❌ لا'}
• لاعبون في كلا الفريقين: ${hasPlayersInBothTeams ? '✅ نعم' : '❌ لا'}
• لا يوجد لاعبون بدون فريق: ${noUnassignedPlayers ? '✅ نعم' : '❌ لا'}
• أنت المضيف: ${isHost ? '✅ نعم' : '❌ لا'}

🎮 النتيجة النهائية: ${canStartGame ? '✅ يمكن بدء اللعبة' : '❌ لا يمكن بدء اللعبة'}

👥 تفاصيل اللاعبين:
${players.map(p => `• ${p.player_name}: فريق ${p.team || 'بدون'}, جاهز: ${p.is_ready} (نوع: ${typeof p.is_ready})`).join('\n')}

📝 ملاحظة: راجع Console (F12) للمزيد من التفاصيل التقنية
                `;
                alert(debugInfo);
              }}
              className="px-8 py-4 bg-yellow-500 text-black font-bold text-lg rounded-xl hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              🔍 اضغط هنا للتشخيص السريع
            </button>
          </div>
        </div>

        {/* Start Game Button */}
        <div className="text-center">
          {/* Developer Testing Info */}
          <div className="mb-6 bg-yellow-500/10 border border-yellow-400/30 rounded-xl p-4">
            <h4 className="text-yellow-300 font-bold mb-2">💡 نصائح للاختبار:</h4>
            <div className="text-yellow-200 text-sm space-y-1">
              <p>• افتح عدة تبويبات لمحاكاة لاعبين متعددين</p>
              <p>• استخدم النوافذ الخاصة (Incognito) لتجنب تضارب البيانات</p>
              <p>• كل تبويب يمثل لاعب منفصل</p>
              <p>• شاهد التحديثات المباشرة عند تحرك اللاعبين</p>
              <p>• ✅ لا يحتاج ضغط "جاهز" - بدء فوري!</p>
              <p>• فقط المضيف يمكنه بدء اللعبة</p>
              <p>• يكفي وجود لاعب في كل فريق لبدء اللعبة</p>
              <p>• البوتات تنضم تلقائياً للفريق المناسب</p>
            </div>
          </div>
          
          <button
            data-start-game
            onClick={handleStartGame}
            disabled={!canStartGame}
            className="px-12 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-xl rounded-2xl hover:from-purple-700 hover:to-pink-700 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-3 mx-auto"
          >
            <Play className="w-6 h-6" />
            {isHost ? 'ابدأ اللعبة' : 'في انتظار المضيف'}
          </button>
          
          {!canStartGame && (
            <div className="mt-4 space-y-2">
              {!hasMinimumPlayers && (
                <p className="text-red-300">
                  يجب وجود لاعبين على الأقل ({players.length}/2)
                </p>
              )}
              {!hasPlayersInBothTeams && (
                <p className="text-yellow-300">
                  يجب وجود لاعب في كل فريق (أحمر: {redTeamPlayers.length}, أزرق: {blueTeamPlayers.length})
                </p>
              )}
              {!noUnassignedPlayers && (
                <p className="text-yellow-300">
                  يوجد {unassignedPlayers.length} لاعب لم ينضم لأي فريق
                  <span className="block text-red-300 text-sm mt-1">
                    بدون فريق: {unassignedPlayers.map(p => p.player_name).join(', ')}
                  </span>
                </p>
              )}
              {!isHost && (
                <p className="text-blue-300">
                  فقط المضيف يمكنه بدء اللعبة
                </p>
              )}
              
              {/* معلومات تشخيصية */}
              <div className="mt-4 bg-gray-500/10 border border-gray-400/30 rounded-xl p-3">
                <div className="text-gray-300 text-sm space-y-1">
                  <p>📊 حالة اللاعبين:</p>
                  <p>• إجمالي اللاعبين: {players.length}</p>
                  <p>• الفريق الأحمر: {redTeamPlayers.length} لاعب</p>
                  <p>• الفريق الأزرق: {blueTeamPlayers.length} لاعب</p>
                  <p>• لاعبون بدون فريق: {unassignedPlayers.length} لاعب</p>
                  <p>• أنت المضيف: {isHost ? 'نعم' : 'لا'}</p>
                  
                  <div className="mt-2 p-2 bg-blue-500/10 rounded border border-blue-400/30">
                    <p className="text-blue-300 font-bold">🔍 تفاصيل اللاعبين:</p>
                    {players.map((player, index) => (
                      <p key={index} className="text-xs">
                        • {player.player_name} - فريق: {player.team || 'بدون'}
                        {player.player_name.includes('🤖') && ' (بوت)'}
                        {player.player_id === lobbyState.playerId && ' (أنت)'}
                      </p>
                    ))}
                  </div>
                  
                  <p className="mt-2">🔍 فحص الشروط:</p>
                  <p>• عدد كافي من اللاعبين: {hasMinimumPlayers ? '✅' : '❌'}</p>
                  <p>• لاعبون في كلا الفريقين: {hasPlayersInBothTeams ? '✅' : '❌'}</p>
                  <p>• لا يوجد لاعبون بدون فريق: {noUnassignedPlayers ? '✅' : '❌'}</p>
                  <p>• أنت المضيف: {isHost ? '✅' : '❌'}</p>
                  <p className="mt-2 font-bold">• يمكن بدء اللعبة: {canStartGame ? '✅ نعم' : '❌ لا'}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Game Rules */}
        <div className="mt-12 bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
          <h3 className="text-2xl font-bold text-white text-center mb-4">قواعد اللعبة الأونلاين</h3>
          
          {/* تحذير للمضيف */}
          {isHost && (
            <div className="mb-6 bg-yellow-500/10 border border-yellow-400/30 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Crown className="w-5 h-5 text-yellow-400" />
                <h4 className="text-yellow-300 font-bold">تنبيه للمضيف:</h4>
              </div>
              <div className="text-yellow-200 text-sm space-y-1">
                <p>• إذا غادرت الغرفة، سيتم حذفها نهائياً</p>
                <p>• جميع اللاعبين سيتم إخراجهم من الغرفة</p>
                <p>• تأكد من إنهاء اللعبة قبل المغادرة</p>
              </div>
            </div>
          )}
          
          <div className="grid md:grid-cols-3 gap-6 text-white/80">
            <div>
              <h4 className="font-semibold text-blue-300 mb-2">نظام الفرق:</h4>
              <ul className="space-y-1 text-sm">
                <li>• انضم لأي فريق تريد</li>
                <li>• يجب وجود لاعب في كل فريق</li>
                <li>• جميع اللاعبين يجب أن يكونوا جاهزين</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-green-300 mb-2">اللعب الأونلاين:</h4>
              <ul className="space-y-1 text-sm">
                <li>• تزامن مباشر بين جميع اللاعبين</li>
                <li>• نفس قواعد اللعبة العادية</li>
                <li>• إمكانية مشاهدة إجابات الآخرين</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-purple-300 mb-2">المضيف:</h4>
              <ul className="space-y-1 text-sm">
                <li>• يتحكم في بدء اللعبة</li>
                <li>• مسؤول عن الغرفة</li>
                <li>• مغادرته تحذف الغرفة</li>
              </ul>
              <p>• يمكن بدء اللعبة: {canStartGame ? 'نعم ✅' : 'لا ❌'}</p>
              <p>• الشروط المطلوبة:</p>
              <p className="ml-4">- أنت المضيف: {isHost ? '✅' : '❌'}</p>
              <p className="ml-4">- جميع اللاعبين جاهزون: {allPlayersReady ? '✅' : '❌'}</p>
              <p className="ml-4">- لاعبون في كلا الفريقين: {hasPlayersInBothTeams ? '✅' : '❌'}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameRoom;