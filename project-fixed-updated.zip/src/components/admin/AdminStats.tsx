import React from 'react';
import { BarChart3, TrendingUp, Users, BookOpen, Target, Activity, Clock, Award } from 'lucide-react';
import { AdminStats as AdminStatsType } from '../../types/admin';

interface AdminStatsProps {
  stats: AdminStatsType;
  detailed?: boolean;
}

const AdminStats: React.FC<AdminStatsProps> = ({ stats, detailed = false }) => {
  const difficultyColors = {
    easy: 'from-green-500 to-emerald-600',
    medium: 'from-yellow-500 to-orange-600',
    hard: 'from-red-500 to-pink-600'
  };

  const difficultyNames = {
    easy: 'سهل',
    medium: 'متوسط',
    hard: 'صعب'
  };

  if (!detailed) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 backdrop-blur-md rounded-2xl p-6 border border-blue-400/30">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold text-white">{stats.totalCategories}</div>
              <div className="text-blue-200">إجمالي التخصصات</div>
            </div>
            <BookOpen className="w-12 h-12 text-blue-400" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 backdrop-blur-md rounded-2xl p-6 border border-green-400/30">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold text-white">{stats.totalQuestions}</div>
              <div className="text-green-200">إجمالي الأسئلة</div>
            </div>
            <Users className="w-12 h-12 text-green-400" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-500/20 to-indigo-500/20 backdrop-blur-md rounded-2xl p-6 border border-purple-400/30">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold text-white">{stats.questionsByDifficulty.easy}</div>
              <div className="text-purple-200">أسئلة سهلة</div>
            </div>
            <Target className="w-12 h-12 text-purple-400" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-orange-500/20 to-red-500/20 backdrop-blur-md rounded-2xl p-6 border border-orange-400/30">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold text-white">{stats.questionsByDifficulty.hard}</div>
              <div className="text-orange-200">أسئلة صعبة</div>
            </div>
            <Award className="w-12 h-12 text-orange-400" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 backdrop-blur-md rounded-2xl p-6 border border-blue-400/30">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold text-white">{stats.totalCategories}</div>
              <div className="text-blue-200">إجمالي التخصصات</div>
            </div>
            <BookOpen className="w-12 h-12 text-blue-400" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 backdrop-blur-md rounded-2xl p-6 border border-green-400/30">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold text-white">{stats.totalQuestions}</div>
              <div className="text-green-200">إجمالي الأسئلة</div>
            </div>
            <Users className="w-12 h-12 text-green-400" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-500/20 to-indigo-500/20 backdrop-blur-md rounded-2xl p-6 border border-purple-400/30">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold text-white">
                {Math.round((stats.questionsByDifficulty.easy / stats.totalQuestions) * 100) || 0}%
              </div>
              <div className="text-purple-200">نسبة الأسئلة السهلة</div>
            </div>
            <TrendingUp className="w-12 h-12 text-purple-400" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-orange-500/20 to-red-500/20 backdrop-blur-md rounded-2xl p-6 border border-orange-400/30">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold text-white">
                {Object.keys(stats.questionsByCategory).length}
              </div>
              <div className="text-orange-200">تخصصات نشطة</div>
            </div>
            <Activity className="w-12 h-12 text-orange-400" />
          </div>
        </div>
      </div>

      {/* Difficulty Distribution */}
      <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-blue-400" />
          توزيع الأسئلة حسب الصعوبة
        </h3>
        
        <div className="space-y-4">
          {Object.entries(stats.questionsByDifficulty).map(([difficulty, count]) => {
            const percentage = stats.totalQuestions > 0 ? (count / stats.totalQuestions) * 100 : 0;
            return (
              <div key={difficulty} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-white font-semibold">
                    {difficultyNames[difficulty as keyof typeof difficultyNames]}
                  </span>
                  <span className="text-white/70">
                    {count} سؤال ({percentage.toFixed(1)}%)
                  </span>
                </div>
                <div className="w-full bg-white/10 rounded-full h-3">
                  <div 
                    className={`h-3 rounded-full bg-gradient-to-r ${difficultyColors[difficulty as keyof typeof difficultyColors]}`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Questions by Category */}
      <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <BookOpen className="w-6 h-6 text-green-400" />
          توزيع الأسئلة حسب التخصص
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Object.entries(stats.questionsByCategory).map(([category, count]) => {
            const percentage = stats.totalQuestions > 0 ? (count / stats.totalQuestions) * 100 : 0;
            return (
              <div key={category} className="bg-white/5 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-semibold">{category}</span>
                  <span className="text-white/70">{count} سؤال</span>
                </div>
                <div className="w-full bg-white/10 rounded-full h-2">
                  <div 
                    className="h-2 rounded-full bg-gradient-to-r from-purple-500 to-pink-500"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <div className="text-white/60 text-sm mt-1">
                  {percentage.toFixed(1)}% من إجمالي الأسئلة
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <Clock className="w-6 h-6 text-yellow-400" />
          النشاط الأخير
        </h3>
        
        <div className="space-y-3">
          {stats.recentActivity.length === 0 ? (
            <div className="text-center py-8 text-white/50">
              لا يوجد نشاط حديث
            </div>
          ) : (
            stats.recentActivity.map(activity => (
              <div key={activity.id} className="bg-white/5 rounded-xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    activity.type === 'create' ? 'bg-green-500/20 text-green-400' :
                    activity.type === 'update' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {activity.type === 'create' ? '+' : activity.type === 'update' ? '✎' : '×'}
                  </div>
                  <div>
                    <div className="text-white font-semibold">
                      {activity.type === 'create' ? 'إنشاء' :
                       activity.type === 'update' ? 'تحديث' : 'حذف'} {
                       activity.entity === 'category' ? 'تخصص' : 'سؤال'
                      }
                    </div>
                    <div className="text-white/70 text-sm truncate max-w-md">
                      {activity.entityName}
                    </div>
                  </div>
                </div>
                <div className="text-white/50 text-sm">
                  {new Date(activity.timestamp).toLocaleDateString('ar-SA', {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Performance Insights */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Target className="w-5 h-5 text-purple-400" />
            نصائح التحسين
          </h3>
          <div className="space-y-3 text-sm">
            {stats.totalQuestions < 50 && (
              <div className="bg-yellow-500/10 border border-yellow-400/30 rounded-lg p-3">
                <div className="text-yellow-300 font-semibold">💡 نصيحة</div>
                <div className="text-yellow-200">أضف المزيد من الأسئلة لتحسين تنوع اللعبة</div>
              </div>
            )}
            {stats.questionsByDifficulty.medium < stats.questionsByDifficulty.easy * 0.5 && (
              <div className="bg-blue-500/10 border border-blue-400/30 rounded-lg p-3">
                <div className="text-blue-300 font-semibold">📊 توازن</div>
                <div className="text-blue-200">أضف المزيد من الأسئلة متوسطة الصعوبة</div>
              </div>
            )}
            {Object.keys(stats.questionsByCategory).length < 5 && (
              <div className="bg-green-500/10 border border-green-400/30 rounded-lg p-3">
                <div className="text-green-300 font-semibold">🎯 تنويع</div>
                <div className="text-green-200">أضف المزيد من التخصصات المختلفة</div>
              </div>
            )}
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Award className="w-5 h-5 text-gold-400" />
            إحصائيات سريعة
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-white/70">متوسط الأسئلة لكل تخصص:</span>
              <span className="text-white font-semibold">
                {stats.totalCategories > 0 ? Math.round(stats.totalQuestions / stats.totalCategories) : 0}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/70">أكثر تخصص أسئلة:</span>
              <span className="text-white font-semibold">
                {Object.entries(stats.questionsByCategory).length > 0 
                  ? Object.entries(stats.questionsByCategory).reduce((a, b) => a[1] > b[1] ? a : b)[0]
                  : 'لا يوجد'
                }
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/70">نسبة الأسئلة الصعبة:</span>
              <span className="text-white font-semibold">
                {stats.totalQuestions > 0 
                  ? Math.round((stats.questionsByDifficulty.hard / stats.totalQuestions) * 100)
                  : 0
                }%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminStats;