import React, { useState } from 'react';
import { Plus, Edit, Trash2, Save, X, ChevronDown } from 'lucide-react';
import { Category } from '../../types/admin';
import { getIconComponent } from '../../lib/icons';

interface CategoriesManagerProps {
  categories: Category[];
  onCreateCategory: (category: Omit<Category, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onUpdateCategory: (id: string, updates: Partial<Category>) => void;
  onDeleteCategory: (id: string) => void;
}

const CategoriesManager: React.FC<CategoriesManagerProps> = ({
  categories,
  onCreateCategory,
  onUpdateCategory,
  onDeleteCategory
}) => {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showIconDropdown, setShowIconDropdown] = useState(false);
  const [formData, setFormData] = useState({
    nameAr: '',
    nameEn: '',
    icon: 'BookOpen',
    color: 'from-blue-500 to-cyan-600',
    description: ''
  });

  const iconOptions = [
    { name: 'BookOpen', label: 'كتاب' },
    { name: 'Globe', label: 'كرة أرضية' },
    { name: 'Atom', label: 'ذرة' },
    { name: 'Smartphone', label: 'هاتف' },
    { name: 'PenTool', label: 'قلم' },
    { name: 'Trophy', label: 'كأس' },
    { name: 'Music', label: 'موسيقى' },
    { name: 'Camera', label: 'كاميرا' },
    { name: 'Heart', label: 'قلب' },
    { name: 'Star', label: 'نجمة' },
    { name: 'Zap', label: 'برق' },
    { name: 'Shield', label: 'درع' },
    { name: 'Crown', label: 'تاج' },
    { name: 'Gem', label: 'جوهرة' },
    { name: 'Rocket', label: 'صاروخ' },
    { name: 'Coffee', label: 'قهوة' },
    { name: 'Gamepad2', label: 'لعبة' },
    { name: 'Brain', label: 'دماغ' },
    { name: 'Calculator', label: 'آلة حاسبة' },
    { name: 'Palette', label: 'لوحة ألوان' },
    { name: 'Microscope', label: 'مجهر' },
    { name: 'Dna', label: 'حمض نووي' },
    { name: 'FlaskConical', label: 'قارورة' },
    { name: 'Telescope', label: 'تلسكوب' },
    { name: 'Mountain', label: 'جبل' },
    { name: 'Plane', label: 'طائرة' },
    { name: 'Car', label: 'سيارة' },
    { name: 'Ship', label: 'سفينة' },
    { name: 'Train', label: 'قطار' },
    { name: 'Home', label: 'منزل' },
    { name: 'Building', label: 'مبنى' },
    { name: 'Factory', label: 'مصنع' },
    { name: 'School', label: 'مدرسة' },
    { name: 'Cross', label: 'مستشفى' },
    { name: 'Church', label: 'كنيسة' },
    { name: 'TreePine', label: 'شجرة' },
    { name: 'Flower', label: 'زهرة' },
    { name: 'Sun', label: 'شمس' },
    { name: 'Moon', label: 'قمر' },
    { name: 'Cloud', label: 'سحابة' },
    { name: 'Snowflake', label: 'ندفة ثلج' },
    { name: 'Flame', label: 'لهب' },
    { name: 'Droplets', label: 'قطرات' },
    { name: 'Wind', label: 'رياح' },
    { name: 'Eye', label: 'عين' },
    { name: 'Ear', label: 'أذن' },
    { name: 'Hand', label: 'يد' },
    { name: 'Footprints', label: 'آثار أقدام' },
    { name: 'Smile', label: 'ابتسامة' },
    { name: 'Frown', label: 'عبوس' },
    { name: 'ThumbsUp', label: 'إعجاب' },
    { name: 'ThumbsDown', label: 'عدم إعجاب' },
    { name: 'Clock', label: 'ساعة' },
    { name: 'Calendar', label: 'تقويم' },
    { name: 'Bell', label: 'جرس' },
    { name: 'Phone', label: 'هاتف' },
    { name: 'Mail', label: 'بريد' },
    { name: 'MessageCircle', label: 'رسالة' },
    { name: 'Users', label: 'مستخدمون' },
    { name: 'User', label: 'مستخدم' },
    { name: 'UserCheck', label: 'مستخدم موافق' },
    { name: 'UserX', label: 'مستخدم مرفوض' },
    { name: 'Settings', label: 'إعدادات' },
    { name: 'Wrench', label: 'مفتاح ربط' },
    { name: 'Hammer', label: 'مطرقة' },
    { name: 'Scissors', label: 'مقص' },
    { name: 'Paintbrush', label: 'فرشاة رسم' },
    { name: 'Brush', label: 'فرشاة' },
    { name: 'Pen', label: 'قلم حبر' },
    { name: 'Pencil', label: 'قلم رصاص' },
    { name: 'Eraser', label: 'ممحاة' },
    { name: 'Ruler', label: 'مسطرة' },
    { name: 'Compass', label: 'بوصلة' },
    { name: 'Map', label: 'خريطة' },
    { name: 'MapPin', label: 'دبوس خريطة' },
    { name: 'Navigation', label: 'ملاحة' },
    { name: 'Flag', label: 'علم' },
    { name: 'Target', label: 'هدف' },
    { name: 'Award', label: 'جائزة' },
    { name: 'Medal', label: 'ميدالية' },
    { name: 'Gift', label: 'هدية' },
    { name: 'ShoppingCart', label: 'عربة تسوق' },
    { name: 'CreditCard', label: 'بطاقة ائتمان' },
    { name: 'DollarSign', label: 'دولار' },
    { name: 'Euro', label: 'يورو' },
    { name: 'PoundSterling', label: 'جنيه استرليني' },
    { name: 'Coins', label: 'عملات' },
    { name: 'Banknote', label: 'ورقة نقدية' },
    { name: 'Wallet', label: 'محفظة' },
    { name: 'Key', label: 'مفتاح' },
    { name: 'Lock', label: 'قفل' },
    { name: 'Unlock', label: 'فتح القفل' }
  ];

  const colorOptions = [
    'from-blue-500 to-cyan-600',
    'from-purple-500 to-indigo-600',
    'from-green-500 to-emerald-600',
    'from-red-500 to-pink-600',
    'from-yellow-500 to-orange-600',
    'from-pink-500 to-rose-600',
    'from-indigo-500 to-purple-600',
    'from-teal-500 to-cyan-600',
    'from-orange-500 to-red-600',
    'from-emerald-500 to-teal-600'
  ];

  const resetForm = () => {
    setFormData({
      nameAr: '',
      nameEn: '',
      icon: 'BookOpen',
      color: 'from-blue-500 to-cyan-600',
      description: ''
    });
    setShowCreateForm(false);
    setEditingId(null);
    setShowIconDropdown(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nameAr.trim()) {
      alert('يرجى إدخال اسم التخصص باللغة العربية');
      return;
    }

    // إضافة معالجة الأخطاء
    try {
      if (editingId) {
        onUpdateCategory(editingId, formData);
      } else {
        onCreateCategory(formData);
      }
      resetForm();
    } catch (error) {
      console.error('❌ خطأ في معالجة النموذج:', error);
      // لا نحتاج alert هنا لأن الخطأ سيتم معالجته في الـ hook
    }
  };

  const startEdit = (category: Category) => {
    console.log('🔧 بدء تعديل التخصص:', category);
    setFormData({
      nameAr: category.nameAr,
      nameEn: category.nameEn,
      icon: category.icon,
      color: category.color,
      description: category.description || ''
    });
    setEditingId(category.id);
    setShowCreateForm(true);
    setShowIconDropdown(false);
  };

  const handleDelete = (category: Category) => {
    if (window.confirm(`هل أنت متأكد من حذف تخصص "${category.nameAr}"؟\n\nسيتم حذف جميع الأسئلة المرتبطة به أيضاً.`)) {
      onDeleteCategory(category.id);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h3 className="text-3xl font-bold bg-gradient-to-r from-white to-green-200 bg-clip-text text-transparent mb-2">
            إدارة التخصصات
          </h3>
          <p className="text-white/70 text-lg">إضافة وتعديل وحذف التخصصات ({categories.length} تخصص)</p>
        </div>
        <button
          onClick={() => setShowCreateForm(true)}
          className="flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-2xl hover:from-green-600 hover:to-emerald-600 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-green-500/25"
        >
          <Plus className="w-6 h-6" />
          إضافة تخصص جديد
        </button>
      </div>

      {/* Create/Edit Form */}
      {showCreateForm && (
        <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-md rounded-3xl p-8 border border-white/20 shadow-2xl">
          <div className="flex items-center justify-between mb-6">
            <h4 className="text-2xl font-bold text-white flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                {editingId ? <Edit className="w-5 h-5 text-white" /> : <Plus className="w-5 h-5 text-white" />}
              </div>
              {editingId ? 'تعديل التخصص' : 'إضافة تخصص جديد'}
            </h4>
            <button
              onClick={resetForm}
              className="w-10 h-10 bg-red-500/20 text-red-400 rounded-2xl flex items-center justify-center hover:bg-red-500/30 transition-all duration-300 transform hover:scale-110"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-white/80 mb-2">الاسم بالعربية *</label>
                <input
                  type="text"
                  value={formData.nameAr}
                  onChange={(e) => setFormData(prev => ({ ...prev, nameAr: e.target.value }))}
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400"
                  placeholder="مثال: التاريخ"
                  required
                />
              </div>

              <div>
                <label className="block text-white/80 mb-2">الاسم بالإنجليزية</label>
                <input
                  type="text"
                  value={formData.nameEn}
                  onChange={(e) => setFormData(prev => ({ ...prev, nameEn: e.target.value }))}
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400"
                  placeholder="Example: History"
                />
              </div>
            </div>

            <div>
              <label className="block text-white/80 mb-2">الوصف</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400"
                placeholder="وصف مختصر للتخصص..."
                rows={3}
              />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-white/80 mb-2">الأيقونة</label>
                <div className="relative">
                  {/* زر فتح القائمة */}
                  <button
                    type="button"
                    onClick={() => setShowIconDropdown(!showIconDropdown)}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400 flex items-center justify-between hover:bg-white/20 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      {(() => {
                        const IconComponent = getIconComponent(formData.icon);
                        return <IconComponent className="w-5 h-5 text-purple-400" />;
                      })()}
                      <span>{iconOptions.find(opt => opt.name === formData.icon)?.label || 'اختر أيقونة'}</span>
                    </div>
                    <ChevronDown className={`w-4 h-4 text-white/70 transition-transform ${showIconDropdown ? 'rotate-180' : ''}`} />
                  </button>

                  {/* القائمة المنسدلة المخصصة */}
                  {showIconDropdown && (
                    <div className="absolute top-full left-0 right-0 mt-1 bg-gray-800 border border-white/20 rounded-xl shadow-xl z-50 max-h-60 overflow-y-auto">
                      {iconOptions.map(iconOption => {
                        const IconComponent = getIconComponent(iconOption.name);
                        return (
                          <button
                            key={iconOption.name}
                            type="button"
                            onClick={() => {
                              setFormData(prev => ({ ...prev, icon: iconOption.name }));
                              setShowIconDropdown(false);
                            }}
                            className={`w-full p-3 flex items-center gap-3 hover:bg-white/10 transition-all text-left ${
                              formData.icon === iconOption.name ? 'bg-purple-500/20 text-purple-300' : 'text-white'
                            }`}
                          >
                            <IconComponent className="w-5 h-5 text-purple-400" />
                            <span>{iconOption.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-white/80 mb-2">اللون</label>
                <div className="grid grid-cols-5 gap-2">
                  {colorOptions.map(color => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, color }))}
                      className={`w-12 h-12 rounded-xl bg-gradient-to-r ${color} border-2 transition-all ${
                        formData.color === color ? 'border-white' : 'border-transparent hover:border-white/50'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <button
                type="submit"
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-emerald-600 transition-all duration-300"
              >
                <Save className="w-5 h-5" />
                {editingId ? 'حفظ التعديلات' : 'إضافة التخصص'}
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="px-6 py-3 bg-gray-500/20 text-gray-300 rounded-xl hover:bg-gray-500/30 transition-all"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Categories List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map(category => {
          const IconComponent = getIconComponent(category.icon);
          
          return (
            <div
              key={category.id}
              className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 hover:border-white/40 transition-all duration-300"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${category.color} flex items-center justify-center`}>
                  <IconComponent className="w-6 h-6 text-white" />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => startEdit(category)}
                    className="w-8 h-8 bg-blue-500/20 text-blue-400 rounded-full flex items-center justify-center hover:bg-blue-500/30 transition-all"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(category)}
                    className="w-8 h-8 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center hover:bg-red-500/30 transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <h4 className="text-xl font-bold text-white mb-2">{category.nameAr}</h4>
              {category.nameEn && (
                <p className="text-white/60 text-sm mb-3">{category.nameEn}</p>
              )}
              {category.description && (
                <p className="text-white/70 text-sm mb-4">{category.description}</p>
              )}

              <div className="text-white/50 text-xs">
                تم الإنشاء: {new Date(category.createdAt).toLocaleDateString('ar-SA')}
              </div>
            </div>
          );
        })}
      </div>

      {categories.length === 0 && (
        <div className="text-center py-12">
          <div className="text-white/50 text-xl mb-4">لا توجد تخصصات بعد</div>
          <button
            onClick={() => setShowCreateForm(true)}
            className="px-6 py-3 bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-bold rounded-xl hover:from-purple-600 hover:to-indigo-600 transition-all duration-300 transform hover:scale-105"
          >
            إضافة أول تخصص
          </button>
        </div>
      )}
    </div>
  );
};

export default CategoriesManager;