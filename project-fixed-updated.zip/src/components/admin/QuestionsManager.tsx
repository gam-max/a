import React, { useState } from 'react';
import { Plus, Edit, Trash2, Save, X, Eye, EyeOff, Tag } from 'lucide-react';
import { AdminQuestion, Category } from '../../types/admin';

interface QuestionsManagerProps {
  questions: AdminQuestion[];
  categories: Category[];
  onCreateQuestion: (question: Omit<AdminQuestion, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onUpdateQuestion: (id: string, updates: Partial<AdminQuestion>) => void;
  onDeleteQuestion: (id: string) => void;
}

const QuestionsManager: React.FC<QuestionsManagerProps> = ({
  questions,
  categories,
  onCreateQuestion,
  onUpdateQuestion,
  onDeleteQuestion
}) => {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    categoryId: '',
    question: '',
    type: 'multiple_choice' as 'multiple_choice' | 'text',
    options: ['', '', '', ''],
    correctAnswer: 0,
    difficulty: 'easy' as 'easy' | 'medium' | 'hard',
    difficultyLevel: 1,
    points: 10,
    explanation: '',
    notes: '',
    tags: [] as string[],
    isActive: true
  });
  const [newTag, setNewTag] = useState('');

  const resetForm = () => {
    setFormData({
      categoryId: '',
      question: '',
      type: 'multiple_choice',
      options: ['', '', '', ''],
      correctAnswer: 0,
      difficulty: 'easy',
      difficultyLevel: 1,
      points: 10,
      explanation: '',
      notes: '',
      tags: [],
      isActive: true
    });
    setShowCreateForm(false);
    setEditingId(null);
    setNewTag('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.question.trim()) {
      alert('يرجى إدخال نص السؤال');
      return;
    }

    if (!formData.categoryId) {
      alert('يرجى اختيار التخصص');
      return;
    }

    if (formData.type === 'multiple_choice') {
      if (formData.options.some(opt => !opt.trim())) {
        alert('يرجى ملء جميع الخيارات');
        return;
      }
    }

    const questionData = {
      ...formData,
      correctAnswer: formData.type === 'multiple_choice' ? formData.correctAnswer : formData.options[0]
    };

    // إضافة معالجة الأخطاء
    try {
      if (editingId) {
        onUpdateQuestion(editingId, questionData);
      } else {
        onCreateQuestion(questionData);
      }
      resetForm();
    } catch (error) {
      console.error('❌ خطأ في معالجة النموذج:', error);
      // لا نحتاج alert هنا لأن الخطأ سيتم معالجته في الـ hook
    }
  };

  const startEdit = (question: AdminQuestion) => {
    setFormData({
      categoryId: question.categoryId,
      question: question.question,
      type: question.type,
      options: question.options,
      correctAnswer: typeof question.correctAnswer === 'number' ? question.correctAnswer : 0,
      difficulty: question.difficulty,
      difficultyLevel: question.difficultyLevel,
      points: question.points,
      explanation: question.explanation || '',
      notes: question.notes || '',
      tags: question.tags,
      isActive: question.isActive
    });
    setEditingId(question.id);
    setShowCreateForm(true);
  };

  const handleDelete = (question: AdminQuestion) => {
    if (window.confirm(`هل أنت متأكد من حذف هذا السؤال؟\n\n"${question.question.substring(0, 100)}..."`)) {
      onDeleteQuestion(question.id);
    }
  };

  const updateOption = (index: number, value: string) => {
    const newOptions = [...formData.options];
    newOptions[index] = value;
    setFormData(prev => ({ ...prev, options: newOptions }));
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData(prev => ({ ...prev, tags: [...prev.tags, newTag.trim()] }));
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setFormData(prev => ({ ...prev, tags: prev.tags.filter(tag => tag !== tagToRemove) }));
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'hard': return 'text-red-400';
      default: return 'text-white';
    }
  };

  const getDifficultyName = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'سهل';
      case 'medium': return 'متوسط';
      case 'hard': return 'صعب';
      default: return difficulty;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h3 className="text-3xl font-bold bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent mb-2">
            إدارة الأسئلة
          </h3>
          <p className="text-white/70 text-lg">إضافة وتعديل وحذف الأسئلة ({questions.length} سؤال)</p>
        </div>
        <button
          onClick={() => setShowCreateForm(true)}
          className="flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-2xl hover:from-green-600 hover:to-emerald-600 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-green-500/25"
        >
          <Plus className="w-6 h-6" />
          إضافة سؤال جديد
        </button>
      </div>

      {/* Create/Edit Form */}
      {showCreateForm && (
        <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-md rounded-3xl p-8 border border-white/20 shadow-2xl">
          <div className="flex items-center justify-between mb-6">
            <h4 className="text-2xl font-bold text-white flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                {editingId ? <Edit className="w-5 h-5 text-white" /> : <Plus className="w-5 h-5 text-white" />}
              </div>
              {editingId ? 'تعديل السؤال' : 'إضافة سؤال جديد'}
            </h4>
            <button
              onClick={resetForm}
              className="w-10 h-10 bg-red-500/20 text-red-400 rounded-2xl flex items-center justify-center hover:bg-red-500/30 transition-all duration-300 transform hover:scale-110"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Info */}
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-white/80 mb-2">التخصص *</label>
                <select
                  value={formData.categoryId}
                  onChange={(e) => setFormData(prev => ({ ...prev, categoryId: e.target.value }))}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400"
                  required
                >
                  <option value="" className="bg-gray-800 text-white">اختر التخصص</option>
                  {categories.map(cat => (
                    <option key={cat.id} value={cat.id} className="bg-gray-800 text-white">{cat.nameAr}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-white/80 mb-2">نوع السؤال</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value as any }))}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400"
                >
                  <option value="multiple_choice" className="bg-gray-800 text-white">اختيار متعدد</option>
                  <option value="text" className="bg-gray-800 text-white">إجابة نصية</option>
                </select>
              </div>
            </div>

            {/* Question */}
            <div>
              <label className="block text-white/80 mb-2">نص السؤال *</label>
              <textarea
                value={formData.question}
                onChange={(e) => setFormData(prev => ({ ...prev, question: e.target.value }))}
                className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400"
                placeholder="اكتب السؤال هنا..."
                rows={3}
                required
              />
            </div>

            {/* Options for Multiple Choice */}
            {formData.type === 'multiple_choice' && (
              <div>
                <label className="block text-white/80 mb-2">الخيارات *</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {formData.options.map((option, index) => (
                    <div key={index} className="relative">
                      <input
                        type="text"
                        value={option}
                        onChange={(e) => updateOption(index, e.target.value)}
                        className={`w-full p-3 bg-white/10 border rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400 ${
                          formData.correctAnswer === index ? 'border-green-400' : 'border-white/20'
                        }`}
                        placeholder={`الخيار ${String.fromCharCode(65 + index)}`}
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, correctAnswer: index }))}
                        className={`absolute left-2 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-full border-2 flex items-center justify-center text-xs font-bold ${
                          formData.correctAnswer === index
                            ? 'bg-green-500 border-green-400 text-white'
                            : 'border-white/40 text-white/60 hover:border-green-400'
                        }`}
                        title="الإجابة الصحيحة"
                      >
                        ✓
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Text Answer */}
            {formData.type === 'text' && (
              <div>
                <label className="block text-white/80 mb-2">الإجابة الصحيحة *</label>
                <input
                  type="text"
                  value={formData.options[0]}
                  onChange={(e) => updateOption(0, e.target.value)}
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400"
                  placeholder="الإجابة الصحيحة..."
                  required
                />
              </div>
            )}

            {/* Difficulty and Points */}
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <label className="block text-white/80 mb-2">مستوى الصعوبة</label>
                <select
                  value={formData.difficulty}
                  onChange={(e) => {
                    const difficulty = e.target.value as 'easy' | 'medium' | 'hard';
                    const points = difficulty === 'easy' ? 10 : difficulty === 'medium' ? 20 : 30;
                    const difficultyLevel = difficulty === 'easy' ? 1 : difficulty === 'medium' ? 3 : 5;
                    setFormData(prev => ({ ...prev, difficulty, points, difficultyLevel }));
                  }}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400"
                >
                  <option value="easy" className="bg-gray-800 text-white">سهل</option>
                  <option value="medium" className="bg-gray-800 text-white">متوسط</option>
                  <option value="hard" className="bg-gray-800 text-white">صعب</option>
                </select>
              </div>

              <div>
                <label className="block text-white/80 mb-2">مستوى الصعوبة (1-5)</label>
                <input
                  type="number"
                  min="1"
                  max="5"
                  value={formData.difficultyLevel}
                  onChange={(e) => setFormData(prev => ({ ...prev, difficultyLevel: parseInt(e.target.value) || 1 }))}
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400"
                />
              </div>

              <div>
                <label className="block text-white/80 mb-2">النقاط</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={formData.points}
                  onChange={(e) => setFormData(prev => ({ ...prev, points: parseInt(e.target.value) || 10 }))}
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400"
                />
              </div>
            </div>

            {/* Explanation and Notes */}
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-white/80 mb-2">الشرح (اختياري)</label>
                <textarea
                  value={formData.explanation}
                  onChange={(e) => setFormData(prev => ({ ...prev, explanation: e.target.value }))}
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400"
                  placeholder="شرح الإجابة الصحيحة..."
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-white/80 mb-2">ملاحظات (اختياري)</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400"
                  placeholder="ملاحظات إضافية..."
                  rows={3}
                />
              </div>
            </div>

            {/* Tags */}
            <div>
              <label className="block text-white/80 mb-2">العلامات</label>
              <div className="flex gap-2 mb-3">
                <input
                  type="text"
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                  className="flex-1 p-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400"
                  placeholder="إضافة علامة..."
                />
                <button
                  type="button"
                  onClick={addTag}
                  className="px-4 py-3 bg-purple-500/20 text-purple-400 rounded-xl hover:bg-purple-500/30 transition-all"
                >
                  <Tag className="w-4 h-4" />
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.tags.map(tag => (
                  <span
                    key={tag}
                    className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm flex items-center gap-2"
                  >
                    {tag}
                    <button
                      type="button"
                      onClick={() => removeTag(tag)}
                      className="w-4 h-4 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center hover:bg-red-500/30"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>

            {/* Active Status */}
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.isActive}
                  onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
                  className="w-5 h-5 text-purple-500 bg-white/10 border-white/20 rounded focus:ring-purple-400"
                />
                <span className="text-white">السؤال نشط</span>
              </label>
            </div>

            <div className="flex gap-4">
              <button
                type="submit"
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-emerald-600 transition-all duration-300"
              >
                <Save className="w-5 h-5" />
                {editingId ? 'حفظ التعديلات' : 'إضافة السؤال'}
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="px-6 py-3 bg-gray-500/20 text-gray-300 rounded-xl hover:bg-gray-500/30 transition-all"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Questions List */}
      <div className="space-y-4">
        {questions.map(question => {
          const category = categories.find(c => c.id === question.categoryId);
          return (
            <div
              key={question.id}
              className={`bg-white/10 backdrop-blur-md rounded-2xl p-6 border transition-all duration-300 ${
                question.isActive ? 'border-white/20 hover:border-white/40' : 'border-red-400/30 opacity-75'
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                      category ? `bg-gradient-to-r ${category.color} text-white` : 'bg-gray-500/20 text-gray-300'
                    }`}>
                      {category?.nameAr || 'غير محدد'}
                    </span>
                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${getDifficultyColor(question.difficulty)}`}>
                      {getDifficultyName(question.difficulty)} ({question.difficultyLevel}/5)
                    </span>
                    <span className="px-2 py-1 bg-yellow-500/20 text-yellow-300 rounded-full text-xs font-bold">
                      {question.points} نقطة
                    </span>
                    {!question.isActive && (
                      <span className="px-2 py-1 bg-red-500/20 text-red-300 rounded-full text-xs font-bold">
                        غير نشط
                      </span>
                    )}
                  </div>
                  <h4 className="text-lg font-bold text-white mb-2">{question.question}</h4>
                  {question.type === 'multiple_choice' && (
                    <div className="grid grid-cols-2 gap-2 mb-3">
                      {question.options.map((option, index) => (
                        <div
                          key={index}
                          className={`p-2 rounded-lg text-sm ${
                            question.correctAnswer === index
                              ? 'bg-green-500/20 text-green-300 border border-green-400/30'
                              : 'bg-white/5 text-white/70'
                          }`}
                        >
                          {String.fromCharCode(65 + index)}. {option}
                        </div>
                      ))}
                    </div>
                  )}
                  {question.type === 'text' && (
                    <div className="mb-3">
                      <span className="text-white/70 text-sm">الإجابة: </span>
                      <span className="text-green-300 font-semibold">{question.correctAnswer}</span>
                    </div>
                  )}
                  {question.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-2">
                      {question.tags.map(tag => (
                        <span key={tag} className="px-2 py-1 bg-purple-500/20 text-purple-300 rounded text-xs">
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="flex gap-2 ml-4">
                  <button
                    onClick={() => onUpdateQuestion(question.id, { isActive: !question.isActive })}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                      question.isActive
                        ? 'bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30'
                        : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                    }`}
                    title={question.isActive ? 'إخفاء السؤال' : 'إظهار السؤال'}
                  >
                    {question.isActive ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => startEdit(question)}
                    className="w-8 h-8 bg-blue-500/20 text-blue-400 rounded-full flex items-center justify-center hover:bg-blue-500/30 transition-all"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(question)}
                    className="w-8 h-8 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center hover:bg-red-500/30 transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              {(question.explanation || question.notes) && (
                <div className="border-t border-white/10 pt-3 mt-3">
                  {question.explanation && (
                    <div className="mb-2">
                      <span className="text-white/70 text-sm font-semibold">الشرح: </span>
                      <span className="text-white/80 text-sm">{question.explanation}</span>
                    </div>
                  )}
                  {question.notes && (
                    <div>
                      <span className="text-white/70 text-sm font-semibold">ملاحظات: </span>
                      <span className="text-white/80 text-sm">{question.notes}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {questions.length === 0 && (
        <div className="text-center py-12">
          <div className="text-white/50 text-xl mb-4">لا توجد أسئلة بعد</div>
          <button
            onClick={() => setShowCreateForm(true)}
            className="px-6 py-3 bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-bold rounded-xl hover:from-purple-600 hover:to-indigo-600 transition-all duration-300"
          >
            إضافة أول سؤال
          </button>
        </div>
      )}
    </div>
  );
};

export default QuestionsManager;