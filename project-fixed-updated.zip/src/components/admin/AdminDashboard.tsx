import React, { useState } from 'react';
import { Settings, BarChart3, Users, BookOpen, Plus, Search, Filter, Activity, Wifi, WifiOff, AlertTriangle, Sparkles, Crown, Zap } from 'lucide-react';
import { useAdminData } from '../../hooks/useAdminData';
import { useOnlineAdminData } from '../../hooks/useOnlineAdminData';
import { hasValidSupabaseConfig } from '../../lib/supabase';
import DatabaseSetupHelper from '../DatabaseSetupHelper';
import CategoriesManager from './CategoriesManager';
import QuestionsManager from './QuestionsManager';
import AdminStats from './AdminStats';
import { AdminFilters } from '../../types/admin';

interface AdminDashboardProps {
  onClose: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'categories' | 'questions' | 'stats'>('overview');
  const [useOnlineMode, setUseOnlineMode] = useState(hasValidSupabaseConfig);
  const [showDatabaseSetup, setShowDatabaseSetup] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<AdminFilters>({});
  
  // استخدام البيانات المناسبة حسب الوضع
  const localData = useAdminData();
  const onlineData = useOnlineAdminData();
  
  const currentData = useOnlineMode ? onlineData : localData;
  
  const {
    categories,
    questions,
    loading,
    createCategory,
    updateCategory,
    deleteCategory,
    createQuestion,
    updateQuestion,
    deleteQuestion,
    getFilteredQuestions,
    getStats
  } = currentData;

  const stats = getStats();
  const filteredQuestions = getFilteredQuestions({ ...filters, searchQuery });

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
        <div className="bg-gradient-to-br from-purple-900/90 to-indigo-900/90 backdrop-blur-md rounded-3xl p-12 border border-purple-400/30 shadow-2xl">
          <div className="text-center">
            <div className="relative mb-6">
              <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto animate-pulse">
                <Settings className="w-10 h-10 text-white animate-spin" />
              </div>
              <div className="absolute -top-2 -right-2">
                <Sparkles className="w-8 h-8 text-yellow-400 animate-bounce" />
              </div>
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">جاري تحميل لوحة التحكم</h2>
            <p className="text-purple-200 text-lg">يرجى الانتظار...</p>
            <div className="mt-6 flex justify-center">
              <div className="flex space-x-2">
                {[...Array(3)].map((_, i) => (
                  <div
                    key={i}
                    className="w-3 h-3 bg-purple-400 rounded-full animate-bounce"
                    style={{ animationDelay: `${i * 0.2}s` }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Show database setup helper if needed
  if (showDatabaseSetup) {
    return <DatabaseSetupHelper onClose={() => setShowDatabaseSetup(false)} />;
  }

  const tabs = [
    { 
      id: 'overview', 
      label: 'نظرة عامة', 
      icon: BarChart3, 
      color: 'from-blue-500 to-cyan-500',
      description: 'إحصائيات شاملة ونظرة عامة'
    },
    { 
      id: 'categories', 
      label: 'إدارة التخصصات', 
      icon: BookOpen, 
      color: 'from-green-500 to-emerald-500',
      description: 'إضافة وتعديل التخصصات'
    },
    { 
      id: 'questions', 
      label: 'إدارة الأسئلة', 
      icon: Users, 
      color: 'from-purple-500 to-indigo-500',
      description: 'إضافة وتعديل الأسئلة'
    },
    { 
      id: 'stats', 
      label: 'الإحصائيات المتقدمة', 
      icon: Activity, 
      color: 'from-orange-500 to-red-500',
      description: 'تحليلات مفصلة وإحصائيات'
    }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 overflow-hidden">
      <div className="h-full flex">
        {/* Enhanced Sidebar */}
        <div className="w-96 bg-gradient-to-b from-slate-900/95 via-purple-900/90 to-indigo-900/95 backdrop-blur-md border-r border-purple-400/30 shadow-2xl">
          {/* Elegant Header */}
          <div className="p-8 border-b border-purple-400/30 bg-gradient-to-r from-purple-600/20 to-pink-600/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
                    <Crown className="w-8 h-8 text-white" />
                  </div>
                  <div className="absolute -top-1 -right-1">
                    <Sparkles className="w-6 h-6 text-yellow-400 animate-pulse" />
                  </div>
                </div>
                <div>
                  <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
                    لوحة التحكم
                  </h1>
                  <div className="flex items-center gap-3 mt-2">
                    <p className="text-purple-200 text-lg">إدارة المحتوى</p>
                    {hasValidSupabaseConfig && (
                      <div className="flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full">
                        {useOnlineMode ? (
                          <>
                            <Wifi className="w-4 h-4 text-green-400 animate-pulse" />
                            <span className="text-xs text-green-300 font-semibold">أونلاين</span>
                          </>
                        ) : (
                          <>
                            <WifiOff className="w-4 h-4 text-gray-400" />
                            <span className="text-xs text-gray-300">محلي</span>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <button
                onClick={onClose}
                className="w-12 h-12 bg-gradient-to-r from-red-500/20 to-pink-500/20 text-red-400 rounded-2xl flex items-center justify-center hover:from-red-500/30 hover:to-pink-500/30 transition-all duration-300 transform hover:scale-110 border border-red-400/30"
              >
                <span className="text-xl">×</span>
              </button>
            </div>
          </div>

          {/* Enhanced Mode Toggle */}
          {hasValidSupabaseConfig && (
            <div className="p-6 border-b border-purple-400/20">
              <div className="bg-gradient-to-r from-indigo-500/10 to-purple-500/10 rounded-2xl p-6 border border-indigo-400/30">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-white font-bold text-lg mb-2 flex items-center gap-2">
                      <Zap className="w-5 h-5 text-yellow-400" />
                      وضع التشغيل
                    </h3>
                    <p className="text-white/70 text-sm leading-relaxed">
                      {useOnlineMode 
                        ? '🌐 التغييرات تتزامن مع جميع اللاعبين فوراً' 
                        : '💾 التغييرات محفوظة محلياً على جهازك فقط'
                      }
                    </p>
                  </div>
                </div>
                
                <button
                  onClick={() => setUseOnlineMode(!useOnlineMode)}
                  className={`w-full flex items-center justify-center gap-3 px-6 py-4 rounded-xl transition-all duration-300 transform hover:scale-105 ${
                    useOnlineMode 
                      ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-lg shadow-green-500/25' 
                      : 'bg-gradient-to-r from-gray-600 to-gray-700 text-gray-200 hover:from-gray-500 hover:to-gray-600'
                  }`}
                >
                  {useOnlineMode ? (
                    <>
                      <Wifi className="w-5 h-5" />
                      <span className="font-bold">الوضع الأونلاين نشط</span>
                      <div className="w-3 h-3 bg-green-300 rounded-full animate-pulse" />
                    </>
                  ) : (
                    <>
                      <WifiOff className="w-5 h-5" />
                      <span className="font-bold">تفعيل الوضع الأونلاين</span>
                    </>
                  )}
                </button>
                
                {/* Quick Local Mode Button */}
                {!useOnlineMode && (
                  <div className="mt-4">
                    <button
                      onClick={() => {
                        localStorage.setItem('prefer_local_mode', 'true');
                        alert('✅ تم تفعيل الوضع المحلي!\n\nيمكنك الآن استخدام جميع ميزات لوحة التحكم محلياً.');
                      }}
                      className="w-full px-4 py-3 bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-bold rounded-xl hover:from-purple-600 hover:to-indigo-600 transition-all"
                    >
                      🎮 استخدام الوضع المحلي الكامل
                    </button>
                  </div>
                )}
                
                {/* Status Messages */}
                {!useOnlineMode && (
                  <div className="mt-4 bg-yellow-500/10 border border-yellow-400/30 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="w-5 h-5 text-yellow-400" />
                      <span className="text-yellow-300 font-semibold">تنبيه - الوضع المحلي:</span>
                    </div>
                    <div className="text-yellow-200 text-sm space-y-1">
                      <p>• التغييرات ستظهر على جهازك فقط</p>
                      <p>• اللاعبون الآخرون لن يروا التحديثات</p>
                      <p>• استخدم الوضع الأونلاين للتزامن</p>
                      <p className="text-green-300 font-semibold mt-2">✅ يمكنك استخدام جميع الميزات محلياً!</p>
                    </div>
                  </div>
                )}
                
                {useOnlineMode && onlineData.isOnline && (
                  <div className="mt-4 bg-green-500/10 border border-green-400/30 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Wifi className="w-5 h-5 text-green-400 animate-pulse" />
                      <span className="text-green-300 font-semibold">متصل - الوضع الأونلاين:</span>
                    </div>
                    <div className="text-green-200 text-sm space-y-1">
                      <p>• التزامن المباشر مع جميع اللاعبين</p>
                      <p>• تحديثات فورية عبر قاعدة البيانات</p>
                      <p>• حفظ آمن ومتزامن للبيانات</p>
                      {questions.length === 0 && (
                        <div className="mt-3 pt-3 border-t border-green-400/20">
                          <p className="text-yellow-300 font-semibold mb-2">⚠️ قاعدة البيانات فارغة من الأسئلة</p>
                          <button
                            onClick={() => {
                              console.log('🔧 تم الضغط على زر الإدراج اليدوي - بدء العملية...');
                              onlineData.manualInsertData();
                            }}
                            className="w-full px-4 py-2 bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-bold rounded-lg hover:from-yellow-600 hover:to-orange-600 transition-all text-sm"
                          >
                            🔧 إدراج 48 سؤال افتراضي الآن
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {/* Database Setup Warning */}
          {useOnlineMode && !onlineData.tablesCreated && (
            <div className="p-6 border-b border-red-400/20">
              <div className="bg-gradient-to-r from-red-500/10 to-pink-500/10 border border-red-400/30 rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-red-500/20 rounded-xl flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-red-400 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-red-300 font-bold text-lg">هيكل قاعدة البيانات غير مكتمل</h3>
                    <p className="text-red-200 text-sm">يتطلب تشغيل ملفات الإعداد</p>
                  </div>
                </div>
                
                <div className="space-y-3 text-red-200 text-sm mb-4">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-red-400 rounded-full"></span>
                    <span>جداول لوحة التحكم مفقودة</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-red-400 rounded-full"></span>
                    <span>أعمدة مطلوبة غير موجودة</span>
                  </div>
                </div>
                
                <button
                  onClick={() => setShowDatabaseSetup(true)}
                  className="w-full px-6 py-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white font-bold rounded-xl hover:from-blue-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2 shadow-lg"
                >
                  <Settings className="w-5 h-5" />
                  🛠️ فتح مساعد الإعداد التفاعلي
                </button>
              </div>
            </div>
          )}

          {/* Enhanced Quick Stats */}
          <div className="p-6 border-b border-purple-400/20">
            <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-purple-400" />
              إحصائيات سريعة
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-2xl p-4 border border-blue-400/30 text-center transform hover:scale-105 transition-all duration-300">
                <div className="text-3xl font-bold text-white mb-1">{stats.totalCategories}</div>
                <div className="text-blue-200 text-sm font-semibold">تخصصات</div>
                <div className="w-full bg-blue-400/20 rounded-full h-1 mt-2">
                  <div className="bg-blue-400 h-1 rounded-full" style={{ width: `${Math.min(100, (stats.totalCategories / 10) * 100)}%` }} />
                </div>
              </div>
              <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-2xl p-4 border border-green-400/30 text-center transform hover:scale-105 transition-all duration-300">
                <div className="text-3xl font-bold text-white mb-1">{stats.totalQuestions}</div>
                <div className="text-green-200 text-sm font-semibold">أسئلة</div>
                <div className="w-full bg-green-400/20 rounded-full h-1 mt-2">
                  <div className="bg-green-400 h-1 rounded-full" style={{ width: `${Math.min(100, (stats.totalQuestions / 100) * 100)}%` }} />
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced Navigation */}
          <div className="p-6 flex-1 overflow-y-auto">
            <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
              <Settings className="w-5 h-5 text-purple-400" />
              أقسام الإدارة
            </h3>
            <nav className="space-y-3">
              {tabs.map(tab => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`w-full group relative overflow-hidden rounded-2xl transition-all duration-300 transform hover:scale-105 ${
                      isActive
                        ? `bg-gradient-to-r ${tab.color} shadow-lg shadow-purple-500/25 border border-white/20`
                        : 'bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center gap-4 p-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${
                        isActive 
                          ? 'bg-white/20 shadow-lg' 
                          : 'bg-white/10 group-hover:bg-white/20'
                      }`}>
                        <Icon className={`w-6 h-6 ${isActive ? 'text-white' : 'text-white/70 group-hover:text-white'}`} />
                      </div>
                      <div className="flex-1 text-left">
                        <div className={`font-bold text-lg ${isActive ? 'text-white' : 'text-white/80 group-hover:text-white'}`}>
                          {tab.label}
                        </div>
                        <div className={`text-sm ${isActive ? 'text-white/80' : 'text-white/60 group-hover:text-white/70'}`}>
                          {tab.description}
                        </div>
                      </div>
                      {isActive && (
                        <div className="w-3 h-3 bg-white rounded-full animate-pulse" />
                      )}
                    </div>
                    
                    {/* Active indicator */}
                    {isActive && (
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent animate-pulse" />
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Enhanced Main Content */}
        <div className="flex-1 bg-gradient-to-br from-slate-900/95 via-gray-900/90 to-slate-800/95 backdrop-blur-md overflow-hidden">
          {/* Enhanced Top Bar */}
          <div className="p-8 border-b border-white/20 bg-gradient-to-r from-purple-600/10 to-pink-600/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${tabs.find(t => t.id === activeTab)?.color} flex items-center justify-center shadow-lg`}>
                  {(() => {
                    const Icon = tabs.find(t => t.id === activeTab)?.icon || Settings;
                    return <Icon className="w-8 h-8 text-white" />;
                  })()}
                </div>
                <div>
                  <h2 className="text-4xl font-bold bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
                    {tabs.find(t => t.id === activeTab)?.label}
                  </h2>
                  <p className="text-white/70 text-lg mt-1">
                    {tabs.find(t => t.id === activeTab)?.description}
                  </p>
                </div>
              </div>
              
              {(activeTab === 'questions' || activeTab === 'overview') && (
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <Search className="w-5 h-5 text-white/50 absolute left-4 top-1/2 transform -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="البحث في الأسئلة..."
                      className="pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-2xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:bg-white/20 transition-all w-64"
                    />
                  </div>
                  
                  <select
                    value={filters.categoryId || ''}
                    onChange={(e) => setFilters(prev => ({ ...prev, categoryId: e.target.value || undefined }))}
                    className="px-4 py-3 bg-white/10 border border-white/20 rounded-2xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400 focus:bg-white/20 transition-all"
                  >
                    <option value="" className="bg-gray-800 text-white">جميع التخصصات</option>
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.id} className="bg-gray-800 text-white">{cat.nameAr}</option>
                    ))}
                  </select>
                  
                  <select
                    value={filters.difficulty || ''}
                    onChange={(e) => setFilters(prev => ({ ...prev, difficulty: e.target.value as any || undefined }))}
                    className="px-4 py-3 bg-white/10 border border-white/20 rounded-2xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400 focus:bg-white/20 transition-all"
                  >
                    <option value="" className="bg-gray-800 text-white">جميع المستويات</option>
                    <option value="easy" className="bg-gray-800 text-white">سهل</option>
                    <option value="medium" className="bg-gray-800 text-white">متوسط</option>
                    <option value="hard" className="bg-gray-800 text-white">صعب</option>
                  </select>
                </div>
              )}
            </div>
          </div>

          {/* Enhanced Content Area */}
          <div className="p-8 h-[calc(100vh-180px)] overflow-y-auto">
            <div className="max-w-7xl mx-auto">
              {activeTab === 'overview' && (
                <div className="space-y-8">
                  {/* Welcome Section */}
                  <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-3xl p-8 border border-purple-400/30">
                    <div className="flex items-center gap-4 mb-6">
                      <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center">
                        <Crown className="w-10 h-10 text-white" />
                      </div>
                      <div>
                        <h3 className="text-3xl font-bold text-white mb-2">مرحباً بك في لوحة التحكم</h3>
                        <p className="text-purple-200 text-lg">إدارة شاملة للتخصصات والأسئلة مع إحصائيات متقدمة</p>
                      </div>
                    </div>
                    
                    <div className="grid md:grid-cols-3 gap-6">
                      <div className="bg-white/10 rounded-2xl p-6 text-center">
                        <BookOpen className="w-12 h-12 text-blue-400 mx-auto mb-3" />
                        <h4 className="text-white font-bold text-lg mb-2">إدارة التخصصات</h4>
                        <p className="text-white/70 text-sm">إضافة وتعديل التخصصات المختلفة</p>
                      </div>
                      <div className="bg-white/10 rounded-2xl p-6 text-center">
                        <Users className="w-12 h-12 text-green-400 mx-auto mb-3" />
                        <h4 className="text-white font-bold text-lg mb-2">إدارة الأسئلة</h4>
                        <p className="text-white/70 text-sm">إنشاء وتحرير الأسئلة والإجابات</p>
                      </div>
                      <div className="bg-white/10 rounded-2xl p-6 text-center">
                        <Activity className="w-12 h-12 text-purple-400 mx-auto mb-3" />
                        <h4 className="text-white font-bold text-lg mb-2">الإحصائيات</h4>
                        <p className="text-white/70 text-sm">تحليلات مفصلة وتقارير شاملة</p>
                      </div>
                    </div>
                  </div>

                  <AdminStats stats={stats} />
                  
                  <div className="grid md:grid-cols-2 gap-8">
                    <div className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20">
                      <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
                          <Plus className="w-5 h-5 text-white" />
                        </div>
                        الأسئلة الحديثة
                      </h3>
                      <div className="space-y-4">
                        {questions.slice(0, 5).map(question => (
                          <div key={question.id} className="bg-white/5 rounded-2xl p-4 hover:bg-white/10 transition-all duration-300">
                            <div className="text-white font-medium truncate mb-2">
                              {question.question}
                            </div>
                            <div className="flex items-center gap-3">
                              <span className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-xs font-bold">
                                {categories.find(c => c.id === question.categoryId)?.nameAr}
                              </span>
                              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                                question.difficulty === 'easy' ? 'bg-green-500/20 text-green-300' :
                                question.difficulty === 'medium' ? 'bg-yellow-500/20 text-yellow-300' :
                                'bg-red-500/20 text-red-300'
                              }`}>
                                {question.difficulty === 'easy' ? 'سهل' :
                                 question.difficulty === 'medium' ? 'متوسط' : 'صعب'}
                              </span>
                            </div>
                          </div>
                        ))}
                        {questions.length === 0 && (
                          <div className="text-center py-8">
                            <div className="text-white/50 text-lg mb-2">لا توجد أسئلة بعد</div>
                            <p className="text-white/30 text-sm">ابدأ بإضافة أول سؤال</p>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20">
                      <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl flex items-center justify-center">
                          <Activity className="w-5 h-5 text-white" />
                        </div>
                        النشاط الأخير
                      </h3>
                      <div className="space-y-4">
                        {stats.recentActivity.map(activity => (
                          <div key={activity.id} className="bg-white/5 rounded-2xl p-4 hover:bg-white/10 transition-all duration-300">
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                                activity.type === 'create' ? 'bg-green-500/20 text-green-400' :
                                activity.type === 'update' ? 'bg-blue-500/20 text-blue-400' :
                                'bg-red-500/20 text-red-400'
                              }`}>
                                {activity.type === 'create' ? '+' : activity.type === 'update' ? '✎' : '×'}
                              </div>
                              <div className="flex-1">
                                <div className="text-white font-semibold">
                                  {activity.type === 'create' ? 'إنشاء' :
                                   activity.type === 'update' ? 'تحديث' : 'حذف'} {
                                   activity.entity === 'category' ? 'تخصص' : 'سؤال'
                                  }
                                </div>
                                <div className="text-white/70 text-sm truncate">
                                  {activity.entityName}
                                </div>
                              </div>
                              <div className="text-white/50 text-xs">
                                {new Date(activity.timestamp).toLocaleDateString('ar-SA', {
                                  month: 'short',
                                  day: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit'
                                })}
                              </div>
                            </div>
                          </div>
                        ))}
                        {stats.recentActivity.length === 0 && (
                          <div className="text-center py-8">
                            <div className="text-white/50 text-lg mb-2">لا يوجد نشاط حديث</div>
                            <p className="text-white/30 text-sm">ابدأ بإضافة محتوى جديد</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'categories' && (
                <CategoriesManager
                  categories={categories}
                  onCreateCategory={createCategory}
                  onUpdateCategory={updateCategory}
                  onDeleteCategory={deleteCategory}
                />
              )}

              {activeTab === 'questions' && (
                <QuestionsManager
                  questions={filteredQuestions}
                  categories={categories}
                  onCreateQuestion={createQuestion}
                  onUpdateQuestion={updateQuestion}
                  onDeleteQuestion={deleteQuestion}
                />
              )}

              {activeTab === 'stats' && (
                <AdminStats stats={stats} detailed />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;