import React, { useState } from 'react';
import { Database, Copy, CheckCircle, AlertTriangle, ExternalLink, FileText, Play } from 'lucide-react';
import SupabaseSQLGuide from './SupabaseSQLGuide';

interface DatabaseSetupHelperProps {
  onClose: () => void;
}

const DatabaseSetupHelper: React.FC<DatabaseSetupHelperProps> = ({ onClose }) => {
  const [copiedFile, setCopiedFile] = useState<string | null>(null);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [showDetailedGuide, setShowDetailedGuide] = useState(false);

  const migrationFiles = [
    {
      id: 1,
      name: '20250726100321_gentle_glade.sql',
      title: 'إنشاء الجداول الأساسية',
      description: 'جداول الغرف واللاعبين وحالة اللعبة',
      path: 'supabase/migrations/20250726100321_gentle_glade.sql',
      required: true
    },
    {
      id: 2,
      name: '20250726212911_lively_rain.sql',
      title: 'جداول لوحة التحكم',
      description: 'التخصصات والأسئلة المدارة + التحديثات المطلوبة',
      path: 'supabase/migrations/20250726212911_lively_rain.sql',
      required: true
    }
  ];

  const copyToClipboard = async (text: string, fileId: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedFile(fileId);
      setTimeout(() => setCopiedFile(null), 2000);
    } catch (error) {
      console.error('فشل في النسخ:', error);
    }
  };

  const markStepCompleted = (stepId: number) => {
    if (!completedSteps.includes(stepId)) {
      setCompletedSteps([...completedSteps, stepId]);
    }
  };

  const allStepsCompleted = completedSteps.length === migrationFiles.length;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 overflow-y-auto">
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="bg-gradient-to-br from-slate-900/95 to-gray-900/95 backdrop-blur-md rounded-3xl border border-white/20 w-full max-w-4xl max-h-[90vh] overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-white/20">
            <div className="flex items-center gap-3">
              <Database className="w-8 h-8 text-blue-400" />
              <div>
                <h1 className="text-2xl font-bold text-white">مساعد إعداد قاعدة البيانات</h1>
                <p className="text-blue-200">إعداد الجداول المطلوبة للعب الأونلاين</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center hover:bg-red-500/30 transition-all"
            >
              ×
            </button>
          </div>

          {/* Problem Description */}
          <div className="p-6 border-b border-white/20">
            <div className="bg-red-500/10 border border-red-400/30 rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <AlertTriangle className="w-6 h-6 text-red-400" />
                <h2 className="text-xl font-bold text-red-400">المشكلة المكتشفة</h2>
              </div>
              <div className="space-y-3 text-red-200">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-red-400 rounded-full"></span>
                  <span>جداول لوحة التحكم (admin_categories, admin_questions) غير موجودة</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-red-400 rounded-full"></span>
                  <span>عمود التخصصات المختارة (selected_categories) مفقود من جدول حالة اللعبة</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-red-400 rounded-full"></span>
                  <span>مراحل اللعبة الجديدة (categoryPreSelection) غير مدعومة</span>
                </div>
              </div>
            </div>
          </div>

          {/* Solution Steps */}
          <div className="p-6 overflow-y-auto max-h-[60vh]">
            <div className="mb-6">
              <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <Play className="w-6 h-6 text-green-400" />
                خطوات الحل
              </h2>
              <div className="bg-blue-500/10 border border-blue-400/30 rounded-xl p-4">
                <p className="text-blue-200 text-sm">
                  🎯 <strong>الهدف:</strong> تشغيل ملفات SQL في محرر Supabase لإنشاء الجداول والأعمدة المطلوبة
                </p>
              </div>
            </div>

            {/* Step 1: Access Supabase */}
            <div className="mb-8">
              <div className="bg-white/5 rounded-2xl p-6 border border-white/10">
                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    completedSteps.includes(0) ? 'bg-green-500' : 'bg-blue-500'
                  }`}>
                    {completedSteps.includes(0) ? <CheckCircle className="w-5 h-5 text-white" /> : '1'}
                  </div>
                  <h3 className="text-lg font-bold text-white">الوصول إلى Supabase Dashboard</h3>
                </div>
                <div className="ml-11 space-y-3">
                  <p className="text-white/80">اذهب إلى لوحة تحكم مشروعك في Supabase:</p>
                  <a
                    href="https://supabase.com/dashboard"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-green-500/20 text-green-300 rounded-lg hover:bg-green-500/30 transition-all"
                  >
                    <ExternalLink className="w-4 h-4" />
                    فتح Supabase Dashboard
                  </a>
                  <button
                    onClick={() => markStepCompleted(0)}
                    className="block px-4 py-2 bg-blue-500/20 text-blue-300 rounded-lg hover:bg-blue-500/30 transition-all"
                  >
                    ✅ تم - وصلت للوحة التحكم
                  </button>
                </div>
              </div>
            </div>

            {/* Step 2: SQL Editor */}
            <div className="mb-8">
              <div className="bg-white/5 rounded-2xl p-6 border border-white/10">
                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    completedSteps.includes(-1) ? 'bg-green-500' : 'bg-blue-500'
                  }`}>
                    {completedSteps.includes(-1) ? <CheckCircle className="w-5 h-5 text-white" /> : '2'}
                  </div>
                  <h3 className="text-lg font-bold text-white">فتح محرر SQL</h3>
                </div>
                <div className="ml-11 space-y-3">
                  <p className="text-white/80">في لوحة التحكم، اذهب إلى:</p>
                  <div className="bg-gray-800 rounded-lg p-3 font-mono text-sm text-green-300">
                    SQL Editor → New Query
                  </div>
                  <button
                    onClick={() => markStepCompleted(-1)}
                    className="px-4 py-2 bg-blue-500/20 text-blue-300 rounded-lg hover:bg-blue-500/30 transition-all"
                  >
                    ✅ تم - فتحت محرر SQL
                  </button>
                </div>
              </div>
            </div>

            {/* Migration Files */}
            <div className="space-y-6">
              {migrationFiles.map((file, index) => (
                <div key={file.id} className="bg-white/5 rounded-2xl p-6 border border-white/10">
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      completedSteps.includes(file.id) ? 'bg-green-500' : 'bg-orange-500'
                    }`}>
                      {completedSteps.includes(file.id) ? <CheckCircle className="w-5 h-5 text-white" /> : (index + 3)}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-white">{file.title}</h3>
                      <p className="text-white/60 text-sm">{file.description}</p>
                    </div>
                  </div>
                  
                  <div className="ml-11 space-y-4">
                    <div className="bg-gray-800 rounded-lg p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white/80 text-sm font-mono">{file.path}</span>
                        <button
                          onClick={() => copyToClipboard(file.path, file.name)}
                          className="flex items-center gap-1 px-2 py-1 bg-blue-500/20 text-blue-300 rounded text-xs hover:bg-blue-500/30 transition-all"
                        >
                          <Copy className="w-3 h-3" />
                          {copiedFile === file.name ? 'تم النسخ!' : 'نسخ المسار'}
                        </button>
                      </div>
                    </div>

                    <div className="bg-yellow-500/10 border border-yellow-400/30 rounded-lg p-4">
                      <h4 className="text-yellow-300 font-bold mb-2">📋 التعليمات:</h4>
                      <ol className="text-yellow-200 text-sm space-y-1 list-decimal list-inside">
                        <li>انسخ محتوى الملف <code className="bg-black/20 px-1 rounded">{file.name}</code> من مجلد المشروع</li>
                        <li>الصق المحتوى في محرر SQL في Supabase</li>
                        <li>اضغط زر "Run" أو Ctrl+Enter لتشغيل الكود</li>
                        <li>تأكد من ظهور رسالة "Success" أو عدم وجود أخطاء</li>
                      </ol>
                    </div>

                    <div className="flex gap-3">
                      <button
                        onClick={() => markStepCompleted(file.id)}
                        disabled={completedSteps.includes(file.id)}
                        className={`px-4 py-2 rounded-lg transition-all ${
                          completedSteps.includes(file.id)
                            ? 'bg-green-500/20 text-green-300 cursor-not-allowed'
                            : 'bg-green-500/20 text-green-300 hover:bg-green-500/30'
                        }`}
                      >
                        {completedSteps.includes(file.id) ? '✅ مكتمل' : '✅ تم تشغيل هذا الملف'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Completion Status */}
            {allStepsCompleted && (
              <div className="mt-8 bg-green-500/10 border border-green-400/30 rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <CheckCircle className="w-8 h-8 text-green-400" />
                  <h3 className="text-xl font-bold text-green-400">🎉 تم الإعداد بنجاح!</h3>
                </div>
                <div className="space-y-3 text-green-200">
                  <p>✅ تم تشغيل جميع ملفات الإعداد المطلوبة</p>
                  <p>✅ قاعدة البيانات جاهزة للعب الأونلاين</p>
                  <p>✅ يمكنك الآن إغلاق هذه النافذة والعودة للعبة</p>
                </div>
                <div className="space-y-4">
                  <button
                    onClick={() => setShowDetailedGuide(true)}
                    className="w-full px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white font-bold rounded-xl hover:from-blue-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2"
                  >
                    📚 دليل مفصل: كيفية إنشاء New Query في Supabase
                  </button>
                  
                <button
                  onClick={onClose}
                  className="mt-4 px-6 py-3 bg-green-500 text-white font-bold rounded-xl hover:bg-green-600 transition-all"
                >
                  🎮 العودة للعبة
                </button>
                </div>
              </div>
            )}

            {/* Help Section */}
            <div className="mt-8 bg-blue-500/10 border border-blue-400/30 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-blue-300 mb-4">💡 نصائح مهمة:</h3>
              <div className="space-y-2 text-blue-200 text-sm">
                <p>• تأكد من تشغيل الملفات بالترتيب المحدد</p>
                <p>• إذا ظهرت أخطاء، تحقق من صحة نسخ المحتوى</p>
                <p>• بعض الأوامر قد تظهر تحذيرات - هذا طبيعي</p>
                <p>• إذا فشل ملف، جرب تشغيله مرة أخرى</p>
                <p>• بعد الانتهاء، أعد تحميل الصفحة لتطبيق التغييرات</p>
              </div>
            </div>

            {/* Quick Solutions */}
            <div className="mt-6 bg-green-500/10 border border-green-400/30 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-green-300 mb-4">🚀 حلول سريعة:</h3>
              <div className="space-y-4">
                <div className="bg-white/5 rounded-xl p-4">
                  <h4 className="text-white font-bold mb-2">الحل الأول: استخدام الوضع المحلي</h4>
                  <p className="text-green-200 text-sm mb-3">
                    إذا كنت تريد تجربة اللعبة فوراً بدون إعداد قاعدة البيانات:
                  </p>
                  <button
                    onClick={() => {
                      localStorage.setItem('force_local_mode', 'true');
                      window.location.reload();
                    }}
                    className="w-full px-4 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-emerald-600 transition-all"
                  >
                    🎮 تفعيل الوضع المحلي فقط
                  </button>
                </div>
                
                <div className="bg-white/5 rounded-xl p-4">
                  <h4 className="text-white font-bold mb-2">الحل الثاني: إعداد قاعدة البيانات</h4>
                  <p className="text-blue-200 text-sm mb-3">
                    للحصول على جميع الميزات والعب الأونلاين:
                  </p>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs font-bold">1</span>
                      <span className="text-blue-200">اذهب إلى Supabase Dashboard</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs font-bold">2</span>
                      <span className="text-blue-200">افتح SQL Editor → New Query</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs font-bold">3</span>
                      <span className="text-blue-200">انسخ والصق محتوى الملفين بالترتيب</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white/5 rounded-xl p-4">
                  <h4 className="text-white font-bold mb-2">الحل الثالث: تخطي الإعداد مؤقتاً</h4>
                  <p className="text-yellow-200 text-sm mb-3">
                    استخدم اللعبة المحلية مع جميع الميزات:
                  </p>
                  <button
                    onClick={() => {
                      // إغلاق النافذة والعودة للوضع المحلي
                      onClose();
                      // تعطيل الوضع الأونلاين مؤقتاً
                      localStorage.setItem('skip_online_setup', 'true');
                    }}
                    className="w-full px-4 py-3 bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-bold rounded-xl hover:from-yellow-600 hover:to-orange-600 transition-all"
                  >
                    ⏭️ تخطي الإعداد والعب محلياً
                  </button>
                </div>
              </div>
            </div>

            {/* Troubleshooting */}
            <div className="mt-6 bg-red-500/10 border border-red-400/30 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-red-300 mb-4">🔧 حل المشاكل الشائعة:</h3>
              <div className="space-y-3 text-red-200 text-sm">
                <div>
                  <strong>خطأ "relation does not exist":</strong>
                  <p className="ml-4">• تأكد من تشغيل الملف الأول أولاً</p>
                </div>
                <div>
                  <strong>خطأ "column does not exist":</strong>
                  <p className="ml-4">• تأكد من تشغيل الملف الثاني بعد الأول</p>
                </div>
                <div>
                  <strong>خطأ "permission denied":</strong>
                  <p className="ml-4">• تأكد من أنك مالك المشروع في Supabase</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Detailed SQL Guide */}
      {showDetailedGuide && (
        <SupabaseSQLGuide onClose={() => setShowDetailedGuide(false)} />
      )}
    </div>
  );
};

export default DatabaseSetupHelper;