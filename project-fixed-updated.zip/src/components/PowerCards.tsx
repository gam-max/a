import React from 'react';
import { Zap, RefreshCw, ArrowRightLeft, Plus } from 'lucide-react';
import { GameState, PowerCard } from '../types/game';

interface PowerCardsProps {
  gameState: GameState;
  onUsePowerCard: (cardType: PowerCard) => void;
  disabled: boolean;
}

const PowerCards: React.FC<PowerCardsProps> = ({ gameState, onUsePowerCard, disabled }) => {
  const currentTeam = gameState.currentTurn;
  const currentTeamData = gameState[currentTeam + 'Team'];

  const powerCards = [
    {
      type: 'fiftyFifty' as PowerCard,
      name: '50/50',
      description: 'حذف إجابتين خاطئتين',
      icon: Zap,
      color: 'from-yellow-500 to-orange-500',
      disabled: gameState.usedPowerCard === 'fiftyFifty'
    },
    {
      type: 'skipQuestion' as PowerCard,
      name: 'تبديل السؤال',
      description: 'الحصول على سؤال جديد',
      icon: RefreshCw,
      color: 'from-blue-500 to-purple-500',
      disabled: false
    },
    {
      type: 'stealTurn' as PowerCard,
      name: 'سرقة الدور',
      description: 'أخذ دور الفريق الآخر',
      icon: ArrowRightLeft,
      color: 'from-red-500 to-pink-500',
      disabled: false
    },
    {
      type: 'extraTime' as PowerCard,
      name: 'وقت إضافي',
      description: '+10 ثوانِ إضافية',
      icon: Plus,
      color: 'from-green-500 to-teal-500',
      disabled: gameState.usedPowerCard === 'extraTime'
    }
  ];

  return (
    <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
      <div className="text-center mb-4">
        <h3 className="text-xl font-bold text-white flex items-center justify-center gap-2">
          <Zap className="w-6 h-6 text-yellow-400" />
          كروت المساعدة
        </h3>
        <p className="text-white/70">
          المتبقي: {currentTeamData.powerCards} كرت
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {powerCards.map((card) => {
          const Icon = card.icon;
          const isDisabled = disabled || currentTeamData.powerCards <= 0 || card.disabled;
          
          return (
            <button
              key={card.type}
              onClick={() => !isDisabled && onUsePowerCard(card.type)}
              disabled={isDisabled}
              className={`
                relative p-4 rounded-xl text-white font-semibold transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                bg-gradient-to-br ${card.color}
                ${!isDisabled ? 'hover:shadow-lg hover:shadow-white/20' : ''}
              `}
            >
              <div className="text-center">
                <Icon className="w-8 h-8 mx-auto mb-2" />
                <div className="text-sm font-bold mb-1">{card.name}</div>
                <div className="text-xs opacity-90">{card.description}</div>
              </div>
              
              {card.disabled && (
                <div className="absolute inset-0 bg-black/50 rounded-xl flex items-center justify-center">
                  <span className="text-white text-xs font-bold">مُستخدم</span>
                </div>
              )}
            </button>
          );
        })}
      </div>

      {gameState.usedPowerCard && (
        <div className="mt-4 text-center">
          <div className="inline-flex items-center px-4 py-2 bg-white/10 rounded-full text-white text-sm">
            <Zap className="w-4 h-4 mr-2 text-yellow-400" />
            تم استخدام: {powerCards.find(c => c.type === gameState.usedPowerCard)?.name}
          </div>
        </div>
      )}
    </div>
  );
};

export default PowerCards;