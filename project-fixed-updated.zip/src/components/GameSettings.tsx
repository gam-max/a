import React, { useState } from 'react';
import { Settings, Volume2, VolumeX, Palette, Clock, Users, Trophy, RotateCcw, Trash2 } from 'lucide-react';

interface GameSettingsProps {
  isVisible: boolean;
  onClose: () => void;
  onResetQuestions?: () => void;
  onClearQuestionHistory?: () => void;
  settings: {
    soundEnabled: boolean;
    timePerQuestion: number;
    maxQuestionsPerTeam: number;
    theme: 'default' | 'dark' | 'colorful';
    showHints: boolean;
    autoNextQuestion: boolean;
  };
  onUpdateSettings: (settings: any) => void;
}

const GameSettings: React.FC<GameSettingsProps> = ({
  isVisible,
  onClose,
  onResetQuestions,
  onClearQuestionHistory,
  settings,
  onUpdateSettings
}) => {
  const [localSettings, setLocalSettings] = useState(settings);

  if (!isVisible) return null;

  const handleSave = () => {
    onUpdateSettings(localSettings);
    onClose();
  };

  const updateSetting = (key: string, value: any) => {
    setLocalSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/20">
          <div className="flex items-center gap-3">
            <Settings className="w-6 h-6 text-purple-400" />
            <h2 className="text-xl font-bold text-white">إعدادات اللعبة</h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center hover:bg-red-500/30 transition-all"
          >
            ×
          </button>
        </div>

        {/* Settings */}
        <div className="p-6 space-y-6">
          {/* Sound Settings */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                {localSettings.soundEnabled ? (
                  <Volume2 className="w-5 h-5 text-green-400" />
                ) : (
                  <VolumeX className="w-5 h-5 text-red-400" />
                )}
                <span className="text-white font-semibold">الأصوات</span>
              </div>
              <button
                onClick={() => updateSetting('soundEnabled', !localSettings.soundEnabled)}
                className={`w-12 h-6 rounded-full transition-all ${
                  localSettings.soundEnabled ? 'bg-green-500' : 'bg-gray-500'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full transition-all ${
                  localSettings.soundEnabled ? 'translate-x-6' : 'translate-x-0.5'
                }`} />
              </button>
            </div>
          </div>

          {/* Time Settings */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Clock className="w-5 h-5 text-blue-400" />
              <span className="text-white font-semibold">وقت السؤال</span>
            </div>
            <div className="flex gap-2">
              {[10, 15, 20, 30].map(time => (
                <button
                  key={time}
                  onClick={() => updateSetting('timePerQuestion', time)}
                  className={`px-3 py-2 rounded-lg text-sm font-bold transition-all ${
                    localSettings.timePerQuestion === time
                      ? 'bg-blue-500 text-white'
                      : 'bg-white/10 text-white/70 hover:bg-white/20'
                  }`}
                >
                  {time}ث
                </button>
              ))}
            </div>
          </div>

          {/* Questions Count */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Trophy className="w-5 h-5 text-yellow-400" />
              <span className="text-white font-semibold">عدد الأسئلة لكل فريق</span>
            </div>
            <div className="flex gap-2">
              {[5, 10, 15, 20].map(count => (
                <button
                  key={count}
                  onClick={() => updateSetting('maxQuestionsPerTeam', count)}
                  className={`px-3 py-2 rounded-lg text-sm font-bold transition-all ${
                    localSettings.maxQuestionsPerTeam === count
                      ? 'bg-yellow-500 text-white'
                      : 'bg-white/10 text-white/70 hover:bg-white/20'
                  }`}
                >
                  {count}
                </button>
              ))}
            </div>
          </div>

          {/* Theme Settings */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Palette className="w-5 h-5 text-purple-400" />
              <span className="text-white font-semibold">المظهر</span>
            </div>
            <div className="space-y-2">
              {[
                { key: 'default', label: 'افتراضي', color: 'from-purple-500 to-blue-500' },
                { key: 'dark', label: 'داكن', color: 'from-gray-700 to-gray-900' },
                { key: 'colorful', label: 'ملون', color: 'from-pink-500 to-yellow-500' }
              ].map(theme => (
                <button
                  key={theme.key}
                  onClick={() => updateSetting('theme', theme.key)}
                  className={`w-full p-3 rounded-lg text-left transition-all ${
                    localSettings.theme === theme.key
                      ? 'bg-white/20 ring-2 ring-white/30'
                      : 'bg-white/10 hover:bg-white/15'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-6 h-6 rounded-full bg-gradient-to-r ${theme.color}`} />
                    <span className="text-white">{theme.label}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Additional Options */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-white">إظهار التلميحات</span>
              <button
                onClick={() => updateSetting('showHints', !localSettings.showHints)}
                className={`w-12 h-6 rounded-full transition-all ${
                  localSettings.showHints ? 'bg-green-500' : 'bg-gray-500'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full transition-all ${
                  localSettings.showHints ? 'translate-x-6' : 'translate-x-0.5'
                }`} />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-white">الانتقال التلقائي للسؤال التالي</span>
              <button
                onClick={() => updateSetting('autoNextQuestion', !localSettings.autoNextQuestion)}
                className={`w-12 h-6 rounded-full transition-all ${
                  localSettings.autoNextQuestion ? 'bg-green-500' : 'bg-gray-500'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full transition-all ${
                  localSettings.autoNextQuestion ? 'translate-x-6' : 'translate-x-0.5'
                }`} />
              </button>
            </div>
          </div>

          {/* إدارة الأسئلة */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <RotateCcw className="w-5 h-5 text-orange-400" />
              <span className="text-white font-semibold">إدارة الأسئلة</span>
            </div>
            <div className="space-y-3">
              {onResetQuestions && (
                <button
                  onClick={() => {
                    if (window.confirm('هل تريد إعادة تعيين أسئلة الجلسة الحالية؟\n\nسيتم عرض أسئلة جديدة في الجولات القادمة.')) {
                      onResetQuestions();
                      alert('تم إعادة تعيين أسئلة الجلسة!');
                    }
                  }}
                  className="w-full p-3 bg-orange-500/20 text-orange-300 rounded-lg hover:bg-orange-500/30 transition-all flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  إعادة تعيين أسئلة الجلسة
                </button>
              )}
              
              {onClearQuestionHistory && (
                <button
                  onClick={() => {
                    if (window.confirm('هل تريد حذف جميع تاريخ الأسئلة؟\n\nسيتم عرض جميع الأسئلة كأنها جديدة.\n\nهذا الإجراء لا يمكن التراجع عنه.')) {
                      onClearQuestionHistory();
                      alert('تم حذف جميع تاريخ الأسئلة!');
                    }
                  }}
                  className="w-full p-3 bg-red-500/20 text-red-300 rounded-lg hover:bg-red-500/30 transition-all flex items-center justify-center gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  حذف جميع تاريخ الأسئلة
                </button>
              )}
            </div>
            
            <div className="mt-3 bg-blue-500/10 border border-blue-400/30 rounded-lg p-3">
              <div className="text-blue-300 text-sm space-y-1">
                <p><strong>💡 نصائح:</strong></p>
                <p>• إعادة تعيين الجلسة: لأسئلة جديدة في اللعبة الحالية</p>
                <p>• حذف التاريخ: لبدء تجربة جديدة تماماً</p>
                <p>• النظام يتذكر الأسئلة التي رأيتها لتجنب التكرار</p>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 p-6 border-t border-white/20">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 bg-gray-500/20 text-gray-300 rounded-lg hover:bg-gray-500/30 transition-all"
          >
            إلغاء
          </button>
          <button
            onClick={handleSave}
            className="flex-1 px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg hover:from-green-600 hover:to-emerald-600 transition-all"
          >
            حفظ
          </button>
        </div>
      </div>
    </div>
  );
};

export default GameSettings;