import React, { useEffect, useState } from 'react';
import { Clock, Zap, RefreshCw, ArrowRightLeft, Plus, Users, AlertCircle, Settings } from 'lucide-react';
import { GameState, PowerCard } from '../types/game';
import { useGameCategories } from '../hooks/useGameCategories';
import { useQuestionManager } from '../hooks/useQuestionManager';
import Timer from './Timer';
import PowerCards from './PowerCards';
import GameHistory from './GameHistory';
import GameSettings from './GameSettings';

interface GameScreenProps {
  gameState: GameState;
  onAnswer: (answer: string, isCorrect: boolean) => void;
  onUsePowerCard: (cardType: PowerCard) => void;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

const GameScreen: React.FC<GameScreenProps> = ({ 
  gameState, 
  onAnswer, 
  onUsePowerCard, 
  setGameState 
}) => {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [visibleOptions, setVisibleOptions] = useState<number[]>([0, 1, 2, 3]);
  const [showHistory, setShowHistory] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [gameSettings, setGameSettings] = useState({
    soundEnabled: true,
    timePerQuestion: 15,
    maxQuestionsPerTeam: 10,
    theme: 'default' as 'default' | 'dark' | 'colorful',
    showHints: true,
    autoNextQuestion: false
  });

  const categoryQuestions = useGameCategories();
  const questionManager = useQuestionManager(categoryQuestions);

  const currentTeam = gameState.currentTurn;
  const currentTeamData = gameState[currentTeam + 'Team'];
  const otherTeam = currentTeam === 'red' ? 'blue' : 'red';
  const otherTeamData = gameState[otherTeam + 'Team'];

  useEffect(() => {
    setSelectedAnswer(null);
    setShowResult(false);
    setVisibleOptions([0, 1, 2, 3]);
  }, [gameState.currentQuestion]);

  useEffect(() => {
    if (gameState.usedPowerCard === 'fiftyFifty' && gameState.currentQuestion) {
      const correctIndex = gameState.currentQuestion.correctAnswer;
      const wrongOptions = [0, 1, 2, 3].filter(i => i !== correctIndex);
      const randomWrong = wrongOptions[Math.floor(Math.random() * wrongOptions.length)];
      setVisibleOptions([correctIndex, randomWrong].sort());
    }
  }, [gameState.usedPowerCard]);

  // إعادة تعيين الحالة عند تغيير الدور للفريق الآخر
  useEffect(() => {
    if (gameState.waitingForOpponent) {
      setSelectedAnswer(null);
      setShowResult(false);
    }
  }, [gameState.waitingForOpponent, gameState.currentTurn]);

  const handleAnswer = (optionIndex: number) => {
    if (selectedAnswer !== null || showResult) return;
    
    setSelectedAnswer(optionIndex);
    setShowResult(true);
    
    const isCorrect = optionIndex === gameState.currentQuestion?.correctAnswer;
    const answer = gameState.currentQuestion?.options[optionIndex] || '';
    
    setTimeout(() => {
      onAnswer(answer, isCorrect);
    }, 1000);
  };

  const handleTimeUp = () => {
    if (!showResult) {
      setShowResult(true);
      setTimeout(() => {
        onAnswer('لم يتم الإجابة', false);
      }, 1000);
    }
  };

  if (!gameState.currentQuestion) return null;

  const teamColors = {
    red: {
      primary: 'from-red-500 to-red-700',
      light: 'from-red-400 to-red-600',
      bg: 'bg-red-500/20',
      border: 'border-red-400/30',
      text: 'text-red-400'
    },
    blue: {
      primary: 'from-blue-500 to-blue-700',
      light: 'from-blue-400 to-blue-600',
      bg: 'bg-blue-500/20',
      border: 'border-blue-400/30',
      text: 'text-blue-400'
    }
  };

  return (
    <div className="min-h-screen p-4">
      {/* Header with Teams Score */}
      <div className="max-w-6xl mx-auto mb-8">
        <div className="grid grid-cols-3 gap-4 items-center">
          {/* Red Team */}
          <div className="bg-gradient-to-r from-red-500/20 to-red-700/20 backdrop-blur-md rounded-2xl p-4 border border-red-400/30">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Users className="w-6 h-6 text-red-400 mr-2" />
                <h3 className="text-xl font-bold text-red-400">الفريق الأحمر</h3>
              </div>
              <div className="text-3xl font-bold text-white">{gameState.redTeam.score}</div>
              <div className="text-red-200 text-sm">{gameState.redTeam.players.length} لاعب</div>
            </div>
          </div>

          {/* Current Turn Indicator */}
          <div className="text-center">
            <div className={`inline-flex items-center px-6 py-3 rounded-full bg-gradient-to-r ${teamColors[currentTeam].primary} text-white font-bold text-lg animate-pulse`}>
              {gameState.waitingForOpponent ? 
                `فرصة ${currentTeam === 'red' ? 'الفريق الأحمر' : 'الفريق الأزرق'}` :
                `دور ${currentTeam === 'red' ? 'الفريق الأحمر' : 'الفريق الأزرق'}`
              }
            </div>
            <div className="mt-2 text-white/70">
              السؤال {gameState.totalQuestions + 1} من {gameState.maxQuestionsPerTeam * 2}
            </div>
          </div>

          {/* Blue Team */}
          <div className="bg-gradient-to-r from-blue-500/20 to-blue-700/20 backdrop-blur-md rounded-2xl p-4 border border-blue-400/30">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Users className="w-6 h-6 text-blue-400 mr-2" />
                <h3 className="text-xl font-bold text-blue-400">الفريق الأزرق</h3>
              </div>
              <div className="text-3xl font-bold text-white">{gameState.blueTeam.score}</div>
              <div className="text-blue-200 text-sm">{gameState.blueTeam.players.length} لاعب</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Game Area */}
      <div className="max-w-4xl mx-auto">
        {/* Question Card */}
        <div className={`bg-gradient-to-br ${teamColors[currentTeam].bg} backdrop-blur-md rounded-3xl p-8 mb-8 border ${teamColors[currentTeam].border} transform transition-all duration-500`}>
          <div className="text-center mb-6">
            <div className="inline-flex items-center gap-4 mb-4">
              <Timer 
                timeLeft={gameState.timeLeft} 
                onTimeUp={handleTimeUp}
                setGameState={setGameState}
                disabled={showResult}
              />
              {gameState.waitingForOpponent && (
                <div className="flex items-center gap-2 px-4 py-2 bg-yellow-500/20 rounded-full text-yellow-300 text-sm">
                  <AlertCircle className="w-4 h-4" />
                  فرصة إضافية للإجابة
                </div>
              )}
            </div>
            
            <div className="bg-white/10 rounded-xl p-2 mb-4 inline-block">
              <span className="text-white/70 text-sm">الفئة: </span>
              <span className="text-white font-semibold">{gameState.currentQuestion.category}</span>
              <span className="text-white/70 text-sm ml-4">الصعوبة: </span>
              <span className="text-white font-semibold">
                {gameState.currentQuestion.difficulty === 'easy' ? 'سهل' : 
                 gameState.currentQuestion.difficulty === 'medium' ? 'متوسط' : 'صعب'}
              </span>
              <span className="text-white/70 text-sm ml-4">النقاط: </span>
              <span className="text-yellow-400 font-bold">{gameState.currentQuestion.points}</span>
            </div>
            
            <h2 className="text-3xl font-bold text-white leading-relaxed">
              {gameState.currentQuestion.question}
            </h2>
          </div>

          {/* Answer Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {gameState.currentQuestion.options.map((option, index) => {
              if (!visibleOptions.includes(index)) return null;
              
              let buttonClass = "p-6 rounded-2xl text-white font-semibold text-lg transition-all duration-300 transform hover:scale-105 border-2 ";
              
              if (showResult) {
                if (index === selectedAnswer) {
                  const isCorrect = index === gameState.currentQuestion.correctAnswer;
                  if (isCorrect) {
                    buttonClass += "bg-gradient-to-r from-green-500 to-green-600 border-green-400 shadow-lg shadow-green-500/50";
                  } else {
                    buttonClass += "bg-gradient-to-r from-red-500 to-red-600 border-red-400 shadow-lg shadow-red-500/50";
                  }
                } else {
                  buttonClass += "bg-gray-500/30 border-gray-500/30";
                }
              } else {
                buttonClass += `bg-white/10 border-white/20 hover:bg-white/20 hover:border-white/40 ${selectedAnswer === index ? 'ring-4 ring-white/50' : ''}`;
              }

              return (
                <button
                  key={index}
                  onClick={() => handleAnswer(index)}
                  disabled={showResult || selectedAnswer !== null}
                  className={buttonClass}
                >
                  <div className="flex items-center">
                    <span className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center mr-4 text-sm font-bold">
                      {String.fromCharCode(65 + index)}
                    </span>
                    {option}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Result Message */}
          {showResult && (
            <div className="text-center mt-6">
              {selectedAnswer === gameState.currentQuestion.correctAnswer ? (
                <div className="text-green-400 text-xl font-bold animate-bounce">
                  ✅ إجابة صحيحة! +{gameState.currentQuestion.points} نقطة
                </div>
              ) : gameState.waitingForOpponent ? (
                <div>
                  <div className="text-red-400 text-xl font-bold">
                    ❌ إجابة خاطئة
                  </div>
                  <div className="text-yellow-400 mt-2">
                    فرصة للفريق الآخر للإجابة!
                  </div>
                </div>
              ) : selectedAnswer !== null ? (
                <div>
                  <div className="text-red-400 text-xl font-bold">
                    ❌ إجابة خاطئة
                  </div>
                </div>
              ) : (
                <div>
                  <div className="text-yellow-400 text-xl font-bold">
                    ⏰ انتهى الوقت
                  </div>
                  {gameState.waitingForOpponent && (
                    <div className="text-yellow-400 mt-2">
                      فرصة للفريق الآخر للإجابة!
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Power Cards */}
        <PowerCards 
          gameState={gameState}
          onUsePowerCard={onUsePowerCard}
          disabled={showResult}
        />
      </div>
      
      {/* Settings Button */}
      <button
        onClick={() => setShowSettings(true)}
        className="fixed top-4 right-4 w-12 h-12 bg-gradient-to-r from-gray-600 to-gray-700 text-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 z-40"
        title="إعدادات اللعبة"
      >
        <Settings className="w-6 h-6" />
      </button>
      
      {/* Game Settings */}
      <GameSettings
        isVisible={showSettings}
        onClose={() => setShowSettings(false)}
        settings={gameSettings}
        onUpdateSettings={setGameSettings}
        onResetQuestions={questionManager.resetSession}
        onClearQuestionHistory={questionManager.resetAllHistory}
      />
      
      {/* Game History */}
      <GameHistory 
        history={gameState.gameHistory}
        isVisible={showHistory}
        onToggle={() => setShowHistory(!showHistory)}
      />
    </div>
  );
};

export default GameScreen;