import React from 'react';
import { Trophy, Target, TrendingUp, Award, Star } from 'lucide-react';
import { GameHistory } from '../types/game';

interface PlayerStatsProps {
  playerName: string;
  team: 'red' | 'blue';
  gameHistory: GameHistory[];
  isVisible: boolean;
  onClose: () => void;
}

const PlayerStats: React.FC<PlayerStatsProps> = ({
  playerName,
  team,
  gameHistory,
  isVisible,
  onClose
}) => {
  if (!isVisible) return null;

  const playerAnswers = gameHistory.filter(h => h.team === team);
  const correctAnswers = playerAnswers.filter(h => h.isCorrect);
  const wrongAnswers = playerAnswers.filter(h => !h.isCorrect);
  
  const totalPoints = correctAnswers.reduce((sum, h) => sum + h.points, 0);
  const accuracy = playerAnswers.length > 0 ? (correctAnswers.length / playerAnswers.length) * 100 : 0;
  
  const categoryStats = gameHistory.reduce((acc, h) => {
    if (h.team !== team) return acc;
    if (!acc[h.category]) {
      acc[h.category] = { correct: 0, total: 0, points: 0 };
    }
    acc[h.category].total++;
    if (h.isCorrect) {
      acc[h.category].correct++;
      acc[h.category].points += h.points;
    }
    return acc;
  }, {} as Record<string, { correct: number; total: number; points: number }>);

  const difficultyStats = gameHistory.reduce((acc, h) => {
    if (h.team !== team) return acc;
    if (!acc[h.difficulty]) {
      acc[h.difficulty] = { correct: 0, total: 0 };
    }
    acc[h.difficulty].total++;
    if (h.isCorrect) {
      acc[h.difficulty].correct++;
    }
    return acc;
  }, {} as Record<string, { correct: number; total: number }>);

  const getAccuracyColor = (acc: number) => {
    if (acc >= 80) return 'text-green-400';
    if (acc >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getRank = () => {
    if (accuracy >= 90) return { title: 'خبير', icon: Star, color: 'text-yellow-400' };
    if (accuracy >= 75) return { title: 'متقدم', icon: Award, color: 'text-purple-400' };
    if (accuracy >= 60) return { title: 'جيد', icon: Trophy, color: 'text-blue-400' };
    return { title: 'مبتدئ', icon: Target, color: 'text-gray-400' };
  };

  const rank = getRank();
  const RankIcon = rank.icon;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/20">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
              team === 'red' ? 'bg-red-500' : 'bg-blue-500'
            }`}>
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">{playerName}</h2>
              <div className="flex items-center gap-2">
                <RankIcon className={`w-4 h-4 ${rank.color}`} />
                <span className={`text-sm ${rank.color}`}>{rank.title}</span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center hover:bg-red-500/30 transition-all"
          >
            ×
          </button>
        </div>

        {/* Stats Overview */}
        <div className="p-6 border-b border-white/20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-white">{totalPoints}</div>
              <div className="text-white/70 text-sm">إجمالي النقاط</div>
            </div>
            <div className="text-center">
              <div className={`text-3xl font-bold ${getAccuracyColor(accuracy)}`}>
                {accuracy.toFixed(1)}%
              </div>
              <div className="text-white/70 text-sm">دقة الإجابة</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">{correctAnswers.length}</div>
              <div className="text-green-300 text-sm">إجابات صحيحة</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400">{wrongAnswers.length}</div>
              <div className="text-red-300 text-sm">إجابات خاطئة</div>
            </div>
          </div>
        </div>

        {/* Category Performance */}
        <div className="p-6 border-b border-white/20">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Target className="w-5 h-5 text-blue-400" />
            الأداء حسب الفئة
          </h3>
          <div className="space-y-3">
            {Object.entries(categoryStats).map(([category, stats]) => {
              const categoryAccuracy = (stats.correct / stats.total) * 100;
              return (
                <div key={category} className="bg-white/5 rounded-xl p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white font-semibold">{category}</span>
                    <span className={`text-sm font-bold ${getAccuracyColor(categoryAccuracy)}`}>
                      {categoryAccuracy.toFixed(0)}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-white/70">
                    <span>{stats.correct}/{stats.total} صحيحة</span>
                    <span>{stats.points} نقطة</span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-2 mt-2">
                    <div 
                      className={`h-2 rounded-full ${
                        categoryAccuracy >= 75 ? 'bg-green-400' :
                        categoryAccuracy >= 50 ? 'bg-yellow-400' : 'bg-red-400'
                      }`}
                      style={{ width: `${categoryAccuracy}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Difficulty Performance */}
        <div className="p-6">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-purple-400" />
            الأداء حسب الصعوبة
          </h3>
          <div className="grid grid-cols-3 gap-4">
            {Object.entries(difficultyStats).map(([difficulty, stats]) => {
              const difficultyAccuracy = (stats.correct / stats.total) * 100;
              const difficultyName = difficulty === 'easy' ? 'سهل' : 
                                   difficulty === 'medium' ? 'متوسط' : 'صعب';
              const difficultyColor = difficulty === 'easy' ? 'text-green-400' :
                                    difficulty === 'medium' ? 'text-yellow-400' : 'text-red-400';
              
              return (
                <div key={difficulty} className="bg-white/5 rounded-xl p-3 text-center">
                  <div className={`text-lg font-bold ${difficultyColor}`}>
                    {difficultyAccuracy.toFixed(0)}%
                  </div>
                  <div className="text-white text-sm mb-1">{difficultyName}</div>
                  <div className="text-white/70 text-xs">
                    {stats.correct}/{stats.total}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerStats;