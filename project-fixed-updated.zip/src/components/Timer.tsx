import React, { useEffect } from 'react';
import { Clock } from 'lucide-react';
import { GameState, OnlineGameState } from '../types/game';
import { supabase } from '../lib/supabase';

interface TimerProps {
  timeLeft: number;
  onTimeUp: () => void;
  setGameState?: React.Dispatch<React.SetStateAction<GameState>>;
  onlineGameState?: any;
  roomId?: string;
  disabled: boolean;
}

const Timer: React.FC<TimerProps> = ({ timeLeft, onTimeUp, setGameState, onlineGameState, roomId, disabled }) => {
  useEffect(() => {
    if (disabled || timeLeft <= 0) return;

    const timer = setInterval(() => {
      if (setGameState) {
        // للعب المحلي
        setGameState(prev => {
          const newTimeLeft = prev.timeLeft - 1;
          if (newTimeLeft <= 0) {
            onTimeUp();
            return { ...prev, timeLeft: 0 };
          }
          return { ...prev, timeLeft: newTimeLeft };
        });
      } else if (roomId && supabase) {
        // للعب الأونلاين
        const newTimeLeft = timeLeft - 1;
        if (newTimeLeft <= 0) {
          onTimeUp();
        } else {
          supabase
            .from('game_state')
            .update({ time_left: newTimeLeft })
            .eq('room_id', roomId);
        }
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, disabled, onTimeUp, setGameState, roomId]);

  const getTimerColor = () => {
    if (timeLeft > 10) return 'text-green-400';
    if (timeLeft > 5) return 'text-yellow-400';
    return 'text-red-400 animate-pulse';
  };

  const getCircleColor = () => {
    if (timeLeft > 10) return 'stroke-green-400';
    if (timeLeft > 5) return 'stroke-yellow-400';
    return 'stroke-red-400';
  };

  const radius = 30;
  const circumference = 2 * Math.PI * radius;
  const strokeDasharray = `${circumference} ${circumference}`;
  const strokeDashoffset = circumference - (timeLeft / 15) * circumference;

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg className="w-20 h-20 transform -rotate-90" width="80" height="80">
        <circle
          cx="40"
          cy="40"
          r={radius}
          stroke="rgba(255,255,255,0.2)"
          strokeWidth="4"
          fill="transparent"
        />
        <circle
          cx="40"
          cy="40"
          r={radius}
          stroke="currentColor"
          strokeWidth="4"
          fill="transparent"
          strokeDasharray={strokeDasharray}
          strokeDashoffset={strokeDashoffset}
          className={`transition-all duration-1000 ease-linear ${getCircleColor()}`}
        />
      </svg>
      
      <div className="absolute inset-0 flex items-center justify-center">
        <div className={`text-2xl font-bold ${getTimerColor()}`}>
          {timeLeft}
        </div>
      </div>
      
      <Clock className={`w-4 h-4 ml-2 ${getTimerColor()}`} />
    </div>
  );
};

export default Timer;