import React, { useState } from 'react';
import { Check, X, Play, BookOpen, Users, Trophy } from 'lucide-react';
import { useGameCategories } from '../hooks/useGameCategories';
import { getIconComponent } from '../lib/icons';

interface CategoryPreSelectionProps {
  onCategoriesSelected: (categories: string[]) => void;
  onBack: () => void;
}

const CategoryPreSelection: React.FC<CategoryPreSelectionProps> = ({
  onCategoriesSelected,
  onBack
}) => {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const categoryQuestions = useGameCategories();
  
  console.log('📋 تحميل صفحة اختيار التخصصات:', {
    totalCategories: categoryQuestions.length,
    categories: categoryQuestions.map(cat => cat.category)
  });

  const toggleCategory = (categoryName: string) => {
    setSelectedCategories(prev => {
      if (prev.includes(categoryName)) {
        return prev.filter(cat => cat !== categoryName);
      } else if (prev.length < 8) {
        return [...prev, categoryName];
      }
      return prev;
    });
  };

  const handleContinue = () => {
    console.log('🎯 تم الضغط على زر المتابعة - بدء المعالجة...');
    console.log('📋 التخصصات المختارة:', selectedCategories);
    console.log('📊 عدد التخصصات:', selectedCategories.length);
    console.log('🔍 نوع onCategoriesSelected:', typeof onCategoriesSelected);
    
    // إذا لم يتم اختيار أي تخصص، اختر جميع التخصصات
    const categoriesToUse = selectedCategories.length > 0 
      ? selectedCategories 
      : categoryQuestions.map(cat => cat.category);
    
    console.log('🚀 التخصصات النهائية التي سيتم إرسالها:', categoriesToUse);
    console.log('📤 استدعاء onCategoriesSelected الآن...');
    
    try {
      // استدعاء الدالة مع معالجة الأخطاء
      onCategoriesSelected(categoriesToUse);
      console.log('✅ تم استدعاء onCategoriesSelected بنجاح');
    } catch (error) {
      console.error('❌ خطأ في استدعاء onCategoriesSelected:', error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-6xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <BookOpen className="w-16 h-16 text-purple-400 mr-4" />
            <h1 className="text-6xl font-bold text-white">
              اختر التخصصات
            </h1>
            <BookOpen className="w-16 h-16 text-purple-400 ml-4" />
          </div>
          <p className="text-xl text-purple-200 mb-4">
            اختر التخصصات التي تريد اللعب بها (حد أقصى 8 تخصصات)
          </p>
          <div className="inline-flex items-center gap-4 px-6 py-3 bg-white/10 rounded-full">
            <span className="text-white">المختار: {selectedCategories.length}/8</span>
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" />
          </div>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {categoryQuestions.map((categoryData) => {
            const isSelected = selectedCategories.includes(categoryData.category);
            const isDisabled = !isSelected && selectedCategories.length >= 8;
            const Icon = getIconComponent(categoryData.icon);
            
            // حساب إجمالي الأسئلة في التخصص
            const totalQuestions = 
              categoryData.difficulties.easy.length +
              categoryData.difficulties.medium.length +
              categoryData.difficulties.hard.length;

            return (
              <button
                key={categoryData.category}
                onClick={() => !isDisabled && toggleCategory(categoryData.category)}
                disabled={isDisabled}
                className={`
                  relative p-6 rounded-3xl border-2 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                  ${isSelected 
                    ? 'bg-gradient-to-br from-purple-500/30 to-pink-500/30 border-purple-400 shadow-lg shadow-purple-500/50' 
                    : 'bg-white/10 border-white/20 hover:bg-white/20 hover:border-white/40'
                  }
                `}
              >
                {/* Selection Indicator */}
                <div className={`absolute top-4 right-4 w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
                  isSelected 
                    ? 'bg-green-500 border-green-400' 
                    : 'border-white/40'
                }`}>
                  {isSelected && <Check className="w-5 h-5 text-white" />}
                </div>

                {/* Category Icon */}
                <div className="text-center mb-4">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                    isSelected 
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500' 
                      : 'bg-gradient-to-r from-gray-500 to-gray-600'
                  }`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">{categoryData.category}</h3>
                  <p className="text-white/70 text-sm">{totalQuestions} سؤال متاح</p>
                </div>

                {/* Difficulty Breakdown */}
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="bg-green-500/20 rounded-lg p-2 text-center">
                    <div className="text-green-400 font-bold">{categoryData.difficulties.easy.length}</div>
                    <div className="text-green-300">سهل</div>
                  </div>
                  <div className="bg-yellow-500/20 rounded-lg p-2 text-center">
                    <div className="text-yellow-400 font-bold">{categoryData.difficulties.medium.length}</div>
                    <div className="text-yellow-300">متوسط</div>
                  </div>
                  <div className="bg-red-500/20 rounded-lg p-2 text-center">
                    <div className="text-red-400 font-bold">{categoryData.difficulties.hard.length}</div>
                    <div className="text-red-300">صعب</div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Categories Summary */}
        {selectedCategories.length > 0 && (
          <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 mb-8 border border-white/10">
            <h3 className="text-xl font-bold text-white text-center mb-4">التخصصات المختارة</h3>
            <div className="flex flex-wrap justify-center gap-3">
              {selectedCategories.map((category) => (
                <div
                  key={category}
                  className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full border border-purple-400/30"
                >
                  <span className="text-white font-semibold">{category}</span>
                  <button
                    onClick={() => toggleCategory(category)}
                    className="w-5 h-5 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center hover:bg-red-500/30 transition-all"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex justify-center gap-6">
          <button
            onClick={onBack}
            className="px-8 py-4 bg-gray-500/20 text-gray-300 font-bold text-xl rounded-2xl hover:bg-gray-500/30 transition-all duration-300 transform hover:scale-105"
          >
            العودة
          </button>
          
          <button
            onClick={handleContinue}
            className="px-12 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-xl rounded-2xl hover:from-purple-700 hover:to-pink-700 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-3"
          >
            <Play className="w-6 h-6" />
            {selectedCategories.length === 0 ? 'متابعة (جميع التخصصات)' : `متابعة (${selectedCategories.length} تخصص)`}
          </button>
        </div>

        {/* Instructions */}
        <div className="mt-12 bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
          <h3 className="text-xl font-bold text-white text-center mb-4">تعليمات اختيار التخصصات</h3>
          <div className="grid md:grid-cols-3 gap-6 text-white/80 text-sm">
            <div>
              <h4 className="font-semibold text-purple-300 mb-2">🎯 الاختيار:</h4>
              <ul className="space-y-1">
                <li>• اختر من 1 إلى 8 تخصصات</li>
                <li>• كلما زادت التخصصات، زاد التنوع</li>
                <li>• يمكن إلغاء الاختيار بالضغط على ×</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-blue-300 mb-2">📊 المعلومات:</h4>
              <ul className="space-y-1">
                <li>• عدد الأسئلة لكل تخصص</li>
                <li>• توزيع الصعوبة (سهل/متوسط/صعب)</li>
                <li>• التخصصات المختارة تظهر فقط في اللعبة</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-green-300 mb-2">🎮 اللعب:</h4>
              <ul className="space-y-1">
                <li>• ستظهر التخصصات المختارة فقط</li>
                <li>• تنوع أكبر في الأسئلة</li>
                <li>• تجربة مخصصة حسب اهتماماتك</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryPreSelection;