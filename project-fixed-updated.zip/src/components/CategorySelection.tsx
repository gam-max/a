import React from 'react';
import { GameState, UsedQuestion } from '../types/game';
import { useGameCategories } from '../hooks/useGameCategories';
import { useQuestionManager } from '../hooks/useQuestionManager';
import { getIconComponent } from '../lib/icons';

interface CategorySelectionProps {
  gameState: GameState;
  onSelectCategory: (category: string, difficulty: 'easy' | 'medium' | 'hard') => void;
}

const CategorySelection: React.FC<CategorySelectionProps> = ({ gameState, onSelectCategory }) => {
  console.log('🎯 === تحميل شاشة اختيار الفئات ===');
  console.log('📋 التخصصات المختارة:', gameState.selectedCategories);
  console.log('📊 عدد التخصصات المختارة:', gameState.selectedCategories?.length);
  console.log('🔍 حالة اللعبة الحالية:', gameState.phase);
  
  const currentTeam = gameState.currentTurn;
  const currentTeamData = gameState[currentTeam + 'Team'];
  const categoryQuestions = useGameCategories();
  const questionManager = useQuestionManager(categoryQuestions);

  // فلترة التخصصات حسب الاختيار المسبق
  const filteredCategories = categoryQuestions.filter(categoryData => {
    const isIncluded = gameState.selectedCategories && gameState.selectedCategories.includes(categoryData.category);
    console.log(`🔍 فحص تخصص "${categoryData.category}": ${isIncluded ? 'مُختار' : 'غير مُختار'}`);
    return isIncluded;
  });
  
  console.log('✅ التخصصات المفلترة التي ستظهر:', filteredCategories.map(cat => cat.category));
  console.log('📊 عدد التخصصات المفلترة:', filteredCategories.length);

  const difficultyColors = {
    easy: 'from-green-500 to-green-600',
    medium: 'from-yellow-500 to-orange-500',
    hard: 'from-red-500 to-red-600'
  };

  const difficultyNames = {
    easy: 'سهل',
    medium: 'متوسط',
    hard: 'صعب'
  };

  const isQuestionUsed = (category: string, difficulty: 'easy' | 'medium' | 'hard') => {
    return gameState.usedQuestions.some(
      used => used.category === category && used.difficulty === difficulty
    );
  };

  // فحص ما إذا كانت جميع الأسئلة المتاحة قد استُخدمت
  const areAllQuestionsUsed = () => {
    return filteredCategories.every(categoryData => 
      (['easy', 'medium', 'hard'] as const).every(difficulty => 
        isQuestionUsed(categoryData.category, difficulty)
      )
    );
  };

  // إذا انتهت جميع الأسئلة، انتقل لشاشة النتائج
  React.useEffect(() => {
    if (areAllQuestionsUsed() && gameState.totalQuestions > 0) {
      console.log('🏁 انتهت جميع الأسئلة المتاحة - الانتقال لشاشة النتائج');
      // تأخير قصير لإظهار الرسالة
      setTimeout(() => {
        onSelectCategory('END_GAME', 'easy'); // إشارة خاصة لإنهاء اللعبة
      }, 2000);
    }
  }, [gameState.usedQuestions, gameState.totalQuestions]);

  // الحصول على إحصائيات الاستخدام
  const getQuestionStats = (category: string, difficulty: 'easy' | 'medium' | 'hard') => {
    const stats = questionManager.getUsageStats(category, difficulty);
    return stats;
  };
  const teamColors = {
    red: {
      primary: 'from-red-500 to-red-700',
      bg: 'bg-red-500/20',
      border: 'border-red-400/30',
      text: 'text-red-400'
    },
    blue: {
      primary: 'from-blue-500 to-blue-700',
      bg: 'bg-blue-500/20',
      border: 'border-blue-400/30',
      text: 'text-blue-400'
    }
  };

  return (
    <div className="min-h-screen p-4">
      {/* Header */}
      <div className="max-w-6xl mx-auto mb-8">
        <div className="text-center mb-8">
          <div className={`inline-flex items-center px-8 py-4 rounded-full bg-gradient-to-r ${teamColors[currentTeam].primary} text-white font-bold text-2xl animate-pulse`}>
            دور {currentTeam === 'red' ? 'الفريق الأحمر' : 'الفريق الأزرق'} - اختر الفئة والصعوبة
          </div>
        </div>

        {/* Teams Score */}
        <div className="grid grid-cols-2 gap-8 mb-8">
          <div className="bg-gradient-to-r from-red-500/20 to-red-700/20 backdrop-blur-md rounded-2xl p-6 border border-red-400/30">
            <div className="text-center">
              <h3 className="text-xl font-bold text-red-400 mb-2">الفريق الأحمر</h3>
              <div className="text-4xl font-bold text-white">{gameState.redTeam.score}</div>
            </div>
          </div>
          <div className="bg-gradient-to-r from-blue-500/20 to-blue-700/20 backdrop-blur-md rounded-2xl p-6 border border-blue-400/30">
            <div className="text-center">
              <h3 className="text-xl font-bold text-blue-400 mb-2">الفريق الأزرق</h3>
              <div className="text-4xl font-bold text-white">{gameState.blueTeam.score}</div>
            </div>
          </div>
        </div>
      </div>

      {/* رسالة انتهاء الأسئلة */}
      {areAllQuestionsUsed() && gameState.totalQuestions > 0 && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-md rounded-3xl p-8 border border-yellow-400/30 text-center animate-pulse">
            <div className="text-6xl mb-4">🏁</div>
            <h2 className="text-3xl font-bold text-yellow-400 mb-4">انتهت جميع الأسئلة!</h2>
            <p className="text-yellow-200 text-xl">جاري الانتقال لإعلان النتائج...</p>
            <div className="mt-4 flex justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-400"></div>
            </div>
          </div>
        </div>
      )}

      {/* Categories Grid */}
      <div className="max-w-6xl mx-auto">
        <div className={`grid gap-6 ${
          filteredCategories.length <= 2 ? 'grid-cols-1 md:grid-cols-2 max-w-4xl mx-auto' :
          filteredCategories.length <= 4 ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-2 max-w-5xl mx-auto' :
          filteredCategories.length <= 6 ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' :
          'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'
        }`}>
          {filteredCategories.map((categoryData) => {
            const Icon = getIconComponent(categoryData.icon);
            
            return (
              <div key={categoryData.category} className="bg-white/10 backdrop-blur-md rounded-3xl p-6 border border-white/20">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    {Icon && <Icon className="w-8 h-8 text-white" />}
                  </div>
                  <h3 className="text-2xl font-bold text-white">{categoryData.category}</h3>
                </div>

                <div className="space-y-3">
                  {(['easy', 'medium', 'hard'] as const).map((difficulty) => {
                    const isUsed = isQuestionUsed(categoryData.category, difficulty);
                    const points = difficulty === 'easy' ? 10 : difficulty === 'medium' ? 20 : 30;
                    const stats = getQuestionStats(categoryData.category, difficulty);
                    
                    return (
                      <button
                        key={difficulty}
                        onClick={() => !isUsed && onSelectCategory(categoryData.category, difficulty)}
                        disabled={isUsed}
                        className={`
                          w-full p-4 rounded-xl text-white font-semibold transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                          bg-gradient-to-r ${difficultyColors[difficulty]}
                          ${!isUsed ? 'hover:shadow-lg hover:shadow-white/20' : ''}
                        `}
                      >
                        <div className="flex items-center justify-between">
                          <span>{difficultyNames[difficulty]}</span>
                          <div className="text-right">
                            <div className="text-lg font-bold">{points} نقطة</div>
                            {stats.total > 0 && (
                              <div className="text-xs opacity-75">
                                {stats.total - stats.used} متاح
                              </div>
                            )}
                          </div>
                        </div>
                        {isUsed && (
                          <div className="text-sm opacity-75 mt-1">مُستخدم</div>
                        )}
                        {stats.needsReset && !isUsed && (
                          <div className="text-xs text-yellow-300 mt-1">
                            💡 نصيحة: أعد تشغيل اللعبة لأسئلة جديدة
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* عرض معلومات التخصصات المختارة */}
        <div className="mt-8 bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
          <div className="text-center">
            <h3 className="text-xl font-bold text-white mb-4">
              🎯 التخصصات المختارة ({filteredCategories.length})
            </h3>
            <div className="flex flex-wrap justify-center gap-3">
              {filteredCategories.map((categoryData) => {
                const Icon = getIconComponent(categoryData.icon);
                const totalQuestions = 
                  categoryData.difficulties.easy.length +
                  categoryData.difficulties.medium.length +
                  categoryData.difficulties.hard.length;
                
                return (
                  <div
                    key={categoryData.category}
                    className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full border border-purple-400/30"
                  >
                    <Icon className="w-4 h-4 text-purple-400" />
                    <span className="text-white font-semibold">{categoryData.category}</span>
                    <span className="text-white/70 text-xs">({totalQuestions})</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="mt-8 bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
          <h3 className="text-xl font-bold text-white text-center mb-4">تعليمات اللعب</h3>
          <div className="grid md:grid-cols-3 gap-6 text-white/80 text-sm">
            <div>
              <h4 className="font-semibold text-green-300 mb-2">نظام النقاط:</h4>
              <ul className="space-y-1">
                <li>• سهل: 10 نقاط</li>
                <li>• متوسط: 20 نقطة</li>
                <li>• صعب: 30 نقطة</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-blue-300 mb-2">القواعد:</h4>
              <ul className="space-y-1">
                <li>• لا يمكن اختيار نفس السؤال مرتين</li>
                <li>• 15 ثانية للإجابة</li>
                <li>• فرصة للفريق الآخر عند الخطأ</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-purple-300 mb-2">الاستراتيجية:</h4>
              <ul className="space-y-1">
                <li>• اختر الصعوبة المناسبة</li>
                <li>• استخدم كروت المساعدة بحكمة</li>
                <li>• فكر في اختيارات الفريق الآخر</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategorySelection;