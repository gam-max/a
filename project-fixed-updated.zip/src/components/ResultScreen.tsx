import React from 'react';
import { Trophy, Medal, RotateCcw, Users, TrendingUp, Home, Star, Crown, Sparkles } from 'lucide-react';
import { GameState } from '../types/game';

interface ResultScreenProps {
  gameState: GameState;
  onRestart: () => void;
  onBackToHome?: () => void;
}

const ResultScreen: React.FC<ResultScreenProps> = ({ gameState, onRestart, onBackToHome }) => {
  const redScore = gameState.redTeam.score;
  const blueScore = gameState.blueTeam.score;
  const winner = redScore > blueScore ? 'red' : blueScore > redScore ? 'blue' : 'tie';

  // تشغيل المؤثرات الصوتية
  React.useEffect(() => {
    const playWinSound = () => {
      try {
        // إنشاء مؤثرات صوتية باستخدام Web Audio API
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        
        if (winner === 'tie') {
          // صوت التعادل - نغمة متوازنة
          playTieSound(audioContext);
          console.log('🎵 تشغيل صوت التعادل');
        } else {
          // صوت الفوز - نغمة احتفالية
          playVictorySound(audioContext);
          console.log(`🎵 تشغيل صوت فوز الفريق ${winner === 'red' ? 'الأحمر' : 'الأزرق'}`);
        }
      } catch (error) {
        console.log('🔇 المتصفح لا يدعم Web Audio API أو تم منع التشغيل التلقائي');
      }
    };

    // تأخير قصير قبل تشغيل الصوت
    const soundTimer = setTimeout(playWinSound, 500);
    
    return () => clearTimeout(soundTimer);
  }, [winner]);

  // دالة تشغيل صوت الفوز
  const playVictorySound = (audioContext: AudioContext) => {
    // نغمة احتفالية متصاعدة
    const frequencies = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    
    frequencies.forEach((freq, index) => {
      setTimeout(() => {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(freq, audioContext.currentTime);
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0, audioContext.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.1);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.5);
      }, index * 200);
    });
    
    // إضافة طبلة احتفالية
    setTimeout(() => {
      for (let i = 0; i < 3; i++) {
        setTimeout(() => {
          const oscillator = audioContext.createOscillator();
          const gainNode = audioContext.createGain();
          
          oscillator.connect(gainNode);
          gainNode.connect(audioContext.destination);
          
          oscillator.frequency.setValueAtTime(80, audioContext.currentTime);
          oscillator.type = 'triangle';
          
          gainNode.gain.setValueAtTime(0, audioContext.currentTime);
          gainNode.gain.linearRampToValueAtTime(0.5, audioContext.currentTime + 0.01);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
          
          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.2);
        }, i * 150);
      }
    }, 1000);
  };

  // دالة تشغيل صوت التعادل
  const playTieSound = (audioContext: AudioContext) => {
    // نغمة متوازنة للتعادل
    const frequencies = [440, 554.37, 440, 554.37]; // A4, C#5, A4, C#5
    
    frequencies.forEach((freq, index) => {
      setTimeout(() => {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(freq, audioContext.currentTime);
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0, audioContext.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.2, audioContext.currentTime + 0.1);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.4);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.4);
      }, index * 300);
    });
  };

  const getWinnerData = () => {
    if (winner === 'tie') {
      return {
        title: 'تعادل!',
        subtitle: 'أداء رائع من الفريقين',
        color: 'from-purple-500 to-pink-500',
        icon: Medal
      };
    }
    
    const winnerTeam = winner === 'red' ? gameState.redTeam : gameState.blueTeam;
    return {
      title: `فوز ${winner === 'red' ? 'الفريق الأحمر' : 'الفريق الأزرق'}!`,
      subtitle: `تهانينا لجميع أعضاء الفريق`,
      color: winner === 'red' ? 'from-red-500 to-red-700' : 'from-blue-500 to-blue-700',
      icon: Trophy,
      team: winnerTeam
    };
  };

  const winnerData = getWinnerData();
  const Icon = winnerData.icon;

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        {/* تأثيرات الفوز المتحركة */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          {/* نجوم متحركة */}
          {[...Array(20)].map((_, i) => (
            <Star
              key={i}
              className={`absolute text-yellow-400 animate-bounce opacity-70 ${
                i % 4 === 0 ? 'w-4 h-4' : i % 4 === 1 ? 'w-6 h-6' : i % 4 === 2 ? 'w-3 h-3' : 'w-5 h-5'
              }`}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`
              }}
            />
          ))}
          
          {/* شرارات متحركة */}
          {[...Array(15)].map((_, i) => (
            <Sparkles
              key={`sparkle-${i}`}
              className={`absolute animate-pulse opacity-60 ${
                winner === 'red' ? 'text-red-400' : 
                winner === 'blue' ? 'text-blue-400' : 'text-purple-400'
              } ${i % 3 === 0 ? 'w-3 h-3' : i % 3 === 1 ? 'w-5 h-5' : 'w-4 h-4'}`}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${1.5 + Math.random() * 1.5}s`
              }}
            />
          ))}
        </div>

        {/* Winner Announcement */}
        <div className="text-center mb-12">
          <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full bg-gradient-to-r ${winnerData.color} mb-6 animate-bounce shadow-2xl`}>
            <Icon className="w-16 h-16 text-white" />
          </div>
          
          {/* تأثير التاج للفائز */}
          {winner !== 'tie' && (
            <div className="flex justify-center mb-4">
              <Crown className="w-12 h-12 text-yellow-400 animate-pulse" />
            </div>
          )}
          
          <h1 className="text-6xl font-bold text-white mb-4 animate-pulse">
            {winnerData.title}
          </h1>
          
          <p className="text-2xl text-white/80 mb-8 animate-fade-in">
            {winnerData.subtitle}
          </p>

          {winner !== 'tie' && (
            <div className="text-7xl font-bold text-white mb-4 animate-bounce">
              {winner === 'red' ? redScore : blueScore} نقطة
            </div>
          )}
          
          {/* رسالة تهنئة إضافية */}
          <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-md rounded-2xl p-6 border border-yellow-400/30 mb-8 animate-fade-in">
            <h3 className="text-2xl font-bold text-yellow-400 mb-2">🎉 تهانينا!</h3>
            <p className="text-yellow-200">
              {winner === 'tie' 
                ? 'أداء رائع من كلا الفريقين! تعادل مثير ومستحق.' 
                : `الفريق ${winner === 'red' ? 'الأحمر' : 'الأزرق'} يستحق الفوز بجدارة!`
              }
            </p>
          </div>
        </div>

        {/* Final Scores */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* Red Team */}
          <div className={`bg-gradient-to-br from-red-500/20 to-red-700/20 backdrop-blur-md rounded-3xl p-8 border border-red-400/30 ${winner === 'red' ? 'ring-4 ring-red-400 shadow-2xl shadow-red-500/50' : ''}`}>
            <div className="text-center">
              {winner === 'red' && (
                <Trophy className="w-12 h-12 text-yellow-400 mx-auto mb-4 animate-pulse" />
              )}
              
              <div className="flex items-center justify-center mb-4">
                <Users className="w-8 h-8 text-red-400 mr-3" />
                <h3 className="text-3xl font-bold text-red-400">الفريق الأحمر</h3>
              </div>
              
              <div className="text-6xl font-bold text-white mb-4">{redScore}</div>
              <div className="text-red-200 mb-6">{gameState.redTeam.players.length} لاعب</div>
              
              <div className="space-y-3">
                {gameState.redTeam.players.map((player, index) => (
                  <div key={player.id} className="bg-red-500/30 rounded-xl p-3">
                    <div className="flex items-center justify-center">
                      <span className="text-white font-semibold">{player.name}</span>
                      {index === 0 && (
                        <Medal className="w-4 h-4 text-yellow-400 ml-2" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Blue Team */}
          <div className={`bg-gradient-to-br from-blue-500/20 to-blue-700/20 backdrop-blur-md rounded-3xl p-8 border border-blue-400/30 ${winner === 'blue' ? 'ring-4 ring-blue-400 shadow-2xl shadow-blue-500/50' : ''}`}>
            <div className="text-center">
              {winner === 'blue' && (
                <Trophy className="w-12 h-12 text-yellow-400 mx-auto mb-4 animate-pulse" />
              )}
              
              <div className="flex items-center justify-center mb-4">
                <Users className="w-8 h-8 text-blue-400 mr-3" />
                <h3 className="text-3xl font-bold text-blue-400">الفريق الأزرق</h3>
              </div>
              
              <div className="text-6xl font-bold text-white mb-4">{blueScore}</div>
              <div className="text-blue-200 mb-6">{gameState.blueTeam.players.length} لاعب</div>
              
              <div className="space-y-3">
                {gameState.blueTeam.players.map((player, index) => (
                  <div key={player.id} className="bg-blue-500/30 rounded-xl p-3">
                    <div className="flex items-center justify-center">
                      <span className="text-white font-semibold">{player.name}</span>
                      {index === 0 && (
                        <Medal className="w-4 h-4 text-yellow-400 ml-2" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Game Statistics */}
        <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 mb-8 border border-white/10">
          <h3 className="text-2xl font-bold text-white text-center mb-6 flex items-center justify-center gap-2">
            <TrendingUp className="w-6 h-6 text-green-400" />
            إحصائيات اللعبة
          </h3>
          
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold text-white mb-2">{gameState.gameHistory.length}</div>
              <div className="text-white/70">إجمالي الأسئلة</div>
            </div>
            
            <div>
              <div className="text-3xl font-bold text-green-400 mb-2">
                {gameState.gameHistory.filter(h => h.isCorrect).length}
              </div>
              <div className="text-white/70">إجابات صحيحة</div>
            </div>
            
            <div>
              <div className="text-3xl font-bold text-red-400 mb-2">
                {gameState.gameHistory.filter(h => !h.isCorrect).length}
              </div>
              <div className="text-white/70">إجابات خاطئة</div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="text-center">
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={onRestart}
              className="px-8 py-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold text-xl rounded-2xl hover:from-green-700 hover:to-emerald-700 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-3"
            >
              <RotateCcw className="w-6 h-6" />
              لعبة جديدة
            </button>
            
            {onBackToHome && (
              <button
                onClick={onBackToHome}
                className="px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-xl rounded-2xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-3"
              >
                <Home className="w-6 h-6" />
                الصفحة الرئيسية
              </button>
            )}
          </div>
          
          {/* نصائح للمستخدم */}
          <div className="mt-6 bg-blue-500/10 border border-blue-400/30 rounded-xl p-4 max-w-md mx-auto">
            <div className="text-blue-300 text-sm space-y-1">
              <p>🎮 <strong>نصائح:</strong></p>
              <p>• اضغط "لعبة جديدة" للعب مرة أخرى</p>
              <p>• اضغط "الصفحة الرئيسية" لتغيير الإعدادات</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultScreen;