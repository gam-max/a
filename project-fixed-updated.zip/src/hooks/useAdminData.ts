import { useState, useEffect, useCallback } from 'react';
import { Category, AdminQuestion, AdminStats, AdminActivity, AdminFilters } from '../types/admin';
import { categoryQuestions } from '../data/questions';

// محاكاة قاعدة البيانات المحلية
const STORAGE_KEYS = {
  CATEGORIES: 'admin_categories',
  QUESTIONS: 'admin_questions',
  ACTIVITY: 'admin_activity'
};

// الفئات الافتراضية
const DEFAULT_CATEGORIES: Category[] = [
  {
    id: '1',
    nameAr: 'التاريخ',
    nameEn: 'History',
    icon: 'Book',
    color: 'from-amber-500 to-orange-600',
    description: 'أسئلة حول التاريخ العربي والعالمي',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: '2',
    nameAr: 'الجغرافيا',
    nameEn: 'Geography',
    icon: 'Globe',
    color: 'from-green-500 to-emerald-600',
    description: 'أسئلة حول الجغرافيا والدول والعواصم',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: '3',
    nameAr: 'العلوم',
    nameEn: 'Science',
    icon: 'Atom',
    color: 'from-blue-500 to-cyan-600',
    description: 'أسئلة حول الفيزياء والكيمياء والأحياء',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: '4',
    nameAr: 'التكنولوجيا',
    nameEn: 'Technology',
    icon: 'Smartphone',
    color: 'from-purple-500 to-indigo-600',
    description: 'أسئلة حول التكنولوجيا والحاسوب',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: '5',
    nameAr: 'الأدب',
    nameEn: 'Literature',
    icon: 'PenTool',
    color: 'from-pink-500 to-rose-600',
    description: 'أسئلة حول الأدب العربي والعالمي',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: '6',
    nameAr: 'الرياضة',
    nameEn: 'Sports',
    icon: 'Trophy',
    color: 'from-red-500 to-pink-600',
    description: 'أسئلة حول الرياضة والألعاب',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const useAdminData = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [questions, setQuestions] = useState<AdminQuestion[]>([]);
  const [activity, setActivity] = useState<AdminActivity[]>([]);
  const [loading, setLoading] = useState(true);

  /**
   * To support reverting to a previous state the hook keeps a snapshot
   * of the last known categories and questions prior to any mutation. When
   * a create, update or delete operation is performed the current
   * categories/questions are copied into these refs. Calling
   * `revertChanges` will restore those snapshots and persist them back
   * into localStorage. This provides a simple undo mechanism so admins
   * can roll back accidental changes from the UI.
   */
  const [prevCategories, setPrevCategories] = useState<Category[]>([]);
  const [prevQuestions, setPrevQuestions] = useState<AdminQuestion[]>([]);

  /**
   * Take a snapshot of current categories and questions. This should be
   * invoked immediately before any state mutation so that the current
   * data can be restored later.
   */
  const backupData = useCallback(() => {
    setPrevCategories(() => categories.map(cat => ({ ...cat })));
    setPrevQuestions(() => questions.map(q => ({ ...q })));
  }, [categories, questions]);

  /**
   * Restore the previously backed up categories and questions. The
   * restored data is written to localStorage to ensure consistency
   * across tabs and persisted across reloads. An admin activity entry
   * is added so that other hooks can react to the change.
   */
  const revertChanges = useCallback(() => {
    // Only restore if a backup exists
    if (prevCategories.length > 0) {
      setCategories(prevCategories);
      saveData('categories', prevCategories);
    }
    if (prevQuestions.length > 0) {
      setQuestions(prevQuestions);
      saveData('questions', prevQuestions);
    }
    if (prevCategories.length > 0 || prevQuestions.length > 0) {
      addActivity('update', 'category', 'استرجاع التحديث السابق');
    }
  }, [prevCategories, prevQuestions, saveData, addActivity]);

  // تحميل البيانات من localStorage
  const loadData = useCallback(() => {
    try {
      const savedCategories = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      const savedQuestions = localStorage.getItem(STORAGE_KEYS.QUESTIONS);
      const savedActivity = localStorage.getItem(STORAGE_KEYS.ACTIVITY);

      if (savedCategories) {
        setCategories(JSON.parse(savedCategories));
      } else {
        setCategories(DEFAULT_CATEGORIES);
        localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(DEFAULT_CATEGORIES));
      }

      if (savedQuestions) {
        setQuestions(JSON.parse(savedQuestions));
      } else {
        // تحويل الأسئلة الحالية إلى تنسيق الإدارة
        const convertedQuestions = convertExistingQuestions();
        setQuestions(convertedQuestions);
        localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(convertedQuestions));
      }

      if (savedActivity) {
        setActivity(JSON.parse(savedActivity));
      }
    } catch (error) {
      console.error('Error loading admin data:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  // تحويل الأسئلة الحالية إلى تنسيق الإدارة
  const convertExistingQuestions = (): AdminQuestion[] => {
    const converted: AdminQuestion[] = [];
    let questionId = 1;

    categoryQuestions.forEach((categoryData) => {
      const category = DEFAULT_CATEGORIES.find(c => c.nameAr === categoryData.category);
      if (!category) return;

      Object.entries(categoryData.difficulties).forEach(([difficulty, questions]) => {
        questions.forEach((question) => {
          converted.push({
            id: `q_${questionId++}`,
            categoryId: category.id,
            question: question.question,
            type: 'multiple_choice',
            options: question.options,
            correctAnswer: question.correctAnswer,
            difficulty: difficulty as 'easy' | 'medium' | 'hard',
            difficultyLevel: difficulty === 'easy' ? 1 : difficulty === 'medium' ? 3 : 5,
            points: question.points,
            explanation: '',
            notes: '',
            tags: [category.nameAr, difficulty],
            isActive: true,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          });
        });
      });
    });

    return converted;
  };

  // حفظ البيانات
  const saveData = useCallback((type: 'categories' | 'questions' | 'activity', data: any) => {
    const key = type === 'categories' ? STORAGE_KEYS.CATEGORIES :
                type === 'questions' ? STORAGE_KEYS.QUESTIONS :
                STORAGE_KEYS.ACTIVITY;
    localStorage.setItem(key, JSON.stringify(data));
    
    // إرسال حدث مخصص لإعلام المكونات الأخرى بالتغيير
    window.dispatchEvent(new CustomEvent('adminDataChanged'));
  }, []);

  // إضافة نشاط جديد
  const addActivity = useCallback((
    type: 'create' | 'update' | 'delete',
    entity: 'category' | 'question',
    entityName: string,
    details?: string
  ) => {
    const newActivity: AdminActivity = {
      id: Date.now().toString(),
      type,
      entity,
      entityName,
      timestamp: new Date().toISOString(),
      details
    };

    setActivity(prev => {
      const updated = [newActivity, ...prev].slice(0, 50); // الاحتفاظ بآخر 50 نشاط
      saveData('activity', updated);
      return updated;
    });
    
    // إرسال إشعار للمكونات الأخرى
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('adminDataChanged'));
    }, 100);
  }, [saveData]);

  // إدارة الفئات
  const createCategory = useCallback((categoryData: Omit<Category, 'id' | 'createdAt' | 'updatedAt'>) => {
    // take a backup before making any changes so we can revert if needed
    backupData();

    const newCategory: Category = {
      ...categoryData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setCategories(prev => {
      const updated = [...prev, newCategory];
      saveData('categories', updated);
      return updated;
    });

    addActivity('create', 'category', categoryData.nameAr);
    
    console.log('✅ تم إنشاء تخصص جديد محلياً:', newCategory);
    return newCategory;
  }, [backupData, saveData, addActivity]);

  const updateCategory = useCallback((id: string, updates: Partial<Category>) => {
    // take a backup before making any changes so we can revert if needed
    backupData();
    setCategories(prev => {
      const updated = prev.map(cat => 
        cat.id === id 
          ? { ...cat, ...updates, updatedAt: new Date().toISOString() }
          : cat
      );
      saveData('categories', updated);
      return updated;
    });

    const category = categories.find(c => c.id === id);
    if (category) {
      addActivity('update', 'category', category.nameAr);
    }
  }, [categories, backupData, saveData, addActivity]);

  const deleteCategory = useCallback((id: string) => {
    const category = categories.find(c => c.id === id);
    if (!category) return;

    // take a backup before making any changes so we can revert if needed
    backupData();

    // حذف الأسئلة المرتبطة بالفئة
    setQuestions(prev => {
      const updated = prev.filter(q => q.categoryId !== id);
      saveData('questions', updated);
      return updated;
    });

    setCategories(prev => {
      const updated = prev.filter(cat => cat.id !== id);
      saveData('categories', updated);
      return updated;
    });

    addActivity('delete', 'category', category.nameAr);
  }, [categories, backupData, saveData, addActivity]);

  // إدارة الأسئلة
  const createQuestion = useCallback((questionData: Omit<AdminQuestion, 'id' | 'createdAt' | 'updatedAt'>) => {
    // take a backup before making any changes so we can revert if needed
    backupData();

    const newQuestion: AdminQuestion = {
      ...questionData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setQuestions(prev => {
      const updated = [...prev, newQuestion];
      saveData('questions', updated);
      return updated;
    });

    addActivity('create', 'question', questionData.question.substring(0, 50) + '...');
    return newQuestion;
  }, [backupData, saveData, addActivity]);

  const updateQuestion = useCallback((id: string, updates: Partial<AdminQuestion>) => {
    // take a backup before making any changes so we can revert if needed
    backupData();
    setQuestions(prev => {
      const updated = prev.map(q => 
        q.id === id 
          ? { ...q, ...updates, updatedAt: new Date().toISOString() }
          : q
      );
      saveData('questions', updated);
      return updated;
    });

    const question = questions.find(q => q.id === id);
    if (question) {
      addActivity('update', 'question', question.question.substring(0, 50) + '...');
    }
  }, [questions, backupData, saveData, addActivity]);

  const deleteQuestion = useCallback((id: string) => {
    const question = questions.find(q => q.id === id);
    if (!question) return;

    // take a backup before making any changes so we can revert if needed
    backupData();

    setQuestions(prev => {
      const updated = prev.filter(q => q.id !== id);
      saveData('questions', updated);
      return updated;
    });

    addActivity('delete', 'question', question.question.substring(0, 50) + '...');
  }, [questions, backupData, saveData, addActivity]);

  // فلترة الأسئلة
  const getFilteredQuestions = useCallback((filters: AdminFilters) => {
    return questions.filter(question => {
      if (filters.categoryId && question.categoryId !== filters.categoryId) return false;
      if (filters.difficulty && question.difficulty !== filters.difficulty) return false;
      if (filters.isActive !== undefined && question.isActive !== filters.isActive) return false;
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase();
        if (!question.question.toLowerCase().includes(query) &&
            !question.options.some(opt => opt.toLowerCase().includes(query))) {
          return false;
        }
      }
      if (filters.tags && filters.tags.length > 0) {
        if (!filters.tags.some(tag => question.tags.includes(tag))) return false;
      }
      return true;
    });
  }, [questions]);

  // إحصائيات
  const getStats = useCallback((): AdminStats => {
    const questionsByDifficulty = questions.reduce((acc, q) => {
      acc[q.difficulty]++;
      return acc;
    }, { easy: 0, medium: 0, hard: 0 });

    const questionsByCategory = questions.reduce((acc, q) => {
      const category = categories.find(c => c.id === q.categoryId);
      if (category) {
        acc[category.nameAr] = (acc[category.nameAr] || 0) + 1;
      }
      return acc;
    }, {} as Record<string, number>);

    return {
      totalCategories: categories.length,
      totalQuestions: questions.length,
      questionsByDifficulty,
      questionsByCategory,
      recentActivity: activity.slice(0, 10)
    };
  }, [categories, questions, activity]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // إضافة مستمع للتغييرات في localStorage لتحديث البيانات عند التعديل من لوحة التحكم
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === STORAGE_KEYS.CATEGORIES || e.key === STORAGE_KEYS.QUESTIONS) {
        loadData();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    
    // مستمع مخصص للتغييرات في نفس التبويب
    const handleCustomStorageChange = () => {
      loadData();
    };

    window.addEventListener('adminDataChanged', handleCustomStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('adminDataChanged', handleCustomStorageChange);
    };
  }, [loadData]);
  return {
    // البيانات
    categories,
    questions,
    activity,
    loading,
    
    // العمليات
    createCategory,
    updateCategory,
    deleteCategory,
    createQuestion,
    updateQuestion,
    deleteQuestion,
    
    // المساعدات
    getFilteredQuestions,
    getStats,
    
    // إعادة التحميل
    reload: loadData,

    // ability to revert to previous data snapshot
    revertChanges
  };
};