import { useState, useEffect, useCallback } from 'react';
import { supabase, hasValidSupabaseConfig } from '../lib/supabase';
import { Category, AdminQuestion, AdminStats, AdminActivity, AdminFilters } from '../types/admin';
import { createAdminTables } from '../lib/createAdminTables';

export const useOnlineAdminData = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [questions, setQuestions] = useState<AdminQuestion[]>([]);
  const [activity, setActivity] = useState<AdminActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(hasValidSupabaseConfig);
  const [tablesCreated, setTablesCreated] = useState(false);

  // تحميل البيانات من Supabase
  const loadData = useCallback(async () => {
    if (!hasValidSupabaseConfig || !supabase) {
      console.log('📱 الوضع المحلي نشط - استخدام localStorage');
      setIsOnline(false);
      setLoading(false);
      return;
    }

    try {
      console.log('🌐 🎉 الوضع الأونلاين نشط - قاعدة البيانات جاهزة!');
      setIsOnline(true);
      setTablesCreated(true);

      // محاولة تحميل البيانات أولاً

      // تحميل التخصصات
      const { data: categoriesData, error: categoriesError } = await supabase
        .from('admin_categories')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: true });

      if (categoriesError) {
        console.error('❌ خطأ في تحميل التخصصات:', categoriesError);
        console.log('📱 التبديل إلى الوضع المحلي');
        setIsOnline(false);
        setLoading(false);
        return;
      }

      // تحويل البيانات لتنسيق التطبيق
      const formattedCategories: Category[] = (categoriesData || []).map(cat => ({
        id: cat.id,
        nameAr: cat.name_ar,
        nameEn: cat.name_en || '',
        icon: cat.icon,
        color: cat.color,
        description: cat.description || '',
        createdAt: cat.created_at,
        updatedAt: cat.updated_at
      }));

      setCategories(formattedCategories);

      // تحميل الأسئلة
      const { data: questionsData, error: questionsError } = await supabase
        .from('admin_questions')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (questionsError) {
        console.error('❌ خطأ في تحميل الأسئلة:', questionsError);
        throw questionsError;
      }

      // تحويل البيانات لتنسيق التطبيق
      const formattedQuestions: AdminQuestion[] = (questionsData || []).map(q => ({
        id: q.id,
        categoryId: q.category_id,
        question: q.question,
        type: q.type,
        options: Array.isArray(q.options) ? q.options : [],
        correctAnswer: q.correct_answer,
        difficulty: q.difficulty,
        difficultyLevel: q.difficulty_level,
        points: q.points,
        explanation: q.explanation || '',
        notes: q.notes || '',
        tags: Array.isArray(q.tags) ? q.tags : [],
        isActive: q.is_active,
        createdAt: q.created_at,
        updatedAt: q.updated_at
      }));

      setQuestions(formattedQuestions);

      // تحميل النشاطات
      const { data: activityData, error: activityError } = await supabase
        .from('admin_activity')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (activityError) {
        console.error('❌ خطأ في تحميل النشاطات:', activityError);
        throw activityError;
      }

      const formattedActivity: AdminActivity[] = (activityData || []).map(a => ({
        id: a.id,
        type: a.type,
        entity: a.entity,
        entityName: a.entity_name,
        timestamp: a.created_at,
        details: a.details || ''
      }));

      setActivity(formattedActivity);

      console.log('✅ تم تحميل جميع البيانات بنجاح من قاعدة البيانات!', {
        categories: formattedCategories.length,
        questions: formattedQuestions.length,
        activities: formattedActivity.length
      });
    } catch (error) {
      console.error('⚠️ فشل في تحميل البيانات من قاعدة البيانات:', error);
      setIsOnline(false);
    } finally {
      setLoading(false);
    }
  }, []);

  // إضافة نشاط جديد
  const addActivity = useCallback(async (
    type: 'create' | 'update' | 'delete',
    entity: 'category' | 'question',
    entityName: string,
    entityId?: string,
    details?: string
  ) => {
    if (!hasValidSupabaseConfig || !supabase) return;

    try {
      const { error } = await supabase
        .from('admin_activity')
        .insert({
          type,
          entity,
          entity_name: entityName,
          entity_id: entityId,
          details,
          user_info: { timestamp: new Date().toISOString() }
        });

      if (error) throw error;
      console.log('📝 تم تسجيل النشاط:', { type, entity, entityName });
    } catch (error) {
      console.error('خطأ في تسجيل النشاط:', error);
    }
  }, []);

  // إدارة التخصصات
  const createCategory = useCallback(async (categoryData: Omit<Category, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (!hasValidSupabaseConfig || !supabase) {
      console.log('📱 الوضع المحلي نشط - لا يمكن إنشاء تخصص في قاعدة البيانات الأونلاين');
      alert('يتطلب إعداد قاعدة بيانات Supabase أولاً للعمل في الوضع الأونلاين');
      return null;
    }

    try {
      console.log('🆕 جاري إنشاء تخصص جديد في قاعدة البيانات:', categoryData);
      
      const { data, error } = await supabase
        .from('admin_categories')
        .insert({
          name_ar: categoryData.nameAr,
          name_en: categoryData.nameEn,
          icon: categoryData.icon,
          color: categoryData.color,
          description: categoryData.description
        })
        .select()
        .single();

      if (error) {
        console.log('📱 فشل في إنشاء التخصص - قاعدة البيانات تحتاج إعداد');
        
        // معالجة خطأ الجدول غير موجود
        if (error.code === '42P01') {
          alert('خطأ: جداول لوحة التحكم غير موجودة في قاعدة البيانات.\n\n🛠️ الحل:\nقم بتشغيل ملفات إعداد قاعدة البيانات في محرر SQL:\n1️⃣ supabase/migrations/20250726100321_gentle_glade.sql\n2️⃣ supabase/migrations/20250726212911_lively_rain.sql');
          return null;
        }
        
        throw error;
      }
      
      console.log('✅ تم إنشاء التخصص بنجاح في قاعدة البيانات');

      await addActivity('create', 'category', categoryData.nameAr, data.id);
      await loadData(); // إعادة تحميل البيانات

      // إرسال إشعار للمكونات الأخرى
      window.dispatchEvent(new CustomEvent('adminDataChanged'));
      
      alert(`🎉 تم إنشاء التخصص "${categoryData.nameAr}" بنجاح في قاعدة البيانات!`);
      return data;
    } catch (error) {
      console.log('📱 خطأ في إنشاء التخصص - الوضع المحلي مطلوب');
      
      // معالجة أفضل لرسائل الأخطاء
      let errorMessage = 'خطأ غير معروف';
      if (error && typeof error === 'object') {
        if ('message' in error) {
          errorMessage = error.message;
        } else if ('error' in error) {
          errorMessage = error.error;
        } else {
          errorMessage = JSON.stringify(error);
        }
      } else if (typeof error === 'string') {
        errorMessage = error;
      }
      
      // رسائل خطأ مخصصة حسب نوع المشكلة
      if (errorMessage.includes('42P01') || errorMessage.includes('does not exist')) {
        alert('❌ خطأ: جداول لوحة التحكم غير موجودة في قاعدة البيانات.\n\n🛠️ الحل:\n1. اذهب إلى Supabase Dashboard\n2. افتح SQL Editor\n3. شغّل ملفات الإعداد بالترتيب:\n   - supabase/migrations/20250726100321_gentle_glade.sql\n   - supabase/migrations/20250726212911_lively_rain.sql');
      } else if (errorMessage.includes('permission') || errorMessage.includes('denied')) {
        alert('❌ خطأ في الصلاحيات: تأكد من أنك مالك المشروع في Supabase');
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        alert('❌ خطأ في الاتصال: تحقق من اتصال الإنترنت وإعدادات Supabase');
      } else {
        alert(`❌ فشل في إنشاء التخصص: ${errorMessage}`);
      }
      
      throw error;
    }
  }, [addActivity, loadData]);

  const updateCategory = useCallback(async (id: string, updates: Partial<Category>) => {
    if (!hasValidSupabaseConfig || !supabase) return;

    try {
      const { error } = await supabase
        .from('admin_categories')
        .update({
          name_ar: updates.nameAr,
          name_en: updates.nameEn,
          icon: updates.icon,
          color: updates.color,
          description: updates.description
        })
        .eq('id', id);

      if (error) throw error;

      const category = categories.find(c => c.id === id);
      if (category) {
        await addActivity('update', 'category', category.nameAr, id);
      }

      await loadData(); // إعادة تحميل البيانات
      console.log('✅ تم تحديث التخصص بنجاح في قاعدة البيانات:', id);
    } catch (error) {
      console.error('❌ خطأ في تحديث التخصص:', error);
      
      // معالجة محسنة لرسائل الأخطاء
      let errorMessage = 'خطأ غير معروف في تحديث التخصص';
      
      if (error) {
        if (typeof error === 'string') {
          errorMessage = error;
        } else if (typeof error === 'object') {
          // محاولة استخراج رسالة الخطأ من مصادر مختلفة
          if (error.message) {
            errorMessage = error.message;
          } else if (error.error) {
            errorMessage = error.error;
          } else if (error.details) {
            errorMessage = error.details;
          } else if (error.hint) {
            errorMessage = error.hint;
          } else {
            // إذا كان الكائن فارغ أو لا يحتوي على رسالة مفيدة
            const errorKeys = Object.keys(error);
            if (errorKeys.length === 0) {
              errorMessage = 'حدث خطأ غير محدد - قد تكون مشكلة في الاتصال أو الصلاحيات';
            } else {
              errorMessage = `خطأ في النظام - تحقق من Console للتفاصيل (${errorKeys.join(', ')})`;
            }
          }
        }
      }
      
      // رسائل خطأ مخصصة حسب المحتوى
      if (errorMessage.includes('42P01') || errorMessage.includes('does not exist')) {
        errorMessage = 'جداول لوحة التحكم غير موجودة في قاعدة البيانات.\n\n🛠️ الحل:\n1. اذهب إلى https://supabase.com/dashboard\n2. اختر مشروعك → SQL Editor → New Query\n3. انسخ محتوى الملف الأول (20250726100321_gentle_glade.sql) والصقه\n4. اضغط Run لتشغيله\n5. كرر للملف الثاني (20250726212911_lively_rain.sql)\n\n📁 الملفات موجودة في مجلد supabase/migrations/';
      } else if (errorMessage.includes('permission') || errorMessage.includes('denied')) {
        errorMessage = 'خطأ في الصلاحيات: تأكد من أنك مالك المشروع في Supabase';
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        errorMessage = 'خطأ في الاتصال: تحقق من اتصال الإنترنت وإعدادات Supabase';
      }
      
      console.error(`❌ فشل في تحديث التخصص: ${errorMessage}`);
      throw error;
    }
  }, [categories, addActivity, loadData]);

  const deleteCategory = useCallback(async (id: string) => {
    if (!hasValidSupabaseConfig || !supabase) return;

    try {
      const category = categories.find(c => c.id === id);
      
      // حذف الأسئلة المرتبطة أولاً
      await supabase
        .from('admin_questions')
        .delete()
        .eq('category_id', id);

      // حذف التخصص
      const { error } = await supabase
        .from('admin_categories')
        .delete()
        .eq('id', id);

      if (error) throw error;

      if (category) {
        await addActivity('delete', 'category', category.nameAr, id);
      }

      await loadData(); // إعادة تحميل البيانات
      console.log('✅ تم حذف التخصص بنجاح من قاعدة البيانات:', id);
    } catch (error) {
      console.error('❌ خطأ في حذف التخصص:', error);
      
      // معالجة محسنة لرسائل الأخطاء
      let errorMessage = 'خطأ غير معروف في حذف التخصص';
      
      if (error) {
        if (typeof error === 'string') {
          errorMessage = error;
        } else if (typeof error === 'object') {
          // محاولة استخراج رسالة الخطأ من مصادر مختلفة
          if (error.message) {
            errorMessage = error.message;
          } else if (error.error) {
            errorMessage = error.error;
          } else if (error.details) {
            errorMessage = error.details;
          } else if (error.hint) {
            errorMessage = error.hint;
          } else {
            // إذا كان الكائن فارغ أو لا يحتوي على رسالة مفيدة
            const errorKeys = Object.keys(error);
            if (errorKeys.length === 0) {
              errorMessage = 'حدث خطأ غير محدد - قد تكون مشكلة في الاتصال أو الصلاحيات';
            } else {
              errorMessage = `خطأ في النظام - تحقق من Console للتفاصيل (${errorKeys.join(', ')})`;
            }
          }
        }
      }
      
      // رسائل خطأ مخصصة حسب المحتوى
      if (errorMessage.includes('42P01') || errorMessage.includes('does not exist')) {
        errorMessage = 'جداول لوحة التحكم غير موجودة في قاعدة البيانات.\n\n🛠️ الحل:\n1. اذهب إلى https://supabase.com/dashboard\n2. اختر مشروعك → SQL Editor → New Query\n3. انسخ محتوى الملف الأول (20250726100321_gentle_glade.sql) والصقه\n4. اضغط Run لتشغيله\n5. كرر للملف الثاني (20250726212911_lively_rain.sql)\n\n📁 الملفات موجودة في مجلد supabase/migrations/';
      } else if (errorMessage.includes('permission') || errorMessage.includes('denied')) {
        errorMessage = 'خطأ في الصلاحيات: تأكد من أنك مالك المشروع في Supabase';
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        errorMessage = 'خطأ في الاتصال: تحقق من اتصال الإنترنت وإعدادات Supabase';
      }
      
      alert(`❌ فشل في حذف التخصص: ${errorMessage}`);
      throw error;
    }
  }, [categories, addActivity, loadData]);

  // إدارة الأسئلة
  const createQuestion = useCallback(async (questionData: Omit<AdminQuestion, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (!hasValidSupabaseConfig || !supabase) {
      console.log('📱 الوضع المحلي نشط - لا يمكن إنشاء سؤال في قاعدة البيانات الأونلاين');
      alert('يتطلب إعداد قاعدة بيانات Supabase أولاً للعمل في الوضع الأونلاين');
      return null;
    }

    try {
      console.log('🆕 جاري إنشاء سؤال جديد في قاعدة البيانات:', questionData.question.substring(0, 50) + '...');
      
      const { data, error } = await supabase
        .from('admin_questions')
        .insert({
          category_id: questionData.categoryId,
          question: questionData.question,
          type: questionData.type,
          options: questionData.options,
          correct_answer: questionData.correctAnswer,
          difficulty: questionData.difficulty,
          difficulty_level: questionData.difficultyLevel,
          points: questionData.points,
          explanation: questionData.explanation,
          notes: questionData.notes,
          tags: questionData.tags
        })
        .select()
        .single();

      if (error) {
        console.error('❌ فشل في إنشاء السؤال في قاعدة البيانات:', error);
        
        // معالجة خطأ الجدول غير موجود
        if (error.code === '42P01') {
          alert('خطأ: جداول لوحة التحكم غير موجودة في قاعدة البيانات.\n\n🛠️ يرجى تشغيل ملفات إعداد قاعدة البيانات أولاً.');
          return null;
        }
        
        throw error;
      }
      
      console.log('✅ تم إنشاء السؤال بنجاح في قاعدة البيانات:', data);

      await addActivity('create', 'question', questionData.question.substring(0, 50) + '...', data.id);
      await loadData(); // إعادة تحميل البيانات

      alert('🎉 تم إنشاء السؤال بنجاح في قاعدة البيانات!');
      return data;
    } catch (error) {
      console.error('❌ خطأ في إنشاء السؤال:', error);
      
      // معالجة محسنة لرسائل الأخطاء
      let errorMessage = 'خطأ غير معروف في إنشاء السؤال';
      
      if (error) {
        if (typeof error === 'string') {
          errorMessage = error;
        } else if (typeof error === 'object') {
          // محاولة استخراج رسالة الخطأ من مصادر مختلفة
          if (error.message) {
            errorMessage = error.message;
          } else if (error.error) {
            errorMessage = error.error;
          } else if (error.details) {
            errorMessage = error.details;
          } else if (error.hint) {
            errorMessage = error.hint;
          } else {
            // إذا كان الكائن فارغ أو لا يحتوي على رسالة مفيدة
            const errorKeys = Object.keys(error);
            if (errorKeys.length === 0) {
              errorMessage = 'حدث خطأ غير محدد - قد تكون مشكلة في الاتصال أو الصلاحيات';
            } else {
              errorMessage = `خطأ في النظام - تحقق من Console للتفاصيل (${errorKeys.join(', ')})`;
            }
          }
        }
      }
      
      // رسائل خطأ مخصصة حسب المحتوى
      if (errorMessage.includes('42P01') || errorMessage.includes('does not exist')) {
        errorMessage = 'جداول لوحة التحكم غير موجودة في قاعدة البيانات.\n\n🛠️ الحل:\n1. اذهب إلى https://supabase.com/dashboard\n2. اختر مشروعك → SQL Editor → New Query\n3. انسخ محتوى الملف الأول (20250726100321_gentle_glade.sql) والصقه\n4. اضغط Run لتشغيله\n5. كرر للملف الثاني (20250726212911_lively_rain.sql)\n\n📁 الملفات موجودة في مجلد supabase/migrations/';
      } else if (errorMessage.includes('permission') || errorMessage.includes('denied')) {
        errorMessage = 'خطأ في الصلاحيات: تأكد من أنك مالك المشروع في Supabase';
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        errorMessage = 'خطأ في الاتصال: تحقق من اتصال الإنترنت وإعدادات Supabase';
      }
      
      alert(`❌ فشل في إنشاء السؤال: ${errorMessage}`);
      throw error;
    }
  }, [addActivity, loadData]);

  const updateQuestion = useCallback(async (id: string, updates: Partial<AdminQuestion>) => {
    if (!hasValidSupabaseConfig || !supabase) return;

    try {
      const { error } = await supabase
        .from('admin_questions')
        .update({
          category_id: updates.categoryId,
          question: updates.question,
          type: updates.type,
          options: updates.options,
          correct_answer: updates.correctAnswer,
          difficulty: updates.difficulty,
          difficulty_level: updates.difficultyLevel,
          points: updates.points,
          explanation: updates.explanation,
          notes: updates.notes,
          tags: updates.tags,
          is_active: updates.isActive
        })
        .eq('id', id);

      if (error) throw error;

      const question = questions.find(q => q.id === id);
      if (question) {
        await addActivity('update', 'question', question.question.substring(0, 50) + '...', id);
      }

      await loadData(); // إعادة تحميل البيانات
      console.log('✅ تم تحديث السؤال بنجاح في قاعدة البيانات:', id);
    } catch (error) {
      console.error('❌ خطأ في تحديث السؤال:', error);
      throw error;
    }
  }, [questions, addActivity, loadData]);

  const deleteQuestion = useCallback(async (id: string) => {
    if (!hasValidSupabaseConfig || !supabase) return;

    try {
      const question = questions.find(q => q.id === id);

      const { error } = await supabase
        .from('admin_questions')
        .delete()
        .eq('id', id);

      if (error) throw error;

      if (question) {
        await addActivity('delete', 'question', question.question.substring(0, 50) + '...', id);
      }

      await loadData(); // إعادة تحميل البيانات
      console.log('✅ تم حذف السؤال بنجاح من قاعدة البيانات:', id);
    } catch (error) {
      console.error('❌ خطأ في حذف السؤال:', error);
      throw error;
    }
  }, [questions, addActivity, loadData]);

  // فلترة الأسئلة
  const getFilteredQuestions = useCallback((filters: AdminFilters) => {
    return questions.filter(question => {
      if (filters.categoryId && question.categoryId !== filters.categoryId) return false;
      if (filters.difficulty && question.difficulty !== filters.difficulty) return false;
      if (filters.isActive !== undefined && question.isActive !== filters.isActive) return false;
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase();
        if (!question.question.toLowerCase().includes(query) &&
            !question.options.some(opt => opt.toLowerCase().includes(query))) {
          return false;
        }
      }
      if (filters.tags && filters.tags.length > 0) {
        if (!filters.tags.some(tag => question.tags.includes(tag))) return false;
      }
      return true;
    });
  }, [questions]);

  // إحصائيات
  const getStats = useCallback((): AdminStats => {
    const questionsByDifficulty = questions.reduce((acc, q) => {
      acc[q.difficulty]++;
      return acc;
    }, { easy: 0, medium: 0, hard: 0 });

    const questionsByCategory = questions.reduce((acc, q) => {
      const category = categories.find(c => c.id === q.categoryId);
      if (category) {
        acc[category.nameAr] = (acc[category.nameAr] || 0) + 1;
      }
      return acc;
    }, {} as Record<string, number>);

    return {
      totalCategories: categories.length,
      totalQuestions: questions.length,
      questionsByDifficulty,
      questionsByCategory,
      recentActivity: activity.slice(0, 10)
    };
  }, [categories, questions, activity]);

  // إعداد الاشتراكات المباشرة
  useEffect(() => {
    if (!hasValidSupabaseConfig || !supabase) return;

    console.log('🔄 إعداد الاشتراكات المباشرة...');

    const categoriesSubscription = supabase
      .channel('admin-categories-changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'admin_categories'
      }, (payload) => {
        console.log('🔄 تحديث التخصصات:', payload);
        loadData();
      })
      .subscribe();

    const questionsSubscription = supabase
      .channel('admin-questions-changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'admin_questions'
      }, (payload) => {
        console.log('🔄 تحديث الأسئلة:', payload);
        loadData();
      })
      .subscribe();

    const activitySubscription = supabase
      .channel('admin-activity-changes')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'admin_activity'
      }, (payload) => {
        console.log('🔄 نشاط جديد:', payload);
        loadData();
      })
      .subscribe();

    return () => {
      categoriesSubscription.unsubscribe();
      questionsSubscription.unsubscribe();
      activitySubscription.unsubscribe();
    };
  }, [loadData]);

  // إدراج البيانات الافتراضية إذا لم تكن موجودة
  const insertDefaultData = useCallback(async () => {
    if (!hasValidSupabaseConfig || !supabase) return;

    try {
      console.log('📝 بدء فحص وإدراج البيانات الافتراضية...');

      // فحص إذا كانت الجداول موجودة أولاً
      const { data: tableCheck, error: tableError } = await supabase
        .from('admin_categories')
        .select('id')
        .limit(1);

      if (tableError) {
        if (tableError.code === '42P01') {
          console.log('❌ جداول لوحة التحكم غير موجودة في قاعدة البيانات - يرجى تشغيل ملفات الإعداد أولاً');
          return;
        }
        console.error('❌ خطأ في فحص وجود الجداول:', tableError);
        return;
      }

      console.log('✅ جداول لوحة التحكم موجودة، جاري فحص الأسئلة الموجودة...');

      // فحص إذا كانت هناك أسئلة موجودة
      const { data: existingQuestions, error: questionsCheckError } = await supabase
        .from('admin_questions')
        .select('id')
        .limit(1);

      if (questionsCheckError) {
        console.error('❌ خطأ في فحص الأسئلة الموجودة:', questionsCheckError);
        return;
      }

      if (existingQuestions && existingQuestions.length > 0) {
        console.log('✅ توجد أسئلة مسبقاً في قاعدة البيانات - تخطي إدراج البيانات الافتراضية');
        return;
      }

      console.log('📝 قاعدة البيانات فارغة من الأسئلة - بدء إدراج البيانات الافتراضية...');

      // جلب التخصصات الموجودة
      const { data: existingCategories, error: categoriesError } = await supabase
        .from('admin_categories')
        .select('*');

      if (categoriesError) {
        console.error('❌ خطأ في جلب التخصصات من قاعدة البيانات:', categoriesError);
        return;
      }

      if (!existingCategories || existingCategories.length === 0) {
        console.log('❌ لا توجد تخصصات في قاعدة البيانات - يرجى تشغيل ملفات إعداد قاعدة البيانات أولاً');
        return;
      }

      console.log(`📊 تم العثور على ${existingCategories.length} تخصص موجود في قاعدة البيانات`);

      // إدراج الأسئلة الافتراضية
      const { categoryQuestions } = await import('../data/questions');
      let insertedQuestionsCount = 0;
      let totalQuestionsToInsert = 0;

      // حساب إجمالي الأسئلة أولاً
      for (const categoryData of categoryQuestions) {
        const matchingCategory = existingCategories.find(cat => cat.name_ar === categoryData.category);
        if (matchingCategory) {
          totalQuestionsToInsert += 
            categoryData.difficulties.easy.length +
            categoryData.difficulties.medium.length +
            categoryData.difficulties.hard.length;
        }
      }

      console.log(`🎯 سيتم إدراج ${totalQuestionsToInsert} سؤال افتراضي من ${categoryQuestions.length} تخصص مختلف`);

      for (const categoryData of categoryQuestions) {
        // البحث عن التخصص المطابق
        const matchingCategory = existingCategories.find(cat => cat.name_ar === categoryData.category);
        
        if (!matchingCategory) {
          console.warn(`⚠️ تخطي تخصص "${categoryData.category}" - غير موجود في قاعدة البيانات`);
          continue;
        }

        console.log(`📝 جاري إدراج أسئلة تخصص "${categoryData.category}"...`);

        // إدراج أسئلة كل مستوى صعوبة
        for (const [difficulty, questions] of Object.entries(categoryData.difficulties)) {
          console.log(`  📝 إدراج ${questions.length} سؤال من مستوى الصعوبة "${difficulty}"...`);
          
          for (const question of questions) {
            try {
              const { error: insertError } = await supabase
                .from('admin_questions')
                .insert({
                  category_id: matchingCategory.id,
                  question: question.question,
                  type: 'multiple_choice',
                  options: question.options,
                  correct_answer: question.correctAnswer,
                  difficulty: difficulty,
                  difficulty_level: difficulty === 'easy' ? 1 : difficulty === 'medium' ? 3 : 5,
                  points: question.points,
                  explanation: '',
                  notes: `سؤال افتراضي من تخصص ${categoryData.category}`,
                  tags: [categoryData.category, difficulty, 'افتراضي'],
                  is_active: true
                });

              if (insertError) {
                console.error(`❌ فشل في إدراج السؤال "${question.question.substring(0, 50)}...":`, insertError);
              } else {
                insertedQuestionsCount++;
                if (insertedQuestionsCount % 10 === 0) {
                  console.log(`  ✅ تقدم الإدراج: ${insertedQuestionsCount}/${totalQuestionsToInsert} سؤال...`);
                }
              }
            } catch (error) {
              console.error(`❌ خطأ في معالجة السؤال "${question.question.substring(0, 50)}...":`, error);
            }
          }
        }
      }

      console.log(`🎉 اكتمل الإدراج! تم إدراج ${insertedQuestionsCount} سؤال افتراضي من أصل ${totalQuestionsToInsert} في قاعدة البيانات`);

      if (insertedQuestionsCount === 0) {
        console.warn('⚠️ لم يتم إدراج أي أسئلة - يرجى التحقق من وجود التخصصات في قاعدة البيانات');
        return;
      }

      // تسجيل النشاط
      await addActivity('create', 'question', `تم إدراج ${insertedQuestionsCount} سؤال افتراضي`, undefined, 'إدراج تلقائي للبيانات الافتراضية عند بدء التشغيل');

      // إعادة تحميل البيانات
      console.log('🔄 جاري إعادة تحميل البيانات بعد اكتمال الإدراج...');
      await loadData();

    } catch (error) {
      console.error('❌ خطأ عام في عملية إدراج البيانات الافتراضية:', error);
    }
  }, [addActivity, loadData]);
  useEffect(() => {
    loadData();
  }, [loadData]);

  // تشغيل إدراج البيانات الافتراضية عند التحميل الأول أو عند فتح لوحة التحكم
  useEffect(() => {
    // تشغيل الإدراج في الحالات التالية:
    // 1. الوضع الأونلاين مفعل
    // 2. تم تحميل التخصصات (أكثر من 0)
    // 3. لا توجد أسئلة (0 أسئلة)
    // 4. انتهى التحميل
    if (isOnline && !loading && categories.length > 0 && questions.length === 0) {
      console.log('🚀 شروط الإدراج محققة - بدء إدراج البيانات الافتراضية...');
      console.log(`📊 الحالة: تخصصات=${categories.length}, أسئلة=${questions.length}, تحميل=${loading}`);
      
      // تأخير قصير للتأكد من استقرار البيانات
      const timer = setTimeout(() => {
        insertDefaultData();
      }, 1000);
      
      return () => clearTimeout(timer);
    } else {
      console.log('⏳ شروط الإدراج غير محققة:', {
        isOnline,
        loading,
        categoriesCount: categories.length,
        questionsCount: questions.length
      });
    }
  }, [isOnline, loading, categories.length, questions.length, insertDefaultData]);

  // إضافة زر يدوي لإدراج البيانات (للاختبار)
  const manualInsertData = useCallback(async () => {
    console.log('🔧 إدراج يدوي للبيانات...');
    await insertDefaultData();
  }, [insertDefaultData]);
  return {
    // البيانات
    categories,
    questions,
    activity,
    loading,
    isOnline,
    tablesCreated,
    
    // العمليات
    createCategory,
    updateCategory,
    deleteCategory,
    createQuestion,
    updateQuestion,
    deleteQuestion,
    
    // المساعدات
    getFilteredQuestions,
    getStats,
    
    // إعادة التحميل
    reload: loadData,
    manualInsertData
  };
};