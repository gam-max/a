import { useState, useEffect } from 'react';
import { CategoryQuestion } from '../types/game';
import { categoryQuestions as defaultCategories } from '../data/questions';
import { useAdminData } from './useAdminData';
import { useOnlineAdminData } from './useOnlineAdminData';
import { hasValidSupabaseConfig } from '../lib/supabase';

export const useGameCategories = (forceOnline: boolean = false) => {
  const [categories, setCategories] = useState<CategoryQuestion[]>(defaultCategories);
  const [lastUpdate, setLastUpdate] = useState(Date.now());
  
  // تحديد نوع البيانات حسب الحالة
  const shouldUseOnline = forceOnline || (hasValidSupabaseConfig && window.location.pathname.includes('online'));
  
  const localAdminData = useAdminData();
  const onlineAdminData = useOnlineAdminData();
  
  // اختيار مصدر البيانات المناسب
  const { categories: adminCategories, questions: adminQuestions, isOnline } = shouldUseOnline 
    ? onlineAdminData 
    : { ...localAdminData, isOnline: false };

  // مراقبة التغييرات في البيانات المحلية
  useEffect(() => {
    const handleStorageChange = () => {
      console.log('🔄 تم اكتشاف تغيير في البيانات المحلية - إعادة تحميل التخصصات');
      setLastUpdate(Date.now());
    };

    window.addEventListener('adminDataChanged', handleStorageChange);
    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('adminDataChanged', handleStorageChange);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);
  useEffect(() => {
    console.log('🎮 تحديث فئات اللعبة...', {
      shouldUseOnline,
      isOnline,
      adminCategoriesCount: adminCategories.length,
      adminQuestionsCount: adminQuestions.length,
      lastUpdate
    });
    
    // دمج التخصصات الافتراضية مع التخصصات المضافة من لوحة التحكم
    const mergedCategories: CategoryQuestion[] = [];

    // إضافة التخصصات الافتراضية
    mergedCategories.push(...defaultCategories);

    // إضافة التخصصات الجديدة من لوحة التحكم
    adminCategories.forEach(adminCategory => {
      // التحقق من عدم وجود التخصص مسبقاً
      const existingCategory = mergedCategories.find(cat => cat.category === adminCategory.nameAr);
      
      if (!existingCategory) {
        // جلب الأسئلة المرتبطة بهذا التخصص
        const categoryQuestions = adminQuestions.filter(q => q.categoryId === adminCategory.id && q.isActive);
        
        // تنظيم الأسئلة حسب الصعوبة
        const easyQuestions = categoryQuestions
          .filter(q => q.difficulty === 'easy')
          .map(q => ({
            id: parseInt(q.id.replace('q_', '')) || Math.random(),
            question: q.question,
            options: q.options,
            correctAnswer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
            category: adminCategory.nameAr,
            difficulty: 'easy' as const,
            points: q.points
          }));

        const mediumQuestions = categoryQuestions
          .filter(q => q.difficulty === 'medium')
          .map(q => ({
            id: parseInt(q.id.replace('q_', '')) || Math.random(),
            question: q.question,
            options: q.options,
            correctAnswer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
            category: adminCategory.nameAr,
            difficulty: 'medium' as const,
            points: q.points
          }));

        const hardQuestions = categoryQuestions
          .filter(q => q.difficulty === 'hard')
          .map(q => ({
            id: parseInt(q.id.replace('q_', '')) || Math.random(),
            question: q.question,
            options: q.options,
            correctAnswer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
            category: adminCategory.nameAr,
            difficulty: 'hard' as const,
            points: q.points
          }));

        // إضافة التخصص فقط إذا كان يحتوي على أسئلة
        // إضافة التخصص حتى لو لم يحتوي على أسئلة (للسماح بظهوره في القائمة)
        mergedCategories.push({
          category: adminCategory.nameAr,
          icon: adminCategory.icon,
          difficulties: {
            easy: easyQuestions,
            medium: mediumQuestions,
            hard: hardQuestions
          }
        });
        
        console.log(`✅ تم إضافة تخصص جديد: ${adminCategory.nameAr}`, {
          easyCount: easyQuestions.length,
          mediumCount: mediumQuestions.length,
          hardCount: hardQuestions.length,
          totalQuestions: easyQuestions.length + mediumQuestions.length + hardQuestions.length
        });
      } else {
        // إذا كان التخصص موجود، أضف الأسئلة الجديدة إليه
        const categoryQuestions = adminQuestions.filter(q => q.categoryId === adminCategory.id && q.isActive);
        
        categoryQuestions.forEach(q => {
          const gameQuestion = {
            id: parseInt(q.id.replace('q_', '')) || Math.random(),
            question: q.question,
            options: q.options,
            correctAnswer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
            category: adminCategory.nameAr,
            difficulty: q.difficulty as 'easy' | 'medium' | 'hard',
            points: q.points
          };

          // تجنب إضافة أسئلة مكررة
          const existingQuestions = existingCategory.difficulties[q.difficulty];
          const isDuplicate = existingQuestions.some(existing => existing.question === q.question);
          
          if (!isDuplicate) {
            existingQuestions.push(gameQuestion);
          }
        });
      }
    });

    setCategories(mergedCategories);
    
    console.log('✅ تم دمج الفئات:', {
      totalCategories: mergedCategories.length,
      defaultCategories: defaultCategories.length,
      adminCategories: adminCategories.length,
      isOnline,
      newCategoriesAdded: mergedCategories.length - defaultCategories.length
    });
  }, [adminCategories, adminQuestions, shouldUseOnline, isOnline, lastUpdate]);

  return categories;
};