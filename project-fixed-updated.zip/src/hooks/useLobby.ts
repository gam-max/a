import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase, hasValidSupabaseConfig } from '../lib/supabase';
import { GameRoom, GamePlayer, LobbyState } from '../types/lobby';
import { v4 as uuidv4 } from 'uuid';

export const useLobby = () => {
  // الحصول على المستخدم الحالي، إذا كان مسجلاً
  const { user } = useAuth();
  const [lobbyState, setLobbyState] = useState<LobbyState>({
    mode: 'menu',
    currentRoom: null,
    // إذا كان هناك مستخدم مصادق عليه استخدم معرّف المستخدم، وإلا فمولّد UUID
    playerId: user?.id ?? uuidv4(),
    // استخدام اسم المستخدم أو البريد الإلكتروني للمستخدم المصادق عليه، إذا كان موجوداً
    playerName: user?.email ?? '',
    rooms: [],
    players: [],
    gameState: null
  });

  // تحديث playerId و playerName عند تغيّر المستخدم
  useEffect(() => {
    setLobbyState(prev => ({
      ...prev,
      playerId: user?.id ?? prev.playerId,
      playerName: user?.email ?? prev.playerName
    }));
  }, [user]);

  // Load rooms
  const loadRooms = useCallback(async () => {
    if (!hasValidSupabaseConfig || !supabase) return;
    
    try {
      console.log('📋 تحميل قائمة الغرف...');
      // جلب الغرف النشطة فقط
      const { data: roomsData, error: roomsError } = await supabase
        .from('game_rooms')
        .select('*')
        .eq('status', 'waiting')
        .order('created_at', { ascending: false });

      if (roomsError) throw roomsError;
      console.log('📋 تم جلب الغرف:', roomsData?.length || 0, 'غرفة');
      
      // تنظيف الغرف الفارغة وتحديث عدد اللاعبين
      const roomsWithPlayerCount = await Promise.all(
        (roomsData || []).map(async (room) => {
          const { data: playersData, error: playersError } = await supabase
            .from('game_players')
            .select('id')
            .eq('room_id', room.id);
          
          if (playersError) {
            console.error('Error counting players:', playersError);
            return room;
          }
          
          const actualPlayerCount = playersData?.length || 0;
          
          // إذا كانت الغرفة فارغة، احذفها
          if (actualPlayerCount === 0) {
            console.log(`🧹 تنظيف الغرفة الفارغة: ${room.name}`);
            
            // حذف حالة اللعبة إن وجدت
            await supabase
              .from('game_state')
              .delete()
              .eq('room_id', room.id);
            
            // حذف الغرفة
            await supabase
              .from('game_rooms')
              .delete()
              .eq('id', room.id);
            
            return null; // إشارة لحذف هذه الغرفة من القائمة
          }
          
          // تحديث عدد اللاعبين في قاعدة البيانات إذا كان مختلفاً
          if (actualPlayerCount !== room.current_players) {
            console.log(`🔄 تحديث عدد اللاعبين في ${room.name}: ${room.current_players} → ${actualPlayerCount}`);
            await supabase
              .from('game_rooms')
              .update({ current_players: actualPlayerCount })
              .eq('id', room.id);
          }
          
          return {
            ...room,
            current_players: actualPlayerCount
          };
        })
      );
      
      // تصفية الغرف المحذوفة (null values)
      const validRooms = roomsWithPlayerCount.filter(room => room !== null);
      setLobbyState(prev => ({ ...prev, rooms: validRooms }));
      
      console.log(`📊 تم تحميل ${validRooms.length} غرفة صالحة`);
    } catch (error) {
      console.error('Error loading rooms:', error);
    }
  }, []);

  // Load players for current room
  const loadPlayers = useCallback(async (roomId: string) => {
    if (!hasValidSupabaseConfig || !supabase) return;
    
    console.log('👥 تحميل اللاعبين للغرفة:', roomId);
    
    try {
      const { data, error } = await supabase
        .from('game_players')
        .select('*')
        .eq('room_id', roomId)
        .order('joined_at', { ascending: true });

      if (error) {
        console.error('❌ خطأ في تحميل اللاعبين:', error);
        throw error;
      }
      
      console.log('✅ تم تحميل اللاعبين:', data?.length || 0, 'لاعب');
      setLobbyState(prev => ({ ...prev, players: data || [] }));
    } catch (error) {
      console.error('Error loading players:', error);
      // في حالة الخطأ، تأكد من عدم ترك الحالة فارغة
      setLobbyState(prev => ({ ...prev, players: [] }));
    }
  }, []);

  // Set player name
  const setPlayerName = useCallback((name: string) => {
    setLobbyState(prev => ({ ...prev, playerName: name }));
  }, []);

  // Create room
  const createRoom = useCallback(async (roomName: string) => {
    if (!hasValidSupabaseConfig || !supabase) {
      alert('يتطلب إعداد Supabase أولاً');
      return;
    }
    
    console.log('🏠 بدء إنشاء غرفة جديدة...', { 
      roomName, 
      playerId: lobbyState.playerId, 
      playerName: lobbyState.playerName,
      hasValidConfig: hasValidSupabaseConfig,
      supabaseExists: !!supabase
    });
    
    // التحقق من صحة البيانات
    if (!lobbyState.playerName || !lobbyState.playerId) {
      console.error('❌ بيانات اللاعب غير صحيحة:', { 
        playerName: lobbyState.playerName, 
        playerId: lobbyState.playerId 
      });
      alert('خطأ: بيانات اللاعب غير صحيحة');
      return;
    }
    
    try {
      // تنظيف الغرف الفارغة أولاً
      console.log('🧹 تنظيف الغرف الفارغة...');
      await cleanupEmptyRooms();
      
      const roomId = uuidv4();
      console.log('🆔 معرف الغرفة الجديد:', roomId);
      
      // Create room
      console.log('📝 إنشاء الغرفة في قاعدة البيانات...');
      const { error: roomError } = await supabase
        .from('game_rooms')
        .insert({
          id: roomId,
          name: roomName,
          host_id: lobbyState.playerId,
          host_name: lobbyState.playerName,
          status: 'waiting',
          max_players: 10,
          current_players: 1
        });

      if (roomError) {
        console.error('❌ خطأ في إنشاء الغرفة:', roomError);
        throw roomError;
      }
      console.log('✅ تم إنشاء الغرفة بنجاح');

      // Join room as host
      console.log('👤 انضمام المضيف للغرفة...');
      const { error: playerError } = await supabase
        .from('game_players')
        .insert({
          room_id: roomId,
          player_id: lobbyState.playerId,
          player_name: lobbyState.playerName,
          // ربط اللاعب بالمستخدم إذا كان متوفراً
          user_id: user?.id || null,
          team: null,
          is_ready: false
        });

      if (playerError) {
        console.error('❌ خطأ في انضمام المضيف:', playerError);
        throw playerError;
      }
      console.log('✅ تم انضمام المضيف للغرفة');

      // Get room data
      console.log('📊 جلب بيانات الغرفة...');
      const { data: roomData, error: getRoomError } = await supabase
        .from('game_rooms')
        .select('*')
        .eq('id', roomId)
        .single();

      if (getRoomError) {
        console.error('❌ خطأ في جلب بيانات الغرفة:', getRoomError);
        throw getRoomError;
      }
      
      if (!roomData) {
        console.error('❌ لم يتم العثور على بيانات الغرفة');
        throw new Error('فشل في جلب بيانات الغرفة');
      }
      
      console.log('✅ تم جلب بيانات الغرفة:', roomData);

      // انتظار قصير للتأكد من حفظ البيانات
      console.log('⏳ انتظار تأكيد حفظ البيانات...');
      await new Promise(resolve => setTimeout(resolve, 500));

      console.log('🔄 تحديث حالة اللوبي...');
      setLobbyState(prev => ({
        ...prev,
        mode: 'room',
        currentRoom: roomData
      }));
      console.log('✅ تم تحديث حالة اللوبي للانتقال للغرفة');

      console.log('👥 تحميل قائمة اللاعبين...');
      // انتظار إضافي للتأكد من استقرار البيانات
      await new Promise(resolve => setTimeout(resolve, 1000));
      try {
        await loadPlayers(roomId);
      } catch (playerError) {
        console.error('❌ خطأ في تحميل اللاعبين:', playerError);
        // المحاولة مرة أخرى
        setTimeout(() => loadPlayers(roomId), 2000);
      }
      console.log('🎉 تم إنشاء الغرفة والانضمام إليها بنجاح!');
    } catch (error) {
      console.error('Error creating room:', error);
      
      // رسالة خطأ مفصلة
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error('❌ تفاصيل الخطأ الكاملة:', {
        error,
        message: errorMessage,
        stack: error instanceof Error ? error.stack : undefined,
        lobbyState: {
          playerId: lobbyState.playerId,
          playerName: lobbyState.playerName,
          mode: lobbyState.mode
        }
      });
      
      alert(`خطأ في إنشاء الغرفة: ${errorMessage}\n\nراجع Console (F12) للمزيد من التفاصيل`);
      
      // إعادة تعيين الحالة في حالة الخطأ
      setLobbyState(prev => ({
        ...prev,
        mode: 'menu',
        currentRoom: null
      }));
    }
  }, [lobbyState.playerId, lobbyState.playerName, loadPlayers]);

  // Join room
  const joinRoom = useCallback(async (roomId: string) => {
    if (!hasValidSupabaseConfig || !supabase) {
      alert('يتطلب إعداد Supabase أولاً');
      return;
    }
    
    try {
      console.log('🚪 محاولة الانضمام للغرفة...', { roomId, playerId: lobbyState.playerId, playerName: lobbyState.playerName });
      
      // Check if room exists and is available
      const { data: roomData, error: roomError } = await supabase
        .from('game_rooms')
        .select('*')
        .eq('id', roomId)
        .eq('status', 'waiting')
        .single();

      if (roomError) throw roomError;
      if (!roomData) throw new Error('Room not found');
      console.log('✅ تم العثور على الغرفة:', roomData);

      // Check if player already in room
      const { data: existingPlayer, error: playerCheckError } = await supabase
        .from('game_players')
        .select('*')
        .eq('room_id', roomId)
        .eq('player_id', lobbyState.playerId)
        .maybeSingle();

      // Handle the case where no player is found (PGRST116 error is expected)
      if (playerCheckError && playerCheckError.code !== 'PGRST116') {
        throw playerCheckError;
      }
      
      const playerExists = existingPlayer !== null;
      
      if (!playerExists) {
        console.log('👤 اللاعب غير موجود في الغرفة، جاري الانضمام...');
        
        // احصل على العدد الفعلي للاعبين
        const { data: currentPlayers } = await supabase
          .from('game_players')
          .select('id')
          .eq('room_id', roomId);
        
        const actualPlayerCount = currentPlayers?.length || 0;
        console.log('📊 عدد اللاعبين الحالي:', actualPlayerCount);
        
        // Join room
        const { error: playerError } = await supabase
          .from('game_players')
          .insert({
            room_id: roomId,
            player_id: lobbyState.playerId,
            player_name: lobbyState.playerName,
            // ربط اللاعب بالمستخدم إذا كان متوفراً
            user_id: user?.id || null,
            team: null,
            is_ready: false
          });

        if (playerError) throw playerError;
        console.log('✅ تم انضمام اللاعب للغرفة');

        // Update room player count
        const { error: updateError } = await supabase
          .from('game_rooms')
          .update({ current_players: actualPlayerCount + 1 })
          .eq('id', roomId);

        if (updateError) throw updateError;
        console.log('✅ تم تحديث عدد اللاعبين في الغرفة');
      } else {
        console.log('👤 اللاعب موجود بالفعل في الغرفة');
      }

      // انتظار قصير للتأكد من حفظ البيانات
      await new Promise(resolve => setTimeout(resolve, 500));

      setLobbyState(prev => ({
        ...prev,
        mode: 'room',
        currentRoom: roomData
      }));
      console.log('✅ تم تحديث حالة اللوبي للانتقال للغرفة');

      await loadPlayers(roomId);
      console.log('🎉 تم الانضمام للغرفة بنجاح!');
    } catch (error) {
      console.error('Error joining room:', error);
      alert(`خطأ في الانضمام للغرفة: ${error.message || error}`);
    }
  }, [lobbyState.playerId, lobbyState.playerName, loadPlayers]);

  // دالة تنظيف الغرف الفارغة
  const cleanupEmptyRooms = useCallback(async () => {
    if (!hasValidSupabaseConfig || !supabase) return;
    
    try {
      // جلب جميع الغرف
      const { data: allRooms, error: roomsError } = await supabase
        .from('game_rooms')
        .select('*');
      
      if (roomsError) throw roomsError;
      
      // فحص كل غرفة
      for (const room of allRooms || []) {
        const { data: players, error: playersError } = await supabase
          .from('game_players')
          .select('id')
          .eq('room_id', room.id);
        
        if (playersError) continue;
        
        // إذا كانت الغرفة فارغة، احذفها
        if (!players || players.length === 0) {
          console.log(`🧹 حذف الغرفة الفارغة: ${room.name}`);
          
          // حذف حالة اللعبة
          await supabase
            .from('game_state')
            .delete()
            .eq('room_id', room.id);
          
          // حذف الغرفة
          await supabase
            .from('game_rooms')
            .delete()
            .eq('id', room.id);
        }
      }
    } catch (error) {
      console.error('Error cleaning up empty rooms:', error);
    }
  }, []);

  // Leave room
  const leaveRoom = useCallback(async () => {
    if (!lobbyState.currentRoom) return;
    if (!hasValidSupabaseConfig || !supabase) return;

    try {
      const isHost = lobbyState.currentRoom.host_id === lobbyState.playerId;
      
      // Remove player from room
      const { error: playerError } = await supabase
        .from('game_players')
        .delete()
        .eq('room_id', lobbyState.currentRoom.id)
        .eq('player_id', lobbyState.playerId);

      if (playerError) throw playerError;

      // Update room player count or delete if empty
      const { data: remainingPlayers } = await supabase
        .from('game_players')
        .select('*')
        .eq('room_id', lobbyState.currentRoom.id);

      if (!remainingPlayers || remainingPlayers.length === 0 || isHost) {
        // Delete room if empty OR if host left
        // First delete game state if exists
        await supabase
          .from('game_state')
          .delete()
          .eq('room_id', lobbyState.currentRoom.id);
          
        // Then delete all remaining players
        await supabase
          .from('game_players')
          .delete()
          .eq('room_id', lobbyState.currentRoom.id);
          
        // Finally delete the room
        await supabase
          .from('game_rooms')
          .delete()
          .eq('id', lobbyState.currentRoom.id);
      } else {
        // Update player count
        await supabase
          .from('game_rooms')
          .update({ current_players: remainingPlayers.length })
          .eq('id', lobbyState.currentRoom.id);
        
        // إشعار تحديث الغرف
        await loadRooms();

      }

      setLobbyState(prev => ({
        ...prev,
        mode: 'menu',
        currentRoom: null,
        players: []
      }));

      await loadRooms();
    } catch (error) {
      console.error('Error leaving room:', error);
    }
  }, [lobbyState.currentRoom, lobbyState.playerId, loadRooms]);

  // Toggle ready status
  const toggleReady = useCallback(async () => {
    if (!lobbyState.currentRoom) return;
    if (!hasValidSupabaseConfig || !supabase) return;

    const currentPlayer = lobbyState.players.find(p => p.player_id === lobbyState.playerId);
    if (!currentPlayer) return;

    try {
      const { error } = await supabase
        .from('game_players')
        .update({ is_ready: !currentPlayer.is_ready })
        .eq('id', currentPlayer.id);

      if (error) throw error;

      await loadPlayers(lobbyState.currentRoom.id);
    } catch (error) {
      console.error('Error toggling ready:', error);
    }
  }, [lobbyState.currentRoom, lobbyState.players, lobbyState.playerId, loadPlayers]);

  // Switch team
  const switchTeam = useCallback(async (team: 'red' | 'blue') => {
    if (!lobbyState.currentRoom) return;
    if (!hasValidSupabaseConfig || !supabase) return;

    const currentPlayer = lobbyState.players.find(p => p.player_id === lobbyState.playerId);
    if (!currentPlayer) return;

    try {
      const { error } = await supabase
        .from('game_players')
        .update({ team, is_ready: false })
        .eq('id', currentPlayer.id);

      if (error) throw error;

      await loadPlayers(lobbyState.currentRoom.id);
    } catch (error) {
      console.error('Error switching team:', error);
    }
  }, [lobbyState.currentRoom, lobbyState.players, lobbyState.playerId, loadPlayers]);

  // Start game
  const startGame = useCallback(async () => {
    if (!lobbyState.currentRoom) return;
    if (!hasValidSupabaseConfig || !supabase) return;
    
    // التحقق من أن المستخدم هو المضيف
    const isHost = lobbyState.currentRoom.host_id === lobbyState.playerId;
    if (!isHost) {
      console.log('فقط المضيف يمكنه بدء اللعبة');
      return;
    }
    
    // التحقق من وجود لاعبين في كلا الفريقين
    const redTeamPlayers = lobbyState.players.filter(p => p.team === 'red');
    const blueTeamPlayers = lobbyState.players.filter(p => p.team === 'blue');
    const hasMinimumPlayers = lobbyState.players.length >= 2;
    const hasPlayersInBothTeams = redTeamPlayers.length > 0 && blueTeamPlayers.length > 0;
    const noUnassignedPlayers = lobbyState.players.filter(p => p.team === null).length === 0;
    
    if (!hasMinimumPlayers || !hasPlayersInBothTeams || !noUnassignedPlayers) {
      let errorMessage = 'لا يمكن بدء اللعبة:\n';
      if (!hasMinimumPlayers) errorMessage += '• يجب وجود لاعبين على الأقل\n';
      if (!hasPlayersInBothTeams) errorMessage += '• يجب وجود لاعب في كل فريق\n';
      if (!noUnassignedPlayers) errorMessage += '• يوجد لاعبون لم ينضموا لأي فريق\n';
      
      alert(errorMessage);
      return;
    }

    try {
      console.log('🎮 بدء اللعبة...', {
        roomId: lobbyState.currentRoom.id,
        playersCount: lobbyState.players.length,
        redTeam: redTeamPlayers.length,
        blueTeam: blueTeamPlayers.length
      });
      
      // تحديث حالة اللوبي أولاً لمنع الضغط المتكرر
      setLobbyState(prev => ({
        ...prev,
        mode: 'game'
      }));
      
      // Update room status
      const { error: roomError } = await supabase
        .from('game_rooms')
        .update({ status: 'playing' })
        .eq('id', lobbyState.currentRoom.id);

      if (roomError) throw roomError;
      
      console.log('✅ تم تحديث حالة الغرفة إلى "playing"');

      // Initialize game state - محاولة إنشاء حالة اللعبة
      let gameStateData: any = {
        room_id: lobbyState.currentRoom.id,
        phase: 'categoryPreSelection',
        current_turn: 'red',
        time_left: 15,
        red_team_score: 0,
        blue_team_score: 0,
        red_team_power_cards: 4,
        blue_team_power_cards: 4,
        game_history: [],
        used_questions: [],
        total_questions: 0,
        max_questions_per_team: 10,
        waiting_for_opponent: false
      };
      
      // محاولة إضافة selected_categories
      try {
        gameStateData.selected_categories = [];
        
        const { error: gameError } = await supabase
          .from('game_state')
          .upsert(gameStateData);
        
        if (gameError) {
          if (gameError.message.includes('selected_categories')) {
            console.log('⚠️ العمود selected_categories غير متاح، إنشاء حالة اللعبة بدونه...');
            delete gameStateData.selected_categories;
            gameStateData.phase = 'categorySelection';
          } else if (gameError.message.includes('categoryPreSelection')) {
            console.log('⚠️ المرحلة categoryPreSelection غير متاحة، استخدام categorySelection...');
            gameStateData.phase = 'categorySelection';
          } else {
            throw gameError;
          }
          
          // إنشاء حالة اللعبة بدون الميزات المفقودة
          
          const { error: fallbackGameError } = await supabase
            .from('game_state')
            .upsert(gameStateData);
          
          if (fallbackGameError) throw fallbackGameError;
          console.log('✅ تم إنشاء حالة اللعبة مع الإعدادات المتاحة');
        } else {
          console.log('✅ تم إنشاء حالة اللعبة مع جميع الميزات');
        }
      } catch (gameStateError) {
        console.error('❌ خطأ في إنشاء حالة اللعبة:', gameStateError);
        throw gameStateError;
      }

      console.log('✅ تم إنشاء حالة اللعبة');

      console.log('✅ تم الانتقال إلى وضع اللعبة');
    } catch (error) {
      console.error('Error starting game:', error);
      // إعادة تعيين الحالة في حالة الخطأ
      setLobbyState(prev => ({
        ...prev,
        mode: 'room'
      }));
      
      // رسالة خطأ مفصلة
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error('❌ تفاصيل الخطأ:', errorMessage);
      
      if (errorMessage.includes('selected_categories') || errorMessage.includes('categoryPreSelection') || errorMessage.includes('phase_check')) {
        alert(`خطأ في بدء اللعبة: قاعدة البيانات تحتاج تحديث.\n\nالحل:\n1. اذهب إلى Supabase Dashboard\n2. افتح SQL Editor\n3. شغّل محتوى الملفات التالية بالترتيب:\n   - supabase/migrations/20250726100321_gentle_glade.sql\n   - supabase/migrations/20250726192911_silent_mountain.sql\n   - supabase/migrations/20250726194741_fancy_ember.sql\n\nهذا سيحل جميع مشاكل قاعدة البيانات.`);
      } else {
        alert(`خطأ في بدء اللعبة: ${errorMessage}`);
      }
    }
  }, [lobbyState.currentRoom, lobbyState.players, lobbyState.playerId]);

  // End game and return to lobby
  const endGame = useCallback(async () => {
    if (!lobbyState.currentRoom) return;
    if (!hasValidSupabaseConfig || !supabase) return;

    try {
      // Update room status back to waiting
      await supabase
        .from('game_rooms')
        .update({ status: 'waiting' })
        .eq('id', lobbyState.currentRoom.id);

      // Delete game state
      await supabase
        .from('game_state')
        .delete()
        .eq('room_id', lobbyState.currentRoom.id);

      // Reset all players to not ready
      await supabase
        .from('game_players')
        .update({ is_ready: false })
        .eq('room_id', lobbyState.currentRoom.id);

      setLobbyState(prev => ({
        ...prev,
        mode: 'room'
      }));

      await loadPlayers(lobbyState.currentRoom.id);
    } catch (error) {
      console.error('Error ending game:', error);
    }
  }, [lobbyState.currentRoom, loadPlayers]);

  // Add bot player
  const addBot = useCallback(async () => {
    if (!lobbyState.currentRoom) return;
    if (!hasValidSupabaseConfig || !supabase) return;
    
    // Check if user is host
    const isHost = lobbyState.currentRoom.host_id === lobbyState.playerId;
    if (!isHost) return;
    
    try {
      // Bot names
      const botNames = [
        'أحمد الذكي',
        'فاطمة العبقرية', 
        'محمد السريع',
        'عائشة الخبيرة',
        'علي المفكر',
        'زينب الماهرة',
        'خالد البطل',
        'نور الذكية'
      ];
      
      // Get existing players to avoid duplicate names
      const existingBotNames = lobbyState.players
        .filter(p => p.player_name.includes('🤖'))
        .map(p => p.player_name.replace('🤖 ', '').replace(' (بوت)', ''));
      
      // Find available bot name
      const availableBotNames = botNames.filter(name => !existingBotNames.includes(name));
      if (availableBotNames.length === 0) return;
      
      const botName = `🤖 ${availableBotNames[0]} (بوت)`;
      const botId = uuidv4();
      
      // Determine which team has fewer players
      const redTeamCount = lobbyState.players.filter(p => p.team === 'red').length;
      const blueTeamCount = lobbyState.players.filter(p => p.team === 'blue').length;
      
      // تحديد الفريق بشكل واضح
      let botTeam: 'red' | 'blue' = 'red'; // القيمة الافتراضية
      
      if (redTeamCount === 0 && blueTeamCount === 0) {
        // إذا لم يكن هناك لاعبون في أي فريق
        botTeam = 'red';
        console.log('🤖 البوت ينضم للفريق الأحمر (كلا الفريقين فارغ)');
      } else if (redTeamCount === 0) {
        // إذا كان الفريق الأحمر فارغ
        botTeam = 'red';
        console.log('🤖 البوت ينضم للفريق الأحمر (فارغ)');
      } else if (blueTeamCount === 0) {
        // إذا كان الفريق الأزرق فارغ
        botTeam = 'blue';
        console.log('🤖 البوت ينضم للفريق الأزرق (فارغ)');
      } else {
        // كلا الفريقين بهما لاعبون، اختر الأقل عدداً
        botTeam = redTeamCount <= blueTeamCount ? 'red' : 'blue';
        console.log(`🤖 البوت ينضم للفريق ${botTeam === 'red' ? 'الأحمر' : 'الأزرق'} (الأقل عدداً)`);
      }
      
      console.log('🤖 إضافة بوت:', {
        botName,
        botTeam,
        redTeamCount,
        blueTeamCount,
        totalPlayers: lobbyState.players.length
      });
      
      // Add bot to database
      const { error: playerError } = await supabase
        .from('game_players')
        .insert({
          room_id: lobbyState.currentRoom.id,
          player_id: botId,
          player_name: botName,
          team: botTeam,
          is_ready: true
        });
      
      if (playerError) throw playerError;
      
      console.log('✅ تم إضافة البوت بنجاح:', botName, 'للفريق', botTeam);
      
      // Update room player count
      const { error: updateError } = await supabase
        .from('game_rooms')
        .update({ current_players: lobbyState.players.length + 1 })
        .eq('id', lobbyState.currentRoom.id);
      
      if (updateError) throw updateError;
      
      // انتظار أطول للتأكد من حفظ البيانات
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      await loadPlayers(lobbyState.currentRoom.id);
      
      // التحقق من حالة اللاعبين بعد التحديث
      const updatedPlayers = await supabase
        .from('game_players')
        .select('*')
        .eq('room_id', lobbyState.currentRoom.id);
      
      console.log('🎉 تم تحديث قائمة اللاعبين بعد إضافة البوت:', {
        playersInDB: updatedPlayers.data?.length || 0,
        playersInState: lobbyState.players.length + 1,
        newBotData: updatedPlayers.data?.find(p => p.player_name === botName)
      });
    } catch (error) {
      console.error('Error adding bot:', error);
      alert(`خطأ في إضافة اللاعب الوهمي: ${error.message || error}`);
    }
  }, [lobbyState.currentRoom, lobbyState.players, lobbyState.playerId, loadPlayers]);

  // Set up real-time subscriptions
  useEffect(() => {
    if (lobbyState.mode === 'menu') {
      loadRooms();
      
      // Subscribe to rooms changes for live updates
      if (hasValidSupabaseConfig && supabase) {
        const roomsSubscription = supabase
          .channel('public-rooms')
          .on('postgres_changes',
            {
              event: 'INSERT',
              schema: 'public',
              table: 'game_rooms'
            },
            (payload) => {
              console.log('غرفة جديدة تم إنشاؤها:', payload.new);
              loadRooms();
            }
          )
          .on('postgres_changes',
            {
              event: 'UPDATE',
              schema: 'public',
              table: 'game_rooms'
            },
            (payload) => {
              console.log('تم تحديث غرفة:', payload.new);
              loadRooms();
            }
          )
          .on('postgres_changes',
            {
              event: 'DELETE',
              schema: 'public',
              table: 'game_rooms'
            },
            (payload) => {
              console.log('تم حذف غرفة:', payload.old);
              loadRooms();
            }
          )
          // مراقبة تغييرات اللاعبين لتحديث عدد اللاعبين
          .on('postgres_changes',
            {
              event: '*',
              schema: 'public',
              table: 'game_players'
            },
            (payload) => {
              console.log('تغيير في اللاعبين:', payload);
              // تحديث الغرف عند تغيير اللاعبين
              setTimeout(() => loadRooms(), 500);
            }
          )
          .subscribe();

        return () => {
          roomsSubscription.unsubscribe();
        };
      }
    }
  }, [lobbyState.mode, loadRooms]);

  useEffect(() => {
    if (lobbyState.currentRoom && hasValidSupabaseConfig && supabase) {
      loadPlayers(lobbyState.currentRoom.id);

      // Subscribe to player changes
      const playersSubscription = supabase
        .channel(`room-${lobbyState.currentRoom.id}-players`)
        .on('postgres_changes', 
          { 
            event: '*', 
            schema: 'public', 
            table: 'game_players',
            filter: `room_id=eq.${lobbyState.currentRoom.id}`
          }, 
          (payload) => {
            console.log('🔄 تحديث اللاعبين:', payload);
            loadPlayers(lobbyState.currentRoom!.id);
          }
        )
        .subscribe();

      // Subscribe to room changes
      const roomSubscription = supabase
        .channel(`room-${lobbyState.currentRoom.id}`)
        .on('postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'game_rooms',
            filter: `id=eq.${lobbyState.currentRoom.id}`
          },
          (payload) => {
            const updatedRoom = payload.new as GameRoom;
            console.log('🏠 تحديث الغرفة:', updatedRoom);
            setLobbyState(prev => ({
              ...prev,
              currentRoom: updatedRoom
            }));

            if (updatedRoom.status === 'playing') {
              console.log('🎮 الانتقال إلى وضع اللعبة...');
              setLobbyState(prev => ({ ...prev, mode: 'game' }));
            }
          }
        )
        .subscribe();
      
      // Subscribe to game state changes
      const gameStateSubscription = supabase
        .channel(`game-state-${lobbyState.currentRoom.id}`)
        .on('postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'game_state',
            filter: `room_id=eq.${lobbyState.currentRoom.id}`
          },
          (payload) => {
            console.log('🎯 تحديث حالة اللعبة:', payload);
            // إذا تم إنشاء حالة لعبة جديدة، انتقل إلى وضع اللعبة
            if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
              setLobbyState(prev => ({ ...prev, mode: 'game' }));
            }
          }
        )
        .subscribe();

      return () => {
        playersSubscription.unsubscribe();
        roomSubscription.unsubscribe();
        gameStateSubscription.unsubscribe();
      };
    }
  }, [lobbyState.currentRoom, loadPlayers]);

  return {
    lobbyState,
    setPlayerName,
    createRoom,
    joinRoom,
    leaveRoom,
    toggleReady,
    switchTeam,
    startGame,
    endGame,
    refreshRooms: loadRooms,
    cleanupEmptyRooms,
    addBot
  };
};