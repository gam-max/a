import { useState, useEffect, useCallback } from 'react';
import { Question, CategoryQuestion } from '../types/game';

interface QuestionHistory {
  questionId: number;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  timestamp: number;
}

interface QuestionManagerState {
  usedQuestions: QuestionHistory[];
  sessionQuestions: Set<string>; // للجلسة الحالية
  globalQuestions: Set<string>; // لجميع الجلسات
}

const STORAGE_KEY = 'trivia_question_history';
const MAX_HISTORY_SIZE = 1000; // الحد الأقصى للأسئلة المحفوظة
const RESET_THRESHOLD = 0.8; // إعادة تعيين عند استخدام 80% من الأسئلة

export const useQuestionManager = (categoryQuestions: CategoryQuestion[]) => {
  const [questionState, setQuestionState] = useState<QuestionManagerState>({
    usedQuestions: [],
    sessionQuestions: new Set(),
    globalQuestions: new Set()
  });

  // تحميل تاريخ الأسئلة من localStorage
  useEffect(() => {
    try {
      const savedHistory = localStorage.getItem(STORAGE_KEY);
      if (savedHistory) {
        const history: QuestionHistory[] = JSON.parse(savedHistory);
        const globalSet = new Set(history.map(h => `${h.category}-${h.difficulty}-${h.questionId}`));
        
        setQuestionState(prev => ({
          ...prev,
          usedQuestions: history,
          globalQuestions: globalSet
        }));
      }
    } catch (error) {
      console.error('Error loading question history:', error);
    }
  }, []);

  // حفظ تاريخ الأسئلة
  const saveQuestionHistory = useCallback((history: QuestionHistory[]) => {
    try {
      // الاحتفاظ بآخر MAX_HISTORY_SIZE سؤال فقط
      const trimmedHistory = history
        .sort((a, b) => b.timestamp - a.timestamp)
        .slice(0, MAX_HISTORY_SIZE);
      
      localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmedHistory));
    } catch (error) {
      console.error('Error saving question history:', error);
    }
  }, []);

  // إضافة سؤال للتاريخ
  const addQuestionToHistory = useCallback((question: Question) => {
    const questionKey = `${question.category}-${question.difficulty}-${question.id}`;
    const historyEntry: QuestionHistory = {
      questionId: question.id,
      category: question.category,
      difficulty: question.difficulty,
      timestamp: Date.now()
    };

    setQuestionState(prev => {
      const newHistory = [...prev.usedQuestions, historyEntry];
      const newGlobalSet = new Set([...prev.globalQuestions, questionKey]);
      const newSessionSet = new Set([...prev.sessionQuestions, questionKey]);

      // حفظ التاريخ الجديد
      saveQuestionHistory(newHistory);

      return {
        usedQuestions: newHistory,
        globalQuestions: newGlobalSet,
        sessionQuestions: newSessionSet
      };
    });
  }, [saveQuestionHistory]);

  // الحصول على أسئلة متاحة (غير مستخدمة)
  const getAvailableQuestions = useCallback((
    category: string, 
    difficulty: 'easy' | 'medium' | 'hard',
    prioritizeNew: boolean = true
  ): Question[] => {
    const categoryData = categoryQuestions.find(c => c.category === category);
    if (!categoryData) return [];

    const allQuestions = categoryData.difficulties[difficulty] || [];
    if (allQuestions.length === 0) return [];

    // تصنيف الأسئلة
    const newQuestions: Question[] = [];
    const usedInSession: Question[] = [];
    const usedGlobally: Question[] = [];

    allQuestions.forEach(question => {
      const questionKey = `${category}-${difficulty}-${question.id}`;
      
      if (questionState.sessionQuestions.has(questionKey)) {
        usedInSession.push(question);
      } else if (questionState.globalQuestions.has(questionKey)) {
        usedGlobally.push(question);
      } else {
        newQuestions.push(question);
      }
    });

    console.log(`📊 إحصائيات الأسئلة - ${category} (${difficulty}):`, {
      total: allQuestions.length,
      new: newQuestions.length,
      usedInSession: usedInSession.length,
      usedGlobally: usedGlobally.length
    });

    // ترتيب الأولوية
    if (prioritizeNew) {
      // أولوية للأسئلة الجديدة، ثم المستخدمة عالمياً، ثم المستخدمة في الجلسة
      return [...newQuestions, ...usedGlobally, ...usedInSession];
    } else {
      // خلط عشوائي لجميع الأسئلة
      return shuffleArray([...newQuestions, ...usedGlobally, ...usedInSession]);
    }
  }, [categoryQuestions, questionState]);

  // اختيار سؤال عشوائي ذكي
  const selectRandomQuestion = useCallback((
    category: string, 
    difficulty: 'easy' | 'medium' | 'hard'
  ): Question | null => {
    const availableQuestions = getAvailableQuestions(category, difficulty, true);
    
    if (availableQuestions.length === 0) {
      console.warn(`⚠️ لا توجد أسئلة متاحة في ${category} - ${difficulty}`);
      return null;
    }

    // اختيار عشوائي من أول 3 أسئلة (الأولوية العالية)
    const topQuestions = availableQuestions.slice(0, Math.min(3, availableQuestions.length));
    const selectedQuestion = topQuestions[Math.floor(Math.random() * topQuestions.length)];

    console.log(`🎯 تم اختيار سؤال من ${category} - ${difficulty}:`, {
      questionId: selectedQuestion.id,
      isNew: !questionState.globalQuestions.has(`${category}-${difficulty}-${selectedQuestion.id}`),
      availableCount: availableQuestions.length
    });

    return selectedQuestion;
  }, [getAvailableQuestions, questionState.globalQuestions]);

  // فحص نسبة الاستخدام
  const getUsageStats = useCallback((category: string, difficulty: 'easy' | 'medium' | 'hard') => {
    const categoryData = categoryQuestions.find(c => c.category === category);
    if (!categoryData) return { total: 0, used: 0, percentage: 0, needsReset: false };

    const allQuestions = categoryData.difficulties[difficulty] || [];
    const usedCount = allQuestions.filter(q => 
      questionState.sessionQuestions.has(`${category}-${difficulty}-${q.id}`)
    ).length;

    const percentage = allQuestions.length > 0 ? (usedCount / allQuestions.length) : 0;
    const needsReset = percentage >= RESET_THRESHOLD;

    return {
      total: allQuestions.length,
      used: usedCount,
      percentage: Math.round(percentage * 100),
      needsReset
    };
  }, [categoryQuestions, questionState.sessionQuestions]);

  // إعادة تعيين جلسة الأسئلة
  const resetSession = useCallback(() => {
    setQuestionState(prev => ({
      ...prev,
      sessionQuestions: new Set()
    }));
    console.log('🔄 تم إعادة تعيين جلسة الأسئلة');
  }, []);

  // إعادة تعيين كامل للتاريخ
  const resetAllHistory = useCallback(() => {
    setQuestionState({
      usedQuestions: [],
      sessionQuestions: new Set(),
      globalQuestions: new Set()
    });
    localStorage.removeItem(STORAGE_KEY);
    console.log('🗑️ تم حذف جميع تاريخ الأسئلة');
  }, []);

  // دالة مساعدة لخلط المصفوفة
  const shuffleArray = <T>(array: T[]): T[] => {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  return {
    // الوظائف الأساسية
    selectRandomQuestion,
    addQuestionToHistory,
    getAvailableQuestions,
    
    // الإحصائيات
    getUsageStats,
    
    // إدارة الجلسة
    resetSession,
    resetAllHistory,
    
    // البيانات
    questionHistory: questionState.usedQuestions,
    sessionQuestionsCount: questionState.sessionQuestions.size,
    globalQuestionsCount: questionState.globalQuestions.size
  };
};