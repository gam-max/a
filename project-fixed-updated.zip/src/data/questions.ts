import { CategoryQuestion } from '../types/game';

export const categoryQuestions: CategoryQuestion[] = [
  {
    category: "التاريخ",
    icon: "Book",
    difficulties: {
      easy: [
        {
          id: 1,
          question: "في أي عام انتهت الحرب العالمية الثانية؟",
          options: ["1944", "1945", "1946", "1947"],
          correctAnswer: 1,
          category: "التاريخ",
          difficulty: "easy",
          points: 10
        },
        {
          id: 2,
          question: "من هو أول رئيس للولايات المتحدة الأمريكية؟",
          options: ["توماس جيفرسون", "جورج واشنطن", "جون آدامز", "بنيامين فرانكلين"],
          correctAnswer: 1,
          category: "التاريخ",
          difficulty: "easy",
          points: 10
        },
        {
          id: 3,
          question: "في أي قرن عاش نابليون بونابرت؟",
          options: ["القرن 17", "القرن 18", "القرن 19", "القرن 20"],
          correctAnswer: 2,
          category: "التاريخ",
          difficulty: "easy",
          points: 10
        }
      ],
      medium: [
        {
          id: 4,
          question: "متى تم فتح القسطنطينية على يد العثمانيين؟",
          options: ["1453", "1456", "1461", "1448"],
          correctAnswer: 0,
          category: "التاريخ",
          difficulty: "medium",
          points: 20
        },
        {
          id: 5,
          question: "من هو القائد الذي هزم نابليون في معركة واترلو؟",
          options: ["ولينغتون", "نيلسون", "بلوخر", "كوتوزوف"],
          correctAnswer: 0,
          category: "التاريخ",
          difficulty: "medium",
          points: 20
        },
        {
          id: 6,
          question: "في أي عام تم توقيع معاهدة فرساي؟",
          options: ["1918", "1919", "1920", "1921"],
          correctAnswer: 1,
          category: "التاريخ",
          difficulty: "medium",
          points: 20
        }
      ],
      hard: [
        {
          id: 7,
          question: "من هو الإمبراطور البيزنطي الذي حكم أثناء حصار القسطنطينية عام 1453؟",
          options: ["قسطنطين الحادي عشر", "يوحنا الثامن", "مانويل الثاني", "يوحنا السابع"],
          correctAnswer: 0,
          category: "التاريخ",
          difficulty: "hard",
          points: 30
        },
        {
          id: 8,
          question: "في أي عام تم توقيع صلح الحديبية؟",
          options: ["6 هـ", "7 هـ", "8 هـ", "5 هـ"],
          correctAnswer: 0,
          category: "التاريخ",
          difficulty: "hard",
          points: 30
        }
      ]
    }
  },
  {
    category: "الجغرافيا",
    icon: "Globe",
    difficulties: {
      easy: [
        {
          id: 9,
          question: "ما هي عاصمة فرنسا؟",
          options: ["لندن", "برلين", "باريس", "روما"],
          correctAnswer: 2,
          category: "الجغرافيا",
          difficulty: "easy",
          points: 10
        },
        {
          id: 10,
          question: "كم عدد قارات العالم؟",
          options: ["5", "6", "7", "8"],
          correctAnswer: 2,
          category: "الجغرافيا",
          difficulty: "easy",
          points: 10
        },
        {
          id: 11,
          question: "ما هو أكبر محيط في العالم؟",
          options: ["المحيط الأطلسي", "المحيط الهادئ", "المحيط الهندي", "المحيط المتجمد الشمالي"],
          correctAnswer: 1,
          category: "الجغرافيا",
          difficulty: "easy",
          points: 10
        }
      ],
      medium: [
        {
          id: 12,
          question: "ما هي أطول سلسلة جبال في العالم؟",
          options: ["جبال الهيمالايا", "جبال الأنديز", "جبال الألب", "جبال روكي"],
          correctAnswer: 1,
          category: "الجغرافيا",
          difficulty: "medium",
          points: 20
        },
        {
          id: 13,
          question: "ما هي أصغر دولة في العالم؟",
          options: ["موناكو", "ناورو", "الفاتيكان", "سان مارينو"],
          correctAnswer: 2,
          category: "الجغرافيا",
          difficulty: "medium",
          points: 20
        },
        {
          id: 14,
          question: "في أي قارة تقع صحراء كالاهاري؟",
          options: ["آسيا", "أفريقيا", "أستراليا", "أمريكا الجنوبية"],
          correctAnswer: 1,
          category: "الجغرافيا",
          difficulty: "medium",
          points: 20
        }
      ],
      hard: [
        {
          id: 15,
          question: "ما هو أعمق خندق في المحيطات؟",
          options: ["خندق ماريانا", "خندق بورتوريكو", "خندق اليابان", "خندق بيرو-تشيلي"],
          correctAnswer: 0,
          category: "الجغرافيا",
          difficulty: "hard",
          points: 30
        },
        {
          id: 16,
          question: "كم عدد الدول التي تحدها سويسرا؟",
          options: ["4", "5", "6", "7"],
          correctAnswer: 1,
          category: "الجغرافيا",
          difficulty: "hard",
          points: 30
        }
      ]
    }
  },
  {
    category: "العلوم",
    icon: "Atom",
    difficulties: {
      easy: [
        {
          id: 17,
          question: "ما هو أكبر كوكب في المجموعة الشمسية؟",
          options: ["زحل", "المشتري", "أورانوس", "نبتون"],
          correctAnswer: 1,
          category: "العلوم",
          difficulty: "easy",
          points: 10
        },
        {
          id: 18,
          question: "ما هو الرمز الكيميائي للذهب؟",
          options: ["Go", "Au", "Ag", "Gd"],
          correctAnswer: 1,
          category: "العلوم",
          difficulty: "easy",
          points: 10
        },
        {
          id: 19,
          question: "كم عدد أسنان الإنسان البالغ؟",
          options: ["28", "30", "32", "34"],
          correctAnswer: 2,
          category: "العلوم",
          difficulty: "easy",
          points: 10
        }
      ],
      medium: [
        {
          id: 20,
          question: "ما هو الغاز الأكثر وفرة في الغلاف الجوي؟",
          options: ["الأكسجين", "ثاني أكسيد الكربون", "النيتروجين", "الهيدروجين"],
          correctAnswer: 2,
          category: "العلوم",
          difficulty: "medium",
          points: 20
        },
        {
          id: 21,
          question: "كم عدد العضلات في جسم الإنسان تقريباً؟",
          options: ["400", "500", "600", "700"],
          correctAnswer: 2,
          category: "العلوم",
          difficulty: "medium",
          points: 20
        },
        {
          id: 22,
          question: "ما هي وحدة قياس التردد؟",
          options: ["هرتز", "واط", "فولت", "أمبير"],
          correctAnswer: 0,
          category: "العلوم",
          difficulty: "medium",
          points: 20
        }
      ],
      hard: [
        {
          id: 23,
          question: "ما هو العدد الذري للكربون؟",
          options: ["4", "6", "8", "12"],
          correctAnswer: 1,
          category: "العلوم",
          difficulty: "hard",
          points: 30
        },
        {
          id: 24,
          question: "من اكتشف قانون الجاذبية؟",
          options: ["أينشتاين", "نيوتن", "غاليليو", "كبلر"],
          correctAnswer: 1,
          category: "العلوم",
          difficulty: "hard",
          points: 30
        }
      ]
    }
  },
  {
    category: "التكنولوجيا",
    icon: "Smartphone",
    difficulties: {
      easy: [
        {
          id: 25,
          question: "من هو مؤسس شركة مايكروسوفت؟",
          options: ["ستيف جوبز", "بيل غيتس", "مارك زوكربيرغ", "لاري بيج"],
          correctAnswer: 1,
          category: "التكنولوجيا",
          difficulty: "easy",
          points: 10
        },
        {
          id: 26,
          question: "في أي عام تم اختراع الإنترنت؟",
          options: ["1969", "1975", "1981", "1989"],
          correctAnswer: 0,
          category: "التكنولوجيا",
          difficulty: "easy",
          points: 10
        },
        {
          id: 27,
          question: "من اخترع الهاتف؟",
          options: ["توماس إديسون", "ألكسندر غراهام بيل", "نيكولا تيسلا", "بنيامين فرانكلين"],
          correctAnswer: 1,
          category: "التكنولوجيا",
          difficulty: "easy",
          points: 10
        }
      ],
      medium: [
        {
          id: 28,
          question: "ما هو اختصار HTML؟",
          options: ["HyperText Markup Language", "High Tech Modern Language", "Home Tool Markup Language", "Hyperlink Text Management Language"],
          correctAnswer: 0,
          category: "التكنولوجيا",
          difficulty: "medium",
          points: 20
        },
        {
          id: 29,
          question: "في أي عام تم إطلاق أول آيفون؟",
          options: ["2005", "2006", "2007", "2008"],
          correctAnswer: 2,
          category: "التكنولوجيا",
          difficulty: "medium",
          points: 20
        },
        {
          id: 30,
          question: "ما هو اسم أول حاسوب إلكتروني؟",
          options: ["ENIAC", "UNIVAC", "EDVAC", "MANIAC"],
          correctAnswer: 0,
          category: "التكنولوجيا",
          difficulty: "medium",
          points: 20
        }
      ],
      hard: [
        {
          id: 31,
          question: "من هو مخترع شبكة الويب العالمية؟",
          options: ["تيم بيرنرز لي", "فينت سيرف", "روبرت كان", "لاري روبرتس"],
          correctAnswer: 0,
          category: "التكنولوجيا",
          difficulty: "hard",
          points: 30
        },
        {
          id: 32,
          question: "ما هو أول نظام تشغيل تم تطويره من قبل مايكروسوفت؟",
          options: ["MS-DOS", "Windows 1.0", "Xenix", "Windows 95"],
          correctAnswer: 0,
          category: "التكنولوجيا",
          difficulty: "hard",
          points: 30
        }
      ]
    }
  },
  {
    category: "الأدب",
    icon: "PenTool",
    difficulties: {
      easy: [
        {
          id: 33,
          question: "من كتب رواية 'مئة عام من العزلة'؟",
          options: ["بورخيس", "غابرييل غارسيا ماركيز", "إيزابيل الليندي", "أوكتافيو باث"],
          correctAnswer: 1,
          category: "الأدب",
          difficulty: "easy",
          points: 10
        },
        {
          id: 34,
          question: "من هو مؤلف 'الأسود يليق بك'؟",
          options: ["أحلام مستغانمي", "غادة السمان", "نوال السعداوي", "إميلي نصرالله"],
          correctAnswer: 0,
          category: "الأدب",
          difficulty: "easy",
          points: 10
        },
        {
          id: 35,
          question: "من كتب 'روميو وجولييت'؟",
          options: ["تشارلز ديكنز", "وليام شكسبير", "جين أوستن", "مارك توين"],
          correctAnswer: 1,
          category: "الأدب",
          difficulty: "easy",
          points: 10
        }
      ],
      medium: [
        {
          id: 36,
          question: "من هو مؤلف 'الكوميديا الإلهية'؟",
          options: ["دانتي أليغييري", "بترارك", "بوكاتشيو", "تاسو"],
          correctAnswer: 0,
          category: "الأدب",
          difficulty: "medium",
          points: 20
        },
        {
          id: 37,
          question: "في أي عام نشرت رواية '1984'؟",
          options: ["1948", "1949", "1950", "1951"],
          correctAnswer: 1,
          category: "الأدب",
          difficulty: "medium",
          points: 20
        },
        {
          id: 38,
          question: "من كتب 'الحرب والسلام'؟",
          options: ["فيودور دوستويفسكي", "ليو تولستوي", "أنطون تشيخوف", "إيفان تورغينيف"],
          correctAnswer: 1,
          category: "الأدب",
          difficulty: "medium",
          points: 20
        }
      ],
      hard: [
        {
          id: 39,
          question: "من هو مؤلف 'يوليسيس'؟",
          options: ["جيمس جويس", "فرجينيا وولف", "دي إتش لورانس", "تي إس إليوت"],
          correctAnswer: 0,
          category: "الأدب",
          difficulty: "hard",
          points: 30
        },
        {
          id: 40,
          question: "في أي عام حصل نجيب محفوظ على جائزة نوبل للأدب؟",
          options: ["1986", "1987", "1988", "1989"],
          correctAnswer: 2,
          category: "الأدب",
          difficulty: "hard",
          points: 30
        }
      ]
    }
  },
  {
    category: "الرياضة",
    icon: "Trophy",
    difficulties: {
      easy: [
        {
          id: 41,
          question: "كم عدد اللاعبين في فريق كرة القدم؟",
          options: ["9", "10", "11", "12"],
          correctAnswer: 2,
          category: "الرياضة",
          difficulty: "easy",
          points: 10
        },
        {
          id: 42,
          question: "في أي مدينة أقيمت أولمبياد 2020؟",
          options: ["بكين", "طوكيو", "لندن", "ريو دي جانيرو"],
          correctAnswer: 1,
          category: "الرياضة",
          difficulty: "easy",
          points: 10
        },
        {
          id: 43,
          question: "كم مرة فازت البرازيل بكأس العالم؟",
          options: ["3", "4", "5", "6"],
          correctAnswer: 2,
          category: "الرياضة",
          difficulty: "easy",
          points: 10
        }
      ],
      medium: [
        {
          id: 44,
          question: "من هو أسرع رجل في العالم حالياً؟",
          options: ["يوسين بولت", "تايسون غاي", "جاستن غاتلين", "أساف باول"],
          correctAnswer: 0,
          category: "الرياضة",
          difficulty: "medium",
          points: 20
        },
        {
          id: 45,
          question: "في أي عام فاز محمد صلاح بجائزة أفضل لاعب أفريقي؟",
          options: ["2016", "2017", "2018", "2019"],
          correctAnswer: 1,
          category: "الرياضة",
          difficulty: "medium",
          points: 20
        },
        {
          id: 46,
          question: "كم عدد الحلقات في شعار الأولمبياد؟",
          options: ["4", "5", "6", "7"],
          correctAnswer: 1,
          category: "الرياضة",
          difficulty: "medium",
          points: 20
        }
      ],
      hard: [
        {
          id: 47,
          question: "من هو أول لاعب عربي يفوز بدوري أبطال أوروبا؟",
          options: ["محمد صلاح", "رياض محرز", "حكيم زياش", "ياسين براهيمي"],
          correctAnswer: 0,
          category: "الرياضة",
          difficulty: "hard",
          points: 30
        },
        {
          id: 48,
          question: "في أي عام تأسس الاتحاد الدولي لكرة القدم (فيفا)؟",
          options: ["1902", "1904", "1906", "1908"],
          correctAnswer: 1,
          category: "الرياضة",
          difficulty: "hard",
          points: 30
        }
      ]
    }
  }
];